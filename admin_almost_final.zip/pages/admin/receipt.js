import React from 'react'
import SimpleHeader from '../../components/Headers/SimpleHeader';
import Admin from '../../layouts/Admin'

function receipt() {
    return (
        <div>
            This is Genrated Receipty 
        </div>
    )
}

receipt.layout=Admin;

export default receipt
