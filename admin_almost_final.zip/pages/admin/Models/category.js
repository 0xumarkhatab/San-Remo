\
export default class category{
    title;
    description;
    imageURL;
    flavors;
    constructor(title,description,imageURL,flavors){
        this.title=title;
        this.description=description;
        this.imageURL=imageURL;
        this.flavors=flavors;
        
    }

};
