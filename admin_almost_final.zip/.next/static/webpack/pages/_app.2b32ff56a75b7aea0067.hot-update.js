webpackHotUpdate_N_E("pages/_app",{

/***/ "./API_WORK/fetchAndDispatch.js":
/*!**************************************!*\
  !*** ./API_WORK/fetchAndDispatch.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_Categories_CategoriesData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Categories/CategoriesData */ "./components/Categories/CategoriesData.js");
/* harmony import */ var _components_Foods_foodsData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Foods/foodsData */ "./components/Foods/foodsData.js");
/* harmony import */ var _components_Orders_ordersData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Orders/ordersData */ "./components/Orders/ordersData.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./api */ "./API_WORK/api.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! socket.io-client */ "./node_modules/socket.io-client/build/index.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_8__);



var _s = $RefreshSig$();









function fetchAndDispatch() {
  _s();

  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"])();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
    var _yield$api$get, data;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/category");

          case 2:
            _yield$api$get = _context.sent;
            data = _yield$api$get.data;
            dispatch({
              type: "SET_CATEGORIES",
              CATEGORIES: data
            });

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }))();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
    var _yield$api$get2, data;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/food");

          case 2:
            _yield$api$get2 = _context2.sent;
            data = _yield$api$get2.data;
            console.log(data, "Foods");
            dispatch({
              type: "SET_FOODS",
              FOODS: data
            });

          case 6:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }))();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
    var _yield$api$get3, data, socket;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/order");

          case 2:
            _yield$api$get3 = _context3.sent;
            data = _yield$api$get3.data;
            socket = Object(socket_io_client__WEBPACK_IMPORTED_MODULE_8__["io"])("http://192.168.100.156:5050");
            socket.on('order', function (order) {
              console.log("Order received ", order);
            });
            dispatch({
              type: "SET_ORDERS",
              ORDERS: data
            });

          case 7:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }))();

  return 0;
}

_s(fetchAndDispatch, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"]];
});

/* harmony default export */ __webpack_exports__["default"] = (fetchAndDispatch);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vQVBJX1dPUksvZmV0Y2hBbmREaXNwYXRjaC5qcyJdLCJuYW1lcyI6WyJmZXRjaEFuZERpc3BhdGNoIiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsImFwaSIsImdldCIsImRhdGEiLCJ0eXBlIiwiQ0FURUdPUklFUyIsImNvbnNvbGUiLCJsb2ciLCJGT09EUyIsInNvY2tldCIsImlvIiwib24iLCJvcmRlciIsIk9SREVSUyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLGdCQUFULEdBQTRCO0FBQUE7O0FBQzFCLE1BQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7O0FBRUEsMk5BQUM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQ3dCQyw0Q0FBRyxDQUFDQyxHQUFKLENBQVEsV0FBUixDQUR4Qjs7QUFBQTtBQUFBO0FBQ1NDLGdCQURULGtCQUNTQSxJQURUO0FBR0NKLG9CQUFRLENBQUM7QUFDUEssa0JBQUksRUFBRSxnQkFEQztBQUVQQyx3QkFBVSxFQUFFRjtBQUZMLGFBQUQsQ0FBUjs7QUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFEOztBQVNBLDJOQUFDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUNzQkYsNENBQUcsQ0FBQ0MsR0FBSixDQUFRLE9BQVIsQ0FEdEI7O0FBQUE7QUFBQTtBQUNRQyxnQkFEUixtQkFDUUEsSUFEUjtBQUVDRyxtQkFBTyxDQUFDQyxHQUFSLENBQVlKLElBQVosRUFBaUIsT0FBakI7QUFFQUosb0JBQVEsQ0FBQztBQUNQSyxrQkFBSSxFQUFFLFdBREM7QUFFUEksbUJBQUssRUFBRUw7QUFGQSxhQUFELENBQVI7O0FBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBRDs7QUFhQSwyTkFBQztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFDd0JGLDRDQUFHLENBQUNDLEdBQUosQ0FBUSxRQUFSLENBRHhCOztBQUFBO0FBQUE7QUFDU0MsZ0JBRFQsbUJBQ1NBLElBRFQ7QUFFT00sa0JBRlAsR0FFY0MsMkRBQUUsQ0FBQyw2QkFBRCxDQUZoQjtBQUlDRCxrQkFBTSxDQUFDRSxFQUFQLENBQVUsT0FBVixFQUFrQixVQUFDQyxLQUFELEVBQVM7QUFDMUJOLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QkssS0FBOUI7QUFJQyxhQUxGO0FBT0NiLG9CQUFRLENBQUM7QUFDUEssa0JBQUksRUFBRSxZQURDO0FBRVBTLG9CQUFNLEVBQUVWO0FBRkQsYUFBRCxDQUFSOztBQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQUQ7O0FBc0JBLFNBQU8sQ0FBUDtBQUNEOztHQWhEUUwsZ0I7VUFDVUUsdUQ7OztBQWlESkYsK0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC4yYjMyZmY1NmE3NWI3YWVhMDA2Ny5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VTZWxlY3RvciwgdXNlRGlzcGF0Y2ggfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcclxuaW1wb3J0IHsgY2F0ZWdvcmllcyB9IGZyb20gXCIuLi9jb21wb25lbnRzL0NhdGVnb3JpZXMvQ2F0ZWdvcmllc0RhdGFcIjtcclxuaW1wb3J0IHsgZm9vZHNBcnJheSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zvb2RzL2Zvb2RzRGF0YVwiO1xyXG5pbXBvcnQgeyBvcmRlcnNEYXRhIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvT3JkZXJzL29yZGVyc0RhdGFcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi9hcGlcIjtcclxuaW1wb3J0IHsgaW8gfSBmcm9tIFwic29ja2V0LmlvLWNsaWVudFwiO1xyXG5cclxuZnVuY3Rpb24gZmV0Y2hBbmREaXNwYXRjaCgpIHtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XHJcblxyXG4gIChhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoXCIvY2F0ZWdvcnlcIik7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9DQVRFR09SSUVTXCIsXHJcbiAgICAgIENBVEVHT1JJRVM6IGRhdGEsXHJcbiAgICB9KTtcclxuICB9KSgpO1xyXG5cclxuICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3Qge2RhdGF9ID0gYXdhaXQgYXBpLmdldChcIi9mb29kXCIpO1xyXG4gICAgY29uc29sZS5sb2coZGF0YSxcIkZvb2RzXCIpO1xyXG5cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogXCJTRVRfRk9PRFNcIixcclxuICAgICAgRk9PRFM6IGRhdGEsXHJcbiAgICB9KTtcclxuICAgIFxyXG4gIH0pKCk7XHJcblxyXG4gXHJcblxyXG4gIChhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoXCIvb3JkZXJcIik7XHJcbiAgICBjb25zdCBzb2NrZXQ9aW8oXCJodHRwOi8vMTkyLjE2OC4xMDAuMTU2OjUwNTBcIik7XHJcbiBcclxuICAgIHNvY2tldC5vbignb3JkZXInLChvcmRlcik9PntcclxuICAgICBjb25zb2xlLmxvZyhcIk9yZGVyIHJlY2VpdmVkIFwiLG9yZGVyKVxyXG4gICAgIFxyXG4gICAgICBcclxuICAgICAgXHJcbiAgICAgfSk7XHJcbiAgIFxyXG4gICAgIGRpc3BhdGNoKHtcclxuICAgICAgIHR5cGU6IFwiU0VUX09SREVSU1wiLFxyXG4gICAgICAgT1JERVJTOiBkYXRhICxcclxuICAgICB9KTtcclxuICAgICAgICAgXHJcbiAgICBcclxuICB9KSgpO1xyXG5cclxuICBcclxuICBcclxuICBcclxuICByZXR1cm4gMDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZmV0Y2hBbmREaXNwYXRjaDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==