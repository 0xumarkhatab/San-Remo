webpackHotUpdate_N_E("pages/admin/AddFood",{

/***/ "./API_WORK/api.js":
false,

/***/ "./assets/img/brand/nextjs_argon_black.png":
false,

/***/ "./assets/img/theme/team-1-800x800.jpg":
false,

/***/ "./assets/img/theme/team-4-800x800.jpg":
false,

/***/ "./components/Footers/AdminFooter.js":
false,

/***/ "./components/Headers/SimpleHeader.js":
false,

/***/ "./components/Navbars/AdminNavbar.js":
false,

/***/ "./components/SelectMenu/SelectMenuMultiple.jsx":
false,

/***/ "./components/SelectMenu/SelectMenuSingle.jsx":
false,

/***/ "./components/Sidebar/Sidebar.js":
false,

/***/ "./components/Sidebar/toggler.png":
false,

/***/ "./layouts/Admin.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next-stable-react-context/dist/esm/context.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next-stable-react-context/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsContext/LegacyAnalyticsContext.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsContext/ModernAnalyticsContext.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsContext/index.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsErrorBoundary.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsListener/LegacyAnalyticsListener.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsListener/ModernAnalyticsListener.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/components/AnalyticsListener/index.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/events/AnalyticsEvent.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/events/UIAnalyticsEvent.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hocs/withAnalyticsContext.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hocs/withAnalyticsEvents.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/useAnalyticsContext.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/useAnalyticsEvents.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/useCallbackWithAnalytics.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/usePatchedProps.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/usePlatformLeafEventHandler.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/usePlatformLeafSyntheticEventHandler.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/hooks/useTrackedRef.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/utils/cleanProps.js":
false,

/***/ "./node_modules/@atlaskit/analytics-next/dist/esm/utils/createAndFireEvent.js":
false,

/***/ "./node_modules/@atlaskit/ds-lib/dist/esm/hooks/use-close-on-escape-press.js":
false,

/***/ "./node_modules/@atlaskit/ds-lib/dist/esm/hooks/use-document-event.js":
false,

/***/ "./node_modules/@atlaskit/ds-lib/dist/esm/utils/keycodes.js":
false,

/***/ "./node_modules/@atlaskit/icon/dist/esm/components/icon.js":
false,

/***/ "./node_modules/@atlaskit/icon/dist/esm/components/styles.js":
false,

/***/ "./node_modules/@atlaskit/icon/dist/esm/components/utils.js":
false,

/***/ "./node_modules/@atlaskit/icon/dist/esm/constants.js":
false,

/***/ "./node_modules/@atlaskit/icon/dist/esm/entry-points/base.js":
false,

/***/ "./node_modules/@atlaskit/icon/glyph/emoji.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/exiting-persistence.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/fade-in.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/keyframes-motion.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/shrink-out.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/slide-in.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/staggered-entrance.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/entering/zoom-in.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/resizing/height.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/accessibility.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/curves.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/durations.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/timer-hooks.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/use-element-ref.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/use-force-render.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/use-layout-effect.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/use-snapshot-before-update.js":
false,

/***/ "./node_modules/@atlaskit/motion/dist/esm/utils/use-unique-id.js":
false,

/***/ "./node_modules/@atlaskit/popper/dist/esm/Popper.js":
false,

/***/ "./node_modules/@atlaskit/popper/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/Manager.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/Popper.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/Reference.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/usePopper.js":
false,

/***/ "./node_modules/@atlaskit/popper/node_modules/react-popper/lib/esm/utils.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/constants.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/components/internal-portal.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/constants.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/hooks/use-is-subsequent-render.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/hooks/use-portal-event.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/utils/portal-custom-event.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/internal/utils/portal-dom-utils.js":
false,

/***/ "./node_modules/@atlaskit/portal/dist/esm/portal.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/colors.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/components.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/components/Appearance.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/components/AtlaskitThemeProvider.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/components/Reset.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/components/Theme.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/constants.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/hoc.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/utils/createTheme.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/utils/getTheme.js":
false,

/***/ "./node_modules/@atlaskit/theme/dist/esm/utils/themed.js":
false,

/***/ "./node_modules/@atlaskit/tokens/dist/esm/get-token.js":
false,

/***/ "./node_modules/@atlaskit/tokens/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/tokens/dist/esm/set-global-theme.js":
false,

/***/ "./node_modules/@atlaskit/tokens/dist/esm/tokens/token-names.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/Tooltip.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/TooltipContainer.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/TooltipPrimitive.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/index.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/internal/shared-schedule.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/internal/tooltip-manager.js":
false,

/***/ "./node_modules/@atlaskit/tooltip/dist/esm/utilities.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/arrayWithHoles.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/classCallCheck.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/construct.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/createClass.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/assertThisInitialized.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/createClass.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/extends.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/inherits.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/inheritsLoose.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/objectWithoutProperties.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/objectWithoutPropertiesLoose.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/setPrototypeOf.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/taggedTemplateLiteral.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/typeof.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/get.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/inherits.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/inheritsLoose.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/isNativeReflectConstruct.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/nonIterableRest.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutProperties.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/setPrototypeOf.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/slicedToArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/superPropBase.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/taggedTemplateLiteral.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
false,

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
false,

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
false,

/***/ "./node_modules/@emotion/cache/dist/emotion-cache.browser.esm.js":
false,

/***/ "./node_modules/@emotion/cache/node_modules/stylis/dist/stylis.mjs":
false,

/***/ "./node_modules/@emotion/core/dist/core.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/dist/emotion-element-57a3a7a3.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/node_modules/@emotion/cache/dist/cache.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/node_modules/@emotion/memoize/dist/memoize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/node_modules/@emotion/serialize/dist/serialize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/node_modules/@emotion/sheet/dist/sheet.browser.esm.js":
false,

/***/ "./node_modules/@emotion/core/node_modules/@emotion/utils/dist/utils.browser.esm.js":
false,

/***/ "./node_modules/@emotion/css/dist/css.browser.esm.js":
false,

/***/ "./node_modules/@emotion/css/node_modules/@emotion/memoize/dist/memoize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/css/node_modules/@emotion/serialize/dist/serialize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/hash/dist/hash.browser.esm.js":
false,

/***/ "./node_modules/@emotion/is-prop-valid/dist/is-prop-valid.browser.esm.js":
false,

/***/ "./node_modules/@emotion/is-prop-valid/node_modules/@emotion/memoize/dist/memoize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/memoize/dist/emotion-memoize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/react/dist/emotion-element-99289b21.browser.esm.js":
false,

/***/ "./node_modules/@emotion/react/dist/emotion-react.browser.esm.js":
false,

/***/ "./node_modules/@emotion/react/isolated-hoist-non-react-statics-do-not-use-this-in-your-code/dist/emotion-react-isolated-hoist-non-react-statics-do-not-use-this-in-your-code.browser.esm.js":
false,

/***/ "./node_modules/@emotion/react/node_modules/@babel/runtime/helpers/esm/extends.js":
false,

/***/ "./node_modules/@emotion/react/node_modules/@babel/runtime/helpers/extends.js":
false,

/***/ "./node_modules/@emotion/serialize/dist/emotion-serialize.browser.esm.js":
false,

/***/ "./node_modules/@emotion/sheet/dist/emotion-sheet.browser.esm.js":
false,

/***/ "./node_modules/@emotion/stylis/dist/stylis.browser.esm.js":
false,

/***/ "./node_modules/@emotion/unitless/dist/unitless.browser.esm.js":
false,

/***/ "./node_modules/@emotion/utils/dist/emotion-utils.browser.esm.js":
false,

/***/ "./node_modules/@emotion/weak-memoize/dist/weak-memoize.browser.esm.js":
false,

/***/ "./node_modules/@hypnosphi/create-react-context/lib/implementation.js":
false,

/***/ "./node_modules/@hypnosphi/create-react-context/lib/index.js":
false,

/***/ "./node_modules/@popperjs/core/lib/createPopper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/contains.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getBoundingClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getClippingRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getCompositeRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getComputedStyle.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getDocumentRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getHTMLElementScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getLayoutRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getNodeScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getOffsetParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getParentNode.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getViewportRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScroll.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/getWindowScrollBarX.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/instanceOf.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isScrollParent.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/isTableElement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/dom-utils/listScrollParents.js":
false,

/***/ "./node_modules/@popperjs/core/lib/enums.js":
false,

/***/ "./node_modules/@popperjs/core/lib/index.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/applyStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/arrow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/computeStyles.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/eventListeners.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/flip.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/hide.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/index.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/offset.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/popperOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/modifiers/preventOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper-lite.js":
false,

/***/ "./node_modules/@popperjs/core/lib/popper.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeAutoPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/computeOffsets.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/debounce.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/detectOverflow.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/expandToHashMap.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/format.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getAltAxis.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getBasePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getFreshSideObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getMainAxisFromPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositePlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getOppositeVariationPlacement.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/getVariation.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/math.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergeByName.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/mergePaddingObject.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/orderModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/rectToClientRect.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/uniqueBy.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/validateModifiers.js":
false,

/***/ "./node_modules/@popperjs/core/lib/utils/within.js":
false,

/***/ "./node_modules/axios/index.js":
false,

/***/ "./node_modules/axios/lib/adapters/xhr.js":
false,

/***/ "./node_modules/axios/lib/axios.js":
false,

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
false,

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
false,

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
false,

/***/ "./node_modules/axios/lib/core/Axios.js":
false,

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
false,

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
false,

/***/ "./node_modules/axios/lib/core/createError.js":
false,

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
false,

/***/ "./node_modules/axios/lib/core/enhanceError.js":
false,

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
false,

/***/ "./node_modules/axios/lib/core/settle.js":
false,

/***/ "./node_modules/axios/lib/core/transformData.js":
false,

/***/ "./node_modules/axios/lib/defaults.js":
false,

/***/ "./node_modules/axios/lib/helpers/bind.js":
false,

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
false,

/***/ "./node_modules/axios/lib/helpers/cookies.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
false,

/***/ "./node_modules/axios/lib/helpers/isAxiosError.js":
false,

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
false,

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
false,

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
false,

/***/ "./node_modules/axios/lib/helpers/spread.js":
false,

/***/ "./node_modules/axios/lib/helpers/validator.js":
false,

/***/ "./node_modules/axios/lib/utils.js":
false,

/***/ "./node_modules/axios/package.json":
false,

/***/ "./node_modules/bind-event-listener/dist/bind-all.js":
false,

/***/ "./node_modules/bind-event-listener/dist/bind.js":
false,

/***/ "./node_modules/bind-event-listener/dist/index.js":
false,

/***/ "./node_modules/call-bind/callBound.js":
false,

/***/ "./node_modules/call-bind/index.js":
false,

/***/ "./node_modules/classnames/index.js":
false,

/***/ "./node_modules/deep-equal/index.js":
false,

/***/ "./node_modules/define-properties/index.js":
false,

/***/ "./node_modules/dom-helpers/class/addClass.js":
false,

/***/ "./node_modules/dom-helpers/class/hasClass.js":
false,

/***/ "./node_modules/dom-helpers/class/removeClass.js":
false,

/***/ "./node_modules/exenv/index.js":
false,

/***/ "./node_modules/function-bind/implementation.js":
false,

/***/ "./node_modules/function-bind/index.js":
false,

/***/ "./node_modules/get-intrinsic/index.js":
false,

/***/ "./node_modules/gud/index.js":
false,

/***/ "./node_modules/has-symbols/index.js":
false,

/***/ "./node_modules/has-symbols/shams.js":
false,

/***/ "./node_modules/has-tostringtag/shams.js":
false,

/***/ "./node_modules/has/src/index.js":
false,

/***/ "./node_modules/hoist-non-react-statics/dist/hoist-non-react-statics.cjs.js":
false,

/***/ "./node_modules/is-arguments/index.js":
false,

/***/ "./node_modules/is-date-object/index.js":
false,

/***/ "./node_modules/is-regex/index.js":
false,

/***/ "./node_modules/memoize-one/dist/memoize-one.esm.js":
false,

/***/ "./node_modules/next/dist/build/polyfills/object-assign.js":
false,

/***/ "./node_modules/next/dist/client/link.js":
false,

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
false,

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
false,

/***/ "./node_modules/next/dist/client/route-loader.js":
false,

/***/ "./node_modules/next/dist/client/router.js":
false,

/***/ "./node_modules/next/dist/client/use-intersection.js":
false,

/***/ "./node_modules/next/dist/client/with-router.js":
false,

/***/ "./node_modules/next/dist/compiled/webpack/global.js":
false,

/***/ "./node_modules/next/dist/compiled/webpack/harmony-module.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/i18n/normalize-locale-path.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/mitt.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router-context.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/router.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/format-url.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/get-asset-path-from-route.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites-noop.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-regex.js":
false,

/***/ "./node_modules/next/dist/next-server/lib/utils.js":
false,

/***/ "./node_modules/next/dist/next-server/server/denormalize-page-path.js":
false,

/***/ "./node_modules/next/link.js":
false,

/***/ "./node_modules/next/router.js":
false,

/***/ "./node_modules/object-is/implementation.js":
false,

/***/ "./node_modules/object-is/index.js":
false,

/***/ "./node_modules/object-is/polyfill.js":
false,

/***/ "./node_modules/object-is/shim.js":
false,

/***/ "./node_modules/object-keys/implementation.js":
false,

/***/ "./node_modules/object-keys/index.js":
false,

/***/ "./node_modules/object-keys/isArguments.js":
false,

/***/ "./node_modules/popper.js/dist/esm/popper.js":
false,

/***/ "./node_modules/process/browser.js":
false,

/***/ "./node_modules/prop-types/checkPropTypes.js":
false,

/***/ "./node_modules/prop-types/factoryWithTypeCheckers.js":
false,

/***/ "./node_modules/prop-types/index.js":
false,

/***/ "./node_modules/prop-types/lib/ReactPropTypesSecret.js":
false,

/***/ "./node_modules/react-dom/cjs/react-dom.development.js":
false,

/***/ "./node_modules/react-dom/index.js":
false,

/***/ "./node_modules/react-fast-compare/index.js":
false,

/***/ "./node_modules/react-input-autosize/lib/AutosizeInput.js":
false,

/***/ "./node_modules/react-is/cjs/react-is.development.js":
false,

/***/ "./node_modules/react-is/index.js":
false,

/***/ "./node_modules/react-lifecycles-compat/react-lifecycles-compat.es.js":
false,

/***/ "./node_modules/react-popper/lib/esm/Manager.js":
false,

/***/ "./node_modules/react-popper/lib/esm/Popper.js":
false,

/***/ "./node_modules/react-popper/lib/esm/Reference.js":
false,

/***/ "./node_modules/react-popper/lib/esm/index.js":
false,

/***/ "./node_modules/react-popper/lib/esm/utils.js":
false,

/***/ "./node_modules/react-redux/es/components/Context.js":
false,

/***/ "./node_modules/react-redux/es/components/Provider.js":
false,

/***/ "./node_modules/react-redux/es/components/connectAdvanced.js":
false,

/***/ "./node_modules/react-redux/es/connect/connect.js":
false,

/***/ "./node_modules/react-redux/es/connect/mapDispatchToProps.js":
false,

/***/ "./node_modules/react-redux/es/connect/mapStateToProps.js":
false,

/***/ "./node_modules/react-redux/es/connect/mergeProps.js":
false,

/***/ "./node_modules/react-redux/es/connect/selectorFactory.js":
false,

/***/ "./node_modules/react-redux/es/connect/verifySubselectors.js":
false,

/***/ "./node_modules/react-redux/es/connect/wrapMapToProps.js":
false,

/***/ "./node_modules/react-redux/es/exports.js":
false,

/***/ "./node_modules/react-redux/es/hooks/useDispatch.js":
false,

/***/ "./node_modules/react-redux/es/hooks/useReduxContext.js":
false,

/***/ "./node_modules/react-redux/es/hooks/useSelector.js":
false,

/***/ "./node_modules/react-redux/es/hooks/useStore.js":
false,

/***/ "./node_modules/react-redux/es/index.js":
false,

/***/ "./node_modules/react-redux/es/utils/Subscription.js":
false,

/***/ "./node_modules/react-redux/es/utils/batch.js":
false,

/***/ "./node_modules/react-redux/es/utils/bindActionCreators.js":
false,

/***/ "./node_modules/react-redux/es/utils/isPlainObject.js":
false,

/***/ "./node_modules/react-redux/es/utils/reactBatchedUpdates.js":
false,

/***/ "./node_modules/react-redux/es/utils/shallowEqual.js":
false,

/***/ "./node_modules/react-redux/es/utils/useIsomorphicLayoutEffect.js":
false,

/***/ "./node_modules/react-redux/es/utils/verifyPlainObject.js":
false,

/***/ "./node_modules/react-redux/es/utils/warning.js":
false,

/***/ "./node_modules/react-select/dist/Select-dbb12e54.esm.js":
false,

/***/ "./node_modules/react-select/dist/index-4bd03571.esm.js":
false,

/***/ "./node_modules/react-select/dist/react-select.esm.js":
false,

/***/ "./node_modules/react-select/dist/stateManager-845a3300.esm.js":
false,

/***/ "./node_modules/react-transition-group/CSSTransition.js":
false,

/***/ "./node_modules/react-transition-group/ReplaceTransition.js":
false,

/***/ "./node_modules/react-transition-group/Transition.js":
false,

/***/ "./node_modules/react-transition-group/TransitionGroup.js":
false,

/***/ "./node_modules/react-transition-group/index.js":
false,

/***/ "./node_modules/react-transition-group/utils/ChildMapping.js":
false,

/***/ "./node_modules/react-transition-group/utils/PropTypes.js":
false,

/***/ "./node_modules/react/cjs/react-jsx-dev-runtime.development.js":
false,

/***/ "./node_modules/react/cjs/react.development.js":
false,

/***/ "./node_modules/react/index.js":
false,

/***/ "./node_modules/react/jsx-dev-runtime.js":
false,

/***/ "./node_modules/reactstrap/es/Alert.js":
false,

/***/ "./node_modules/reactstrap/es/Badge.js":
false,

/***/ "./node_modules/reactstrap/es/Breadcrumb.js":
false,

/***/ "./node_modules/reactstrap/es/BreadcrumbItem.js":
false,

/***/ "./node_modules/reactstrap/es/Button.js":
false,

/***/ "./node_modules/reactstrap/es/ButtonDropdown.js":
false,

/***/ "./node_modules/reactstrap/es/ButtonGroup.js":
false,

/***/ "./node_modules/reactstrap/es/ButtonToggle.js":
false,

/***/ "./node_modules/reactstrap/es/ButtonToolbar.js":
false,

/***/ "./node_modules/reactstrap/es/Card.js":
false,

/***/ "./node_modules/reactstrap/es/CardBody.js":
false,

/***/ "./node_modules/reactstrap/es/CardColumns.js":
false,

/***/ "./node_modules/reactstrap/es/CardDeck.js":
false,

/***/ "./node_modules/reactstrap/es/CardFooter.js":
false,

/***/ "./node_modules/reactstrap/es/CardGroup.js":
false,

/***/ "./node_modules/reactstrap/es/CardHeader.js":
false,

/***/ "./node_modules/reactstrap/es/CardImg.js":
false,

/***/ "./node_modules/reactstrap/es/CardImgOverlay.js":
false,

/***/ "./node_modules/reactstrap/es/CardLink.js":
false,

/***/ "./node_modules/reactstrap/es/CardSubtitle.js":
false,

/***/ "./node_modules/reactstrap/es/CardText.js":
false,

/***/ "./node_modules/reactstrap/es/CardTitle.js":
false,

/***/ "./node_modules/reactstrap/es/Carousel.js":
false,

/***/ "./node_modules/reactstrap/es/CarouselCaption.js":
false,

/***/ "./node_modules/reactstrap/es/CarouselControl.js":
false,

/***/ "./node_modules/reactstrap/es/CarouselIndicators.js":
false,

/***/ "./node_modules/reactstrap/es/CarouselItem.js":
false,

/***/ "./node_modules/reactstrap/es/Col.js":
false,

/***/ "./node_modules/reactstrap/es/Collapse.js":
false,

/***/ "./node_modules/reactstrap/es/Container.js":
false,

/***/ "./node_modules/reactstrap/es/CustomFileInput.js":
false,

/***/ "./node_modules/reactstrap/es/CustomInput.js":
false,

/***/ "./node_modules/reactstrap/es/Dropdown.js":
false,

/***/ "./node_modules/reactstrap/es/DropdownContext.js":
false,

/***/ "./node_modules/reactstrap/es/DropdownItem.js":
false,

/***/ "./node_modules/reactstrap/es/DropdownMenu.js":
false,

/***/ "./node_modules/reactstrap/es/DropdownToggle.js":
false,

/***/ "./node_modules/reactstrap/es/Fade.js":
false,

/***/ "./node_modules/reactstrap/es/Form.js":
false,

/***/ "./node_modules/reactstrap/es/FormFeedback.js":
false,

/***/ "./node_modules/reactstrap/es/FormGroup.js":
false,

/***/ "./node_modules/reactstrap/es/FormText.js":
false,

/***/ "./node_modules/reactstrap/es/Input.js":
false,

/***/ "./node_modules/reactstrap/es/InputGroup.js":
false,

/***/ "./node_modules/reactstrap/es/InputGroupAddon.js":
false,

/***/ "./node_modules/reactstrap/es/InputGroupButtonDropdown.js":
false,

/***/ "./node_modules/reactstrap/es/InputGroupText.js":
false,

/***/ "./node_modules/reactstrap/es/Jumbotron.js":
false,

/***/ "./node_modules/reactstrap/es/Label.js":
false,

/***/ "./node_modules/reactstrap/es/List.js":
false,

/***/ "./node_modules/reactstrap/es/ListGroup.js":
false,

/***/ "./node_modules/reactstrap/es/ListGroupItem.js":
false,

/***/ "./node_modules/reactstrap/es/ListGroupItemHeading.js":
false,

/***/ "./node_modules/reactstrap/es/ListGroupItemText.js":
false,

/***/ "./node_modules/reactstrap/es/ListInlineItem.js":
false,

/***/ "./node_modules/reactstrap/es/Media.js":
false,

/***/ "./node_modules/reactstrap/es/Modal.js":
false,

/***/ "./node_modules/reactstrap/es/ModalBody.js":
false,

/***/ "./node_modules/reactstrap/es/ModalFooter.js":
false,

/***/ "./node_modules/reactstrap/es/ModalHeader.js":
false,

/***/ "./node_modules/reactstrap/es/Nav.js":
false,

/***/ "./node_modules/reactstrap/es/NavItem.js":
false,

/***/ "./node_modules/reactstrap/es/NavLink.js":
false,

/***/ "./node_modules/reactstrap/es/Navbar.js":
false,

/***/ "./node_modules/reactstrap/es/NavbarBrand.js":
false,

/***/ "./node_modules/reactstrap/es/NavbarText.js":
false,

/***/ "./node_modules/reactstrap/es/NavbarToggler.js":
false,

/***/ "./node_modules/reactstrap/es/Pagination.js":
false,

/***/ "./node_modules/reactstrap/es/PaginationItem.js":
false,

/***/ "./node_modules/reactstrap/es/PaginationLink.js":
false,

/***/ "./node_modules/reactstrap/es/Popover.js":
false,

/***/ "./node_modules/reactstrap/es/PopoverBody.js":
false,

/***/ "./node_modules/reactstrap/es/PopoverHeader.js":
false,

/***/ "./node_modules/reactstrap/es/PopperContent.js":
false,

/***/ "./node_modules/reactstrap/es/PopperTargetHelper.js":
false,

/***/ "./node_modules/reactstrap/es/Portal.js":
false,

/***/ "./node_modules/reactstrap/es/Progress.js":
false,

/***/ "./node_modules/reactstrap/es/Row.js":
false,

/***/ "./node_modules/reactstrap/es/Spinner.js":
false,

/***/ "./node_modules/reactstrap/es/TabContent.js":
false,

/***/ "./node_modules/reactstrap/es/TabContext.js":
false,

/***/ "./node_modules/reactstrap/es/TabPane.js":
false,

/***/ "./node_modules/reactstrap/es/Table.js":
false,

/***/ "./node_modules/reactstrap/es/Toast.js":
false,

/***/ "./node_modules/reactstrap/es/ToastBody.js":
false,

/***/ "./node_modules/reactstrap/es/ToastHeader.js":
false,

/***/ "./node_modules/reactstrap/es/Tooltip.js":
false,

/***/ "./node_modules/reactstrap/es/TooltipPopoverWrapper.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledAlert.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledButtonDropdown.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledCarousel.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledCollapse.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledDropdown.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledPopover.js":
false,

/***/ "./node_modules/reactstrap/es/UncontrolledTooltip.js":
false,

/***/ "./node_modules/reactstrap/es/index.js":
false,

/***/ "./node_modules/reactstrap/es/polyfill.js":
false,

/***/ "./node_modules/reactstrap/es/utils.js":
false,

/***/ "./node_modules/regenerator-runtime/runtime.js":
false,

/***/ "./node_modules/regexp.prototype.flags/implementation.js":
false,

/***/ "./node_modules/regexp.prototype.flags/index.js":
false,

/***/ "./node_modules/regexp.prototype.flags/polyfill.js":
false,

/***/ "./node_modules/regexp.prototype.flags/shim.js":
false,

/***/ "./node_modules/scheduler/cjs/scheduler-tracing.development.js":
false,

/***/ "./node_modules/scheduler/cjs/scheduler.development.js":
false,

/***/ "./node_modules/scheduler/index.js":
false,

/***/ "./node_modules/scheduler/tracing.js":
false,

/***/ "./node_modules/shallowequal/index.js":
false,

/***/ "./node_modules/styled-components/dist/styled-components.browser.esm.js":
false,

/***/ "./node_modules/use-memo-one/dist/use-memo-one.esm.js":
false,

/***/ "./node_modules/warning/warning.js":
false,

/***/ "./pages/admin/AddFood.js":
/*!********************************!*\
  !*** ./pages/admin/AddFood.js ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module) {

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/module.js */ "./node_modules/next/dist/compiled/webpack/module.js")(module)))

/***/ }),

/***/ "./routes.js":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hZG1pbi9BZGRGb29kLjRhMmE0YmRmMGY1MzVhOTNkZWJkLmhvdC11cGRhdGUuanMiLCJzb3VyY2VSb290IjoiIn0=