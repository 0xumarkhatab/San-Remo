webpackHotUpdate_N_E("pages/admin/AddFood",{

/***/ "./pages/admin/AddFood.js":
/*!********************************!*\
  !*** ./pages/admin/AddFood.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/Headers/SimpleHeader */ "./components/Headers/SimpleHeader.js");
/* harmony import */ var _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../layouts/Admin */ "./layouts/Admin.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuSingle */ "./components/SelectMenu/SelectMenuSingle.jsx");
/* harmony import */ var _components_SelectMenu_SelectMenuMultiple__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuMultiple */ "./components/SelectMenu/SelectMenuMultiple.jsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../API_WORK/api */ "./API_WORK/api.js");






var _jsxFileName = "E:\\admin\\pages\\admin\\AddFood.js",
    _s = $RefreshSig$();









 // layout for this page

var title, category, sizes, description, price;

function addFood(_ref) {
  _s();

  var _this = this,
      _jsxDEV2,
      _jsxDEV3;

  var item = _ref.item;
  console.log("existing Food Recieved", item);

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      showSizeDiv = _useState[0],
      setShowSizeDiv = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      prices = _useState2[0],
      setPrices = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.title : ""),
      title = _useState3[0],
      setTitle = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.category : ""),
      category = _useState4[0],
      setCategory = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.alleries : []),
      allergies = _useState5[0],
      setAllergies = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.description : ""),
      description = _useState6[0],
      setDescription = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.url : ""),
      imageUrl = _useState7[0],
      setImageUrl = _useState7[1];

  var _useState8 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      isextras = _useState8[0],
      setIsextras = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      sizes = _useState9[0],
      setSizes = _useState9[1];

  var _useState10 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentSize = _useState10[0],
      setCurrentSize = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentPrice = _useState11[0],
      setCurrentPrice = _useState11[1];

  var foods = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.FOODS;
  });
  var categories = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.CATEGORIES;
  });
  console.log(Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state;
  }));
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"])();

  function Submitter(e) {
    e.preventDefault();
    sizes.map(function (size, index) {
      console.log(document.getElementById("input-price".concat(index + 1)).value);
      prices.push(document.getElementById("input-price".concat(index + 1)).value);
    });
    var price = document.getElementById("input-price").value;

    if (sizes.length === 0) {
      sizes.push({
        price: price,
        size: null
      });
    }

    var food = {
      foodNo: (foods !== null && foods !== void 0 && foods.length ? length : 0) + 1,
      title: title,
      allergies: allergies,
      description: description,
      extras: isextras,
      // imageUrl: imageUrl,
      category: category,
      sizes: sizes
    };
    _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].post("/food", food);
    console.log("one product ", food);

    Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.mark(function _callee() {
      return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].get("/food").then(function (c) {
                return console.log(c.data);
              });

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))(); // console.log(food);

  }

  var onCategoryChange = function onCategoryChange(e) {
    setCategory(e.value);
  };

  var onPriceChanger = function onPriceChanger(e) {
    prices.push(Number(e.target.value));
    setPrices(prices);
  };

  var onTitleChanger = function onTitleChanger(e) {
    setTitle(e.target.value);
  };

  var onImageUrlChange = function onImageUrlChange(e) {
    setImageUrl(e.target.value);
  };

  var onDescriptionChanger = function onDescriptionChanger(e) {
    setDescription(e.target.value);
  };

  var sizeAdder = function sizeAdder(e) {
    var s = sizes;
    s.push({
      price: currentPrice,
      size: currentSize
    });
    console.log("size added ", s);
    setSizes(s);
  };

  var onAllergiesChanger = function onAllergiesChanger(e) {
    var arr = "";
    arr = arr.concat("" + e.target.value);
    arr = arr.split(",", 1000);
    setAllergies(arr);
  };

  var onextrasChanger = function onextrasChanger(e) {
    // console.log(e.target.checked);
    setIsextras(e.target.checked);
  };

  var categoryOptions = categories.map(function (cat) {
    return {
      value: cat.title,
      label: cat.title
    };
  });
  var sizesOptions = [{
    value: "sm",
    label: "Small"
  }, {
    value: "md",
    label: "Medium"
  }, {
    value: "lg",
    label: "Large"
  }, {
    value: "xlg",
    label: "Extra Large"
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 145,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Container"], {
      className: "mt-7",
      fluid: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
          className: "order-xl-1",
          xl: "8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Card"], {
            className: "bg-secondary shadow",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardHeader"], {
              className: "bg-white border-0"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 151,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardBody"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                className: "align-items-center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  xs: "8",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                    className: "mb-0",
                    children: [item ? "Edit Existing Food" : "Add New Food", " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 155,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 154,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  className: "text-right",
                  xs: "4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
                    exact: true,
                    href: "/admin/manageFoods",
                    onClick: function onClick(e) {
                      return Submitter(e);
                    },
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                      onClick: function onClick(e) {
                        return Submitter(e);
                      },
                      color: item ? "success" : "primary",
                      className: "pt3 pb-3 ",
                      children: item ? "Save Changes" : "Add"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 165,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 160,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 159,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 153,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Form"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mt-2 mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 179,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 178,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 177,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 176,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                        children: "Click On Every Field at least Once"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 187,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 186,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 185,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 184,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 195,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 194,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 193,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 192,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Title"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 204,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-title",
                          placeholder: "pizza , speghati etc....",
                          autoFocus: true,
                          type: "text",
                          defaultValue: item ? item.title : "",
                          onChange: function onChange(e) {
                            onTitleChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 210,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 203,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 202,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 201,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 200,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-category",
                          children: "Select the Category"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 230,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__["default"], {
                          id: "input-category",
                          options: categoryOptions,
                          defaultValue: item ? item.category : "",
                          onChangeHandler: onCategoryChange
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 236,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 229,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 228,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 227,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 226,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                        className: "p-3 mt-2",
                        color: "primary",
                        onClick: function onClick(e) {
                          setShowSizeDiv(true);
                        },
                        children: "+ Manage Size"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 270,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 269,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 268,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 267,
                  columnNumber: 19
                }, this), showSizeDiv ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "sizesDiv",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizeSize",
                            children: "Size"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 289,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizesSize",
                            placeholder: "32x45cm",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentSize(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 295,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 288,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 287,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 286,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 285,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizePrice",
                            children: "Price"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 313,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizePrice",
                            placeholder: "4.33\u20AC",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentPrice(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 319,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 312,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 311,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 310,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 309,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                          className: "p-3 mt-2",
                          color: "primary",
                          onClick: function onClick(e) {
                            setShowSizeDiv(false);
                            sizeAdder(e);
                          },
                          children: "ADD"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 336,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 335,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 334,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 333,
                    columnNumber: 23
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 284,
                  columnNumber: 21
                }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: sizes.map(function (s) {
                        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "text-center ml-4 mr-4 mt-2 d-flex justify-content-between",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                            color: "danger",
                            children: "Delete"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 361,
                            columnNumber: 29
                          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: [s.price, "\u20AC"]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 362,
                            columnNumber: 29
                          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
                            children: s.size
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 363,
                            columnNumber: 29
                          }, _this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 360,
                          columnNumber: 29
                        }, _this);
                      })
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 356,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 355,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 354,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Image Url"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 383,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-imageUrl",
                          placeholder: "www.example.com/image.png",
                          type: "text",
                          defaultValue: item ? item.url : "",
                          onChange: function onChange(e, v) {
                            return onImageUrlChange(e, v);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 389,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 382,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 381,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 380,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 379,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-price",
                          children: "Price"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 406,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-price",
                          placeholder: "4.56\u20AC",
                          defaultValue: item ? item.price : "",
                          onChange: function onChange(e, v) {
                            return onPriceChanger(e, v);
                          },
                          type: "text"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 412,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 405,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 404,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 403,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 402,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-allergies",
                          children: "Allergies"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 428,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV2 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-allergies",
                          placeholder: "Allergies i,i,1,2",
                          type: "text"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "defaultValue", item ? item.allergies : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "onChange", function onChange(e, v) {
                          return onAllergiesChanger(e, v);
                        }), _jsxDEV2), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 434,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 427,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 426,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 425,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 424,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Description"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 451,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV3 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-address",
                          placeholder: "Description"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "defaultValue", item ? item.description : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "type", "textarea"), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "rows", 5), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "onChange", function onChange(e) {
                          onDescriptionChanger(e);
                        }), _jsxDEV3), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 457,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 450,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 449,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 448,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 447,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          type: "checkbox",
                          onChange: function onChange(e) {
                            onextrasChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 477,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                          children: "extras Included?"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 483,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 476,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 475,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 474,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 473,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 175,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 152,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 149,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 148,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 147,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(addFood, "zeK8nBsDwmkHoXI2DEH0KRCbtF4=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"]];
});

addFood.layout = _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__["default"];
/* harmony default export */ __webpack_exports__["default"] = (addFood);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYWRtaW4vQWRkRm9vZC5qcyJdLCJuYW1lcyI6WyJ0aXRsZSIsImNhdGVnb3J5Iiwic2l6ZXMiLCJkZXNjcmlwdGlvbiIsInByaWNlIiwiYWRkRm9vZCIsIml0ZW0iLCJjb25zb2xlIiwibG9nIiwidXNlU3RhdGUiLCJzaG93U2l6ZURpdiIsInNldFNob3dTaXplRGl2IiwicHJpY2VzIiwic2V0UHJpY2VzIiwic2V0VGl0bGUiLCJzZXRDYXRlZ29yeSIsImFsbGVyaWVzIiwiYWxsZXJnaWVzIiwic2V0QWxsZXJnaWVzIiwic2V0RGVzY3JpcHRpb24iLCJ1cmwiLCJpbWFnZVVybCIsInNldEltYWdlVXJsIiwiaXNleHRyYXMiLCJzZXRJc2V4dHJhcyIsInNldFNpemVzIiwiY3VycmVudFNpemUiLCJzZXRDdXJyZW50U2l6ZSIsImN1cnJlbnRQcmljZSIsInNldEN1cnJlbnRQcmljZSIsImZvb2RzIiwidXNlU2VsZWN0b3IiLCJzdGF0ZSIsIkZPT0RTIiwiY2F0ZWdvcmllcyIsIkNBVEVHT1JJRVMiLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwiU3VibWl0dGVyIiwiZSIsInByZXZlbnREZWZhdWx0IiwibWFwIiwic2l6ZSIsImluZGV4IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInZhbHVlIiwicHVzaCIsImxlbmd0aCIsImZvb2QiLCJmb29kTm8iLCJleHRyYXMiLCJhcGkiLCJwb3N0IiwiZ2V0IiwidGhlbiIsImMiLCJkYXRhIiwib25DYXRlZ29yeUNoYW5nZSIsIm9uUHJpY2VDaGFuZ2VyIiwiTnVtYmVyIiwidGFyZ2V0Iiwib25UaXRsZUNoYW5nZXIiLCJvbkltYWdlVXJsQ2hhbmdlIiwib25EZXNjcmlwdGlvbkNoYW5nZXIiLCJzaXplQWRkZXIiLCJzIiwib25BbGxlcmdpZXNDaGFuZ2VyIiwiYXJyIiwiY29uY2F0Iiwic3BsaXQiLCJvbmV4dHJhc0NoYW5nZXIiLCJjaGVja2VkIiwiY2F0ZWdvcnlPcHRpb25zIiwiY2F0IiwibGFiZWwiLCJzaXplc09wdGlvbnMiLCJ2IiwibGF5b3V0IiwiQWRtaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFFQTtBQUVBO0FBYUE7QUFDQTtBQUNBO0NBR0E7O0FBQ0EsSUFBSUEsS0FBSixFQUFXQyxRQUFYLEVBQXFCQyxLQUFyQixFQUE0QkMsV0FBNUIsRUFBeUNDLEtBQXpDOztBQUVBLFNBQVNDLE9BQVQsT0FBMkI7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUEsTUFBUkMsSUFBUSxRQUFSQSxJQUFRO0FBQ3pCQyxTQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBWixFQUFzQ0YsSUFBdEM7O0FBRHlCLGtCQUVhRyxzREFBUSxDQUFDLEtBQUQsQ0FGckI7QUFBQSxNQUVsQkMsV0FGa0I7QUFBQSxNQUVMQyxjQUZLOztBQUFBLG1CQUlHRixzREFBUSxDQUFDLEVBQUQsQ0FKWDtBQUFBLE1BSWxCRyxNQUprQjtBQUFBLE1BSVZDLFNBSlU7O0FBQUEsbUJBS0NKLHNEQUFRLENBQUNILElBQUksR0FBR0EsSUFBSSxDQUFDTixLQUFSLEdBQWdCLEVBQXJCLENBTFQ7QUFBQSxNQUtsQkEsS0FMa0I7QUFBQSxNQUtYYyxRQUxXOztBQUFBLG1CQU1PTCxzREFBUSxDQUFDSCxJQUFJLEdBQUdBLElBQUksQ0FBQ0wsUUFBUixHQUFtQixFQUF4QixDQU5mO0FBQUEsTUFNbEJBLFFBTmtCO0FBQUEsTUFNUmMsV0FOUTs7QUFBQSxtQkFPU04sc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNVLFFBQVIsR0FBbUIsRUFBeEIsQ0FQakI7QUFBQSxNQU9sQkMsU0FQa0I7QUFBQSxNQU9QQyxZQVBPOztBQUFBLG1CQVFhVCxzREFBUSxDQUFDSCxJQUFJLEdBQUdBLElBQUksQ0FBQ0gsV0FBUixHQUFzQixFQUEzQixDQVJyQjtBQUFBLE1BUWxCQSxXQVJrQjtBQUFBLE1BUUxnQixjQVJLOztBQUFBLG1CQVNPVixzREFBUSxDQUFDSCxJQUFJLEdBQUdBLElBQUksQ0FBQ2MsR0FBUixHQUFjLEVBQW5CLENBVGY7QUFBQSxNQVNsQkMsUUFUa0I7QUFBQSxNQVNSQyxXQVRROztBQUFBLG1CQVVPYixzREFBUSxDQUFDLEtBQUQsQ0FWZjtBQUFBLE1BVWxCYyxRQVZrQjtBQUFBLE1BVVJDLFdBVlE7O0FBQUEsbUJBWUNmLHNEQUFRLENBQUMsRUFBRCxDQVpUO0FBQUEsTUFZbEJQLEtBWmtCO0FBQUEsTUFZWHVCLFFBWlc7O0FBQUEsb0JBYWFoQixzREFBUSxDQUFDLEVBQUQsQ0FickI7QUFBQSxNQWFsQmlCLFdBYmtCO0FBQUEsTUFhTEMsY0FiSzs7QUFBQSxvQkFjZWxCLHNEQUFRLENBQUMsRUFBRCxDQWR2QjtBQUFBLE1BY2xCbUIsWUFka0I7QUFBQSxNQWNKQyxlQWRJOztBQWdCekIsTUFBTUMsS0FBSyxHQUFHQyxnRUFBVyxDQUFDLFVBQUNDLEtBQUQ7QUFBQSxXQUFXQSxLQUFLLENBQUNDLEtBQWpCO0FBQUEsR0FBRCxDQUF6QjtBQUNBLE1BQU1DLFVBQVUsR0FBR0gsZ0VBQVcsQ0FBQyxVQUFDQyxLQUFEO0FBQUEsV0FBV0EsS0FBSyxDQUFDRyxVQUFqQjtBQUFBLEdBQUQsQ0FBOUI7QUFDQTVCLFNBQU8sQ0FBQ0MsR0FBUixDQUFZdUIsZ0VBQVcsQ0FBQyxVQUFDQyxLQUFEO0FBQUEsV0FBV0EsS0FBWDtBQUFBLEdBQUQsQ0FBdkI7QUFFQSxNQUFNSSxRQUFRLEdBQUdDLGdFQUFXLEVBQTVCOztBQUVBLFdBQVNDLFNBQVQsQ0FBbUJDLENBQW5CLEVBQXNCO0FBQ3BCQSxLQUFDLENBQUNDLGNBQUY7QUFFQXRDLFNBQUssQ0FBQ3VDLEdBQU4sQ0FBVSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDekJwQyxhQUFPLENBQUNDLEdBQVIsQ0FBWW9DLFFBQVEsQ0FBQ0MsY0FBVCxzQkFBc0NGLEtBQUssR0FBRyxDQUE5QyxHQUFtREcsS0FBL0Q7QUFDQWxDLFlBQU0sQ0FBQ21DLElBQVAsQ0FBWUgsUUFBUSxDQUFDQyxjQUFULHNCQUFzQ0YsS0FBSyxHQUFHLENBQTlDLEdBQW1ERyxLQUEvRDtBQUNELEtBSEQ7QUFLQSxRQUFJMUMsS0FBSyxHQUFHd0MsUUFBUSxDQUFDQyxjQUFULENBQXdCLGFBQXhCLEVBQXVDQyxLQUFuRDs7QUFDSixRQUFHNUMsS0FBSyxDQUFDOEMsTUFBTixLQUFlLENBQWxCLEVBQW9CO0FBQ2xCOUMsV0FBSyxDQUFDNkMsSUFBTixDQUFXO0FBQ1QzQyxhQUFLLEVBQUNBLEtBREc7QUFFVHNDLFlBQUksRUFBQztBQUZJLE9BQVg7QUFJRDs7QUFDRyxRQUFNTyxJQUFJLEdBQ1I7QUFBS0MsWUFBTSxFQUFFLENBQUNwQixLQUFLLFNBQUwsSUFBQUEsS0FBSyxXQUFMLElBQUFBLEtBQUssQ0FBRWtCLE1BQVAsR0FBZ0JBLE1BQWhCLEdBQXlCLENBQTFCLElBQStCLENBQTVDO0FBQ01oRCxXQUFLLEVBQUVBLEtBRGI7QUFFTWlCLGVBQVMsRUFBRUEsU0FGakI7QUFHTWQsaUJBQVcsRUFBRUEsV0FIbkI7QUFJTWdELFlBQU0sRUFBRTVCLFFBSmQ7QUFLTTtBQUNBdEIsY0FBUSxFQUFFQSxRQU5oQjtBQU9NQyxXQUFLLEVBQUNBO0FBUFosS0FERjtBQVlFa0QsMERBQUcsQ0FBQ0MsSUFBSixDQUFTLE9BQVQsRUFBa0JKLElBQWxCO0FBQ0ExQyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCeUMsSUFBNUI7O0FBRUYsNk5BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ09HLHNEQUFHLENBQUNFLEdBQUosQ0FBUSxPQUFSLEVBQWlCQyxJQUFqQixDQUFzQixVQUFDQyxDQUFEO0FBQUEsdUJBQU9qRCxPQUFPLENBQUNDLEdBQVIsQ0FBWWdELENBQUMsQ0FBQ0MsSUFBZCxDQUFQO0FBQUEsZUFBdEIsQ0FEUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFELEtBOUJvQixDQWtDcEI7O0FBQ0Q7O0FBQ0QsTUFBTUMsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixDQUFDbkIsQ0FBRCxFQUFPO0FBQzlCeEIsZUFBVyxDQUFDd0IsQ0FBQyxDQUFDTyxLQUFILENBQVg7QUFDRCxHQUZEOztBQUdBLE1BQU1hLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ3BCLENBQUQsRUFBTztBQUM1QjNCLFVBQU0sQ0FBQ21DLElBQVAsQ0FBWWEsTUFBTSxDQUFDckIsQ0FBQyxDQUFDc0IsTUFBRixDQUFTZixLQUFWLENBQWxCO0FBQ0FqQyxhQUFTLENBQUNELE1BQUQsQ0FBVDtBQUNELEdBSEQ7O0FBSUEsTUFBTWtELGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ3ZCLENBQUQsRUFBTztBQUM1QnpCLFlBQVEsQ0FBQ3lCLENBQUMsQ0FBQ3NCLE1BQUYsQ0FBU2YsS0FBVixDQUFSO0FBQ0QsR0FGRDs7QUFJQSxNQUFNaUIsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixDQUFDeEIsQ0FBRCxFQUFPO0FBQzlCakIsZUFBVyxDQUFDaUIsQ0FBQyxDQUFDc0IsTUFBRixDQUFTZixLQUFWLENBQVg7QUFDRCxHQUZEOztBQUlBLE1BQU1rQixvQkFBb0IsR0FBRyxTQUF2QkEsb0JBQXVCLENBQUN6QixDQUFELEVBQU87QUFDbENwQixrQkFBYyxDQUFDb0IsQ0FBQyxDQUFDc0IsTUFBRixDQUFTZixLQUFWLENBQWQ7QUFDRCxHQUZEOztBQUlBLE1BQU1tQixTQUFTLEdBQUcsU0FBWkEsU0FBWSxDQUFDMUIsQ0FBRCxFQUFPO0FBQ3ZCLFFBQU0yQixDQUFDLEdBQUdoRSxLQUFWO0FBRUFnRSxLQUFDLENBQUNuQixJQUFGLENBQU87QUFDTDNDLFdBQUssRUFBRXdCLFlBREY7QUFFTGMsVUFBSSxFQUFFaEI7QUFGRCxLQUFQO0FBSUFuQixXQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaLEVBQTJCMEQsQ0FBM0I7QUFFQXpDLFlBQVEsQ0FBQ3lDLENBQUQsQ0FBUjtBQUNELEdBVkQ7O0FBWUEsTUFBTUMsa0JBQWtCLEdBQUcsU0FBckJBLGtCQUFxQixDQUFDNUIsQ0FBRCxFQUFPO0FBQ2hDLFFBQUk2QixHQUFHLEdBQUcsRUFBVjtBQUNBQSxPQUFHLEdBQUdBLEdBQUcsQ0FBQ0MsTUFBSixDQUFXLEtBQUs5QixDQUFDLENBQUNzQixNQUFGLENBQVNmLEtBQXpCLENBQU47QUFDQXNCLE9BQUcsR0FBR0EsR0FBRyxDQUFDRSxLQUFKLENBQVUsR0FBVixFQUFlLElBQWYsQ0FBTjtBQUNBcEQsZ0JBQVksQ0FBQ2tELEdBQUQsQ0FBWjtBQUNELEdBTEQ7O0FBTUEsTUFBTUcsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDaEMsQ0FBRCxFQUFPO0FBQzdCO0FBRUFmLGVBQVcsQ0FBQ2UsQ0FBQyxDQUFDc0IsTUFBRixDQUFTVyxPQUFWLENBQVg7QUFDRCxHQUpEOztBQU1BLE1BQU1DLGVBQWUsR0FBR3ZDLFVBQVUsQ0FBQ08sR0FBWCxDQUFlLFVBQUNpQyxHQUFELEVBQVM7QUFDOUMsV0FBTztBQUNMNUIsV0FBSyxFQUFFNEIsR0FBRyxDQUFDMUUsS0FETjtBQUVMMkUsV0FBSyxFQUFFRCxHQUFHLENBQUMxRTtBQUZOLEtBQVA7QUFJRCxHQUx1QixDQUF4QjtBQU9BLE1BQU00RSxZQUFZLEdBQUcsQ0FDbkI7QUFBRTlCLFNBQUssRUFBRSxJQUFUO0FBQWU2QixTQUFLLEVBQUU7QUFBdEIsR0FEbUIsRUFFbkI7QUFBRTdCLFNBQUssRUFBRSxJQUFUO0FBQWU2QixTQUFLLEVBQUU7QUFBdEIsR0FGbUIsRUFHbkI7QUFBRTdCLFNBQUssRUFBRSxJQUFUO0FBQWU2QixTQUFLLEVBQUU7QUFBdEIsR0FIbUIsRUFJbkI7QUFBRTdCLFNBQUssRUFBRSxLQUFUO0FBQWdCNkIsU0FBSyxFQUFFO0FBQXZCLEdBSm1CLENBQXJCO0FBT0Esc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyx3RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFHRSxxRUFBQyxvREFBRDtBQUFXLGVBQVMsRUFBQyxNQUFyQjtBQUE0QixXQUFLLE1BQWpDO0FBQUEsNkJBQ0UscUVBQUMsOENBQUQ7QUFBQSwrQkFDRSxxRUFBQyw4Q0FBRDtBQUFLLG1CQUFTLEVBQUMsWUFBZjtBQUE0QixZQUFFLEVBQUMsR0FBL0I7QUFBQSxpQ0FDRSxxRUFBQywrQ0FBRDtBQUFNLHFCQUFTLEVBQUMscUJBQWhCO0FBQUEsb0NBQ0UscUVBQUMscURBQUQ7QUFBWSx1QkFBUyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREYsZUFFRSxxRUFBQyxtREFBRDtBQUFBLHNDQUNFLHFFQUFDLDhDQUFEO0FBQUsseUJBQVMsRUFBQyxvQkFBZjtBQUFBLHdDQUNFLHFFQUFDLDhDQUFEO0FBQUssb0JBQUUsRUFBQyxHQUFSO0FBQUEseUNBQ0U7QUFBSSw2QkFBUyxFQUFDLE1BQWQ7QUFBQSwrQkFDR3JFLElBQUksR0FBRyxvQkFBSCxHQUEwQixjQURqQyxFQUNpRCxHQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBTUUscUVBQUMsOENBQUQ7QUFBSywyQkFBUyxFQUFDLFlBQWY7QUFBNEIsb0JBQUUsRUFBQyxHQUEvQjtBQUFBLHlDQUNFLHFFQUFDLGdEQUFEO0FBQ0UseUJBQUssTUFEUDtBQUVFLHdCQUFJLEVBQUMsb0JBRlA7QUFHRSwyQkFBTyxFQUFFLGlCQUFDaUMsQ0FBRDtBQUFBLDZCQUFPRCxTQUFTLENBQUNDLENBQUQsQ0FBaEI7QUFBQSxxQkFIWDtBQUFBLDJDQUtFLHFFQUFDLGlEQUFEO0FBQ0UsNkJBQU8sRUFBRSxpQkFBQ0EsQ0FBRDtBQUFBLCtCQUFPRCxTQUFTLENBQUNDLENBQUQsQ0FBaEI7QUFBQSx1QkFEWDtBQUVFLDJCQUFLLEVBQUVqQyxJQUFJLEdBQUcsU0FBSCxHQUFlLFNBRjVCO0FBR0UsK0JBQVMsRUFBQyxXQUhaO0FBQUEsZ0NBS0dBLElBQUksR0FBRyxjQUFILEdBQW9CO0FBTDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREYsZUF1QkUscUVBQUMsK0NBQUQ7QUFBQSx3Q0FDRTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRTtBQUFJLGlDQUFTLEVBQUM7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURGLGVBU0U7QUFBSywyQkFBUyxFQUFDLHFCQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVRGLGVBaUJFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFO0FBQUksaUNBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBakJGLGVBeUJFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxlQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsNEJBQUUsRUFBQyxhQUZMO0FBR0UscUNBQVcsRUFBQywwQkFIZDtBQUlFLG1DQUFTLE1BSlg7QUFLRSw4QkFBSSxFQUFDLE1BTFA7QUFNRSxzQ0FBWSxFQUFFQSxJQUFJLEdBQUdBLElBQUksQ0FBQ04sS0FBUixHQUFnQixFQU5wQztBQU9FLGtDQUFRLEVBQUUsa0JBQUN1QyxDQUFELEVBQU87QUFDZnVCLDBDQUFjLENBQUN2QixDQUFELENBQWQ7QUFDRDtBQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXpCRixlQW1ERTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFO0FBQ0UsbUNBQVMsRUFBQyxvQkFEWjtBQUVFLGlDQUFPLEVBQUMsZ0JBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQywrRUFBRDtBQUNFLDRCQUFFLEVBQUMsZ0JBREw7QUFFRSxpQ0FBTyxFQUFFa0MsZUFGWDtBQUdFLHNDQUFZLEVBQUVuRSxJQUFJLEdBQUdBLElBQUksQ0FBQ0wsUUFBUixHQUFtQixFQUh2QztBQUlFLHlDQUFlLEVBQUV5RDtBQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuREYsZUE0RkU7QUFBSywyQkFBUyxFQUFDLFVBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsaURBQUQ7QUFDRSxpQ0FBUyxFQUFDLFVBRFo7QUFFRSw2QkFBSyxFQUFDLFNBRlI7QUFHRSwrQkFBTyxFQUFFLGlCQUFDbkIsQ0FBRCxFQUFPO0FBQ2Q1Qix3Q0FBYyxDQUFDLElBQUQsQ0FBZDtBQUNELHlCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTVGRixFQTRHR0QsV0FBVyxnQkFDVjtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLDBDQUNFO0FBQUssNkJBQVMsRUFBQyxVQUFmO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBQSw2Q0FDRSxxRUFBQyw4Q0FBRDtBQUFLLDBCQUFFLEVBQUMsSUFBUjtBQUFBLCtDQUNFLHFFQUFDLG9EQUFEO0FBQUEsa0RBQ0U7QUFDRSxxQ0FBUyxFQUFDLG9CQURaO0FBRUUsbUNBQU8sRUFBQyxnQkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FERixlQU9FLHFFQUFDLGdEQUFEO0FBQ0UscUNBQVMsRUFBQywwQkFEWjtBQUVFLDhCQUFFLEVBQUMsaUJBRkw7QUFHRSx1Q0FBVyxFQUFDLFNBSGQ7QUFJRSxnQ0FBSSxFQUFDLE1BSlA7QUFLRSxvQ0FBUSxFQUFFLGtCQUFDNkIsQ0FBRCxFQUFPO0FBQ2ZoQyxxQ0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QitCLENBQUMsQ0FBQ3NCLE1BQUYsQ0FBU2YsS0FBbEM7QUFDQW5CLDRDQUFjLENBQUNZLENBQUMsQ0FBQ3NCLE1BQUYsQ0FBU2YsS0FBVixDQUFkO0FBQ0Q7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFERixlQXlCRTtBQUFLLDZCQUFTLEVBQUMsVUFBZjtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUEsNkNBQ0UscUVBQUMsOENBQUQ7QUFBSywwQkFBRSxFQUFDLElBQVI7QUFBQSwrQ0FDRSxxRUFBQyxvREFBRDtBQUFBLGtEQUNFO0FBQ0UscUNBQVMsRUFBQyxvQkFEWjtBQUVFLG1DQUFPLEVBQUMsaUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLHFDQUFTLEVBQUMsMEJBRFo7QUFFRSw4QkFBRSxFQUFDLGlCQUZMO0FBR0UsdUNBQVcsRUFBQyxZQUhkO0FBSUUsZ0NBQUksRUFBQyxNQUpQO0FBS0Usb0NBQVEsRUFBRSxrQkFBQ1AsQ0FBRCxFQUFPO0FBQ2ZoQyxxQ0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QitCLENBQUMsQ0FBQ3NCLE1BQUYsQ0FBU2YsS0FBbEM7QUFDQWpCLDZDQUFlLENBQUNVLENBQUMsQ0FBQ3NCLE1BQUYsQ0FBU2YsS0FBVixDQUFmO0FBQ0Q7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkF6QkYsZUFpREU7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsaURBQUQ7QUFDRSxtQ0FBUyxFQUFDLFVBRFo7QUFFRSwrQkFBSyxFQUFDLFNBRlI7QUFHRSxpQ0FBTyxFQUFFLGlCQUFDUCxDQUFELEVBQU87QUFDZDVCLDBDQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0FzRCxxQ0FBUyxDQUFDMUIsQ0FBRCxDQUFUO0FBQ0QsMkJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFEVSxHQW9FVixFQWhMSixlQW1MRTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSxnQ0FFRXJDLEtBQUssQ0FBQ3VDLEdBQU4sQ0FBVSxVQUFBeUIsQ0FBQyxFQUFFO0FBQ1gsNENBQ0U7QUFBSyxtQ0FBUyxFQUFDLDJEQUFmO0FBQUEsa0RBQ0EscUVBQUMsaURBQUQ7QUFBUyxpQ0FBSyxFQUFDLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREEsZUFFQTtBQUFBLHVDQUFJQSxDQUFDLENBQUM5RCxLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FGQSxlQUdBO0FBQUEsc0NBQUk4RCxDQUFDLENBQUN4QjtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBSEE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURGO0FBUUQsdUJBVEQ7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbkxGLGVBNE1FO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxlQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsNEJBQUUsRUFBQyxnQkFGTDtBQUdFLHFDQUFXLEVBQUMsMkJBSGQ7QUFJRSw4QkFBSSxFQUFDLE1BSlA7QUFLRSxzQ0FBWSxFQUFFcEMsSUFBSSxHQUFHQSxJQUFJLENBQUNjLEdBQVIsR0FBYyxFQUxsQztBQU1FLGtDQUFRLEVBQUUsa0JBQUNtQixDQUFELEVBQUlzQyxDQUFKO0FBQUEsbUNBQVVkLGdCQUFnQixDQUFDeEIsQ0FBRCxFQUFJc0MsQ0FBSixDQUExQjtBQUFBO0FBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBNU1GLGVBbU9FO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxhQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsNEJBQUUsRUFBQyxhQUZMO0FBR0UscUNBQVcsRUFBQyxZQUhkO0FBSUUsc0NBQVksRUFBRXZFLElBQUksR0FBR0EsSUFBSSxDQUFDRixLQUFSLEdBQWdCLEVBSnBDO0FBS0Usa0NBQVEsRUFBRSxrQkFBQ21DLENBQUQsRUFBSXNDLENBQUo7QUFBQSxtQ0FBVWxCLGNBQWMsQ0FBQ3BCLENBQUQsRUFBSXNDLENBQUosQ0FBeEI7QUFBQSwyQkFMWjtBQU1FLDhCQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuT0YsZUF5UEU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGlCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsc0NBQVksRUFBQyxFQUZmO0FBR0UsNEJBQUUsRUFBQyxpQkFITDtBQUlFLHFDQUFXLEVBQUMsbUJBSmQ7QUFLRSw4QkFBSSxFQUFDO0FBTFAsbUtBTWdCdkUsSUFBSSxHQUFHQSxJQUFJLENBQUNXLFNBQVIsR0FBb0IsRUFOeEMsdUlBT1ksa0JBQUNzQixDQUFELEVBQUlzQyxDQUFKO0FBQUEsaUNBQVVWLGtCQUFrQixDQUFDNUIsQ0FBRCxFQUFJc0MsQ0FBSixDQUE1QjtBQUFBLHlCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXpQRixlQWdSRTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFO0FBQ0UsbUNBQVMsRUFBQyxvQkFEWjtBQUVFLGlDQUFPLEVBQUMsZUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQU9FLHFFQUFDLGdEQUFEO0FBQ0UsbUNBQVMsRUFBQywwQkFEWjtBQUVFLHNDQUFZLEVBQUMsRUFGZjtBQUdFLDRCQUFFLEVBQUMsZUFITDtBQUlFLHFDQUFXLEVBQUM7QUFKZCxtS0FLZ0J2RSxJQUFJLEdBQUdBLElBQUksQ0FBQ0gsV0FBUixHQUFzQixFQUwxQyxtSUFNTyxVQU5QLG1JQU9RLENBUFIsdUlBUVksa0JBQUNvQyxDQUFELEVBQU87QUFDZnlCLDhDQUFvQixDQUFDekIsQ0FBRCxDQUFwQjtBQUNELHlCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWhSRixlQTBTRTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFLHFFQUFDLGdEQUFEO0FBQ0UsOEJBQUksRUFBQyxVQURQO0FBRUUsa0NBQVEsRUFBRSxrQkFBQ0EsQ0FBRCxFQUFPO0FBQ2ZnQywyQ0FBZSxDQUFDaEMsQ0FBRCxDQUFmO0FBQ0Q7QUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQTFTRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFIRjtBQUFBLGtCQURGO0FBaVdEOztHQXBkUWxDLE87VUFnQk8wQix3RCxFQUNLQSx3RCxFQUNQQSx3RCxFQUVLTSx3RDs7O0FBaWNuQmhDLE9BQU8sQ0FBQ3lFLE1BQVIsR0FBaUJDLHNEQUFqQjtBQUVlMUUsc0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWRtaW4vQWRkRm9vZC4yMmE0MzM2YWQ0MWMxODQ5NGExMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaW1wbGVIZWFkZXIgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvSGVhZGVycy9TaW1wbGVIZWFkZXJcIjtcclxuaW1wb3J0IEFkbWluIGZyb20gXCIuLi8uLi9sYXlvdXRzL0FkbWluXCI7XHJcblxyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBDYXJkLFxyXG4gIENhcmRIZWFkZXIsXHJcbiAgQ2FyZEJvZHksXHJcbiAgRm9ybUdyb3VwLFxyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgQ29udGFpbmVyLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcclxuXHJcbmltcG9ydCBTZWxlY3RNZW51U2luZ2xlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1NlbGVjdE1lbnUvU2VsZWN0TWVudVNpbmdsZVwiO1xyXG5pbXBvcnQgU2VsZWN0TWVudU11bHRpcGxlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1NlbGVjdE1lbnUvU2VsZWN0TWVudU11bHRpcGxlXCI7XHJcbmltcG9ydCB7IHVzZVNlbGVjdG9yLCB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi8uLi9BUElfV09SSy9hcGlcIjtcclxuXHJcbi8vIGxheW91dCBmb3IgdGhpcyBwYWdlXHJcbmxldCB0aXRsZSwgY2F0ZWdvcnksIHNpemVzLCBkZXNjcmlwdGlvbiwgcHJpY2U7XHJcblxyXG5mdW5jdGlvbiBhZGRGb29kKHsgaXRlbSB9KSB7XHJcbiAgY29uc29sZS5sb2coXCJleGlzdGluZyBGb29kIFJlY2lldmVkXCIsIGl0ZW0pO1xyXG4gIGNvbnN0IFtzaG93U2l6ZURpdiwgc2V0U2hvd1NpemVEaXZdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbcHJpY2VzLCBzZXRQcmljZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0udGl0bGUgOiBcIlwiKTtcclxuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLmNhdGVnb3J5IDogXCJcIik7XHJcbiAgY29uc3QgW2FsbGVyZ2llcywgc2V0QWxsZXJnaWVzXSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLmFsbGVyaWVzIDogW10pO1xyXG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0uZGVzY3JpcHRpb24gOiBcIlwiKTtcclxuICBjb25zdCBbaW1hZ2VVcmwsIHNldEltYWdlVXJsXSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLnVybCA6IFwiXCIpO1xyXG4gIGNvbnN0IFtpc2V4dHJhcywgc2V0SXNleHRyYXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2l6ZXMsIHNldFNpemVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VycmVudFNpemUsIHNldEN1cnJlbnRTaXplXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjdXJyZW50UHJpY2UsIHNldEN1cnJlbnRQcmljZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgZm9vZHMgPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLkZPT0RTKTtcclxuICBjb25zdCBjYXRlZ29yaWVzID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5DQVRFR09SSUVTKTtcclxuICBjb25zb2xlLmxvZyh1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlKSk7XHJcblxyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuXHJcbiAgZnVuY3Rpb24gU3VibWl0dGVyKGUpIHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBzaXplcy5tYXAoKHNpemUsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBpbnB1dC1wcmljZSR7aW5kZXggKyAxfWApLnZhbHVlKTtcclxuICAgICAgcHJpY2VzLnB1c2goZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYGlucHV0LXByaWNlJHtpbmRleCArIDF9YCkudmFsdWUpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IHByaWNlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJpbnB1dC1wcmljZVwiKS52YWx1ZTtcclxuaWYoc2l6ZXMubGVuZ3RoPT09MCl7XHJcbiAgc2l6ZXMucHVzaCh7XHJcbiAgICBwcmljZTpwcmljZSxcclxuICAgIHNpemU6bnVsbCxcclxuICB9KVxyXG59XHJcbiAgICBjb25zdCBmb29kID1cclxuICAgICAgeyAgICBmb29kTm86IChmb29kcz8ubGVuZ3RoID8gbGVuZ3RoIDogMCkgKyAxLFxyXG4gICAgICAgICAgICB0aXRsZTogdGl0bGUsXHJcbiAgICAgICAgICAgIGFsbGVyZ2llczogYWxsZXJnaWVzLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIGV4dHJhczogaXNleHRyYXMsXHJcbiAgICAgICAgICAgIC8vIGltYWdlVXJsOiBpbWFnZVVybCxcclxuICAgICAgICAgICAgY2F0ZWdvcnk6IGNhdGVnb3J5LFxyXG4gICAgICAgICAgICBzaXplczpzaXplcyxcclxuICAgICAgICAgIH1cclxuICAgICAgICBcclxuXHJcbiAgICAgIGFwaS5wb3N0KFwiL2Zvb2RcIiwgZm9vZCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwib25lIHByb2R1Y3QgXCIsIGZvb2QpO1xyXG4gICAgIFxyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgYXdhaXQgYXBpLmdldChcIi9mb29kXCIpLnRoZW4oKGMpID0+IGNvbnNvbGUubG9nKGMuZGF0YSkpO1xyXG4gICAgfSkoKTtcclxuXHJcbiAgICAvLyBjb25zb2xlLmxvZyhmb29kKTtcclxuICB9XHJcbiAgY29uc3Qgb25DYXRlZ29yeUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRDYXRlZ29yeShlLnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uUHJpY2VDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIHByaWNlcy5wdXNoKE51bWJlcihlLnRhcmdldC52YWx1ZSkpO1xyXG4gICAgc2V0UHJpY2VzKHByaWNlcyk7XHJcbiAgfTtcclxuICBjb25zdCBvblRpdGxlQ2hhbmdlciA9IChlKSA9PiB7XHJcbiAgICBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25JbWFnZVVybENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRJbWFnZVVybChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25EZXNjcmlwdGlvbkNoYW5nZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNpemVBZGRlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzID0gc2l6ZXM7XHJcblxyXG4gICAgcy5wdXNoKHtcclxuICAgICAgcHJpY2U6IGN1cnJlbnRQcmljZSxcclxuICAgICAgc2l6ZTogY3VycmVudFNpemUsXHJcbiAgICB9KTtcclxuICAgIGNvbnNvbGUubG9nKFwic2l6ZSBhZGRlZCBcIiwgcyk7XHJcblxyXG4gICAgc2V0U2l6ZXMocyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25BbGxlcmdpZXNDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIGxldCBhcnIgPSBcIlwiO1xyXG4gICAgYXJyID0gYXJyLmNvbmNhdChcIlwiICsgZS50YXJnZXQudmFsdWUpO1xyXG4gICAgYXJyID0gYXJyLnNwbGl0KFwiLFwiLCAxMDAwKTtcclxuICAgIHNldEFsbGVyZ2llcyhhcnIpO1xyXG4gIH07XHJcbiAgY29uc3Qgb25leHRyYXNDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIC8vIGNvbnNvbGUubG9nKGUudGFyZ2V0LmNoZWNrZWQpO1xyXG5cclxuICAgIHNldElzZXh0cmFzKGUudGFyZ2V0LmNoZWNrZWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhdGVnb3J5T3B0aW9ucyA9IGNhdGVnb3JpZXMubWFwKChjYXQpID0+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHZhbHVlOiBjYXQudGl0bGUsXHJcbiAgICAgIGxhYmVsOiBjYXQudGl0bGUsXHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzaXplc09wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiBcInNtXCIsIGxhYmVsOiBcIlNtYWxsXCIgfSxcclxuICAgIHsgdmFsdWU6IFwibWRcIiwgbGFiZWw6IFwiTWVkaXVtXCIgfSxcclxuICAgIHsgdmFsdWU6IFwibGdcIiwgbGFiZWw6IFwiTGFyZ2VcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJ4bGdcIiwgbGFiZWw6IFwiRXh0cmEgTGFyZ2VcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8U2ltcGxlSGVhZGVyIC8+XHJcblxyXG4gICAgICA8Q29udGFpbmVyIGNsYXNzTmFtZT1cIm10LTdcIiBmbHVpZD5cclxuICAgICAgICA8Um93PlxyXG4gICAgICAgICAgPENvbCBjbGFzc05hbWU9XCJvcmRlci14bC0xXCIgeGw9XCI4XCI+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXNlY29uZGFyeSBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXItMFwiPjwvQ2FyZEhlYWRlcj5cclxuICAgICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgICA8Um93IGNsYXNzTmFtZT1cImFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbSA/IFwiRWRpdCBFeGlzdGluZyBGb29kXCIgOiBcIkFkZCBOZXcgRm9vZFwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCIgeHM9XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIGV4YWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiL2FkbWluL21hbmFnZUZvb2RzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBTdWJtaXR0ZXIoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gU3VibWl0dGVyKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17aXRlbSA/IFwic3VjY2Vzc1wiIDogXCJwcmltYXJ5XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB0MyBwYi0zIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtID8gXCJTYXZlIENoYW5nZXNcIiA6IFwiQWRkXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwibXQtMiBtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+Q2xpY2sgT24gRXZlcnkgRmllbGQgYXQgbGVhc3QgT25jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm1iLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtYWx0ZXJuYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC10aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInBpenphICwgc3BlZ2hhdGkgZXRjLi4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0udGl0bGUgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVGl0bGVDaGFuZ2VyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LWNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgdGhlIENhdGVnb3J5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0TWVudVNpbmdsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1jYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtjYXRlZ29yeU9wdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLmNhdGVnb3J5IDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlSGFuZGxlcj17b25DYXRlZ29yeUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXYgaWQ9XCJzaXplc0RpdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LXNpemVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkIFNpemUob3B0aW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdE1lbnVNdWx0aXBsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXNpemVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2VIYW5kbGVyPXtvblNpemVzQ2hhbmdlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17c2l6ZXNPcHRpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zIG10LTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dTaXplRGl2KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICArIE1hbmFnZSBTaXplXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge3Nob3dTaXplRGl2ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l6ZXNEaXZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LXNpemVTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpemVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXNpemVzU2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIzMng0NWNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNpemVzIGdvdFwiLCBlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50U2l6ZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00IFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtc2l6ZVByaWNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaWNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1zaXplUHJpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNC4zM+KCrFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzaXplcyBnb3RcIiwgZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudFByaWNlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBtdC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2l6ZURpdihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZUFkZGVyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBRERcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+IFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZXMubWFwKHM9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtbC00IG1yLTQgbXQtMiBkLWZsZXgganVzdGlmeS1jb250ZW50LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gIGNvbG9yPVwiZGFuZ2VyXCI+RGVsZXRlPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57cy5wcmljZX3igqw8L2I+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Yj57cy5zaXplfTwvYj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbWFnZSBVcmxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtaW1hZ2VVcmxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ3d3cuZXhhbXBsZS5jb20vaW1hZ2UucG5nXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0udXJsIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25JbWFnZVVybENoYW5nZShlLCB2KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtcHJpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaWNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXByaWNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNC41NuKCrFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLnByaWNlIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25QcmljZUNoYW5nZXIoZSwgdil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtYWxsZXJnaWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbGxlcmdpZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LWFsbGVyZ2llc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbGVyZ2llcyBpLGksMSwyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0uYWxsZXJnaWVzIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25BbGxlcmdpZXNDaGFuZ2VyKGUsIHYpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LWFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlc2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtpdGVtID8gaXRlbS5kZXNjcmlwdGlvbiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dGFyZWFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17NX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkRlc2NyaXB0aW9uQ2hhbmdlcihlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25leHRyYXNDaGFuZ2VyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwPmV4dHJhcyBJbmNsdWRlZD88L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgICAgIDwvQ2FyZEJvZHk+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuYWRkRm9vZC5sYXlvdXQgPSBBZG1pbjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFkZEZvb2Q7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=