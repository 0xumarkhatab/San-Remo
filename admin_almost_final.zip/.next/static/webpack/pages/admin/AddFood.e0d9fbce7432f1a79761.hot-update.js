webpackHotUpdate_N_E("pages/admin/AddFood",{

/***/ "./pages/admin/AddFood.js":
/*!********************************!*\
  !*** ./pages/admin/AddFood.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/Headers/SimpleHeader */ "./components/Headers/SimpleHeader.js");
/* harmony import */ var _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../layouts/Admin */ "./layouts/Admin.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuSingle */ "./components/SelectMenu/SelectMenuSingle.jsx");
/* harmony import */ var _components_SelectMenu_SelectMenuMultiple__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuMultiple */ "./components/SelectMenu/SelectMenuMultiple.jsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../API_WORK/api */ "./API_WORK/api.js");






var _jsxFileName = "E:\\admin\\pages\\admin\\AddFood.js",
    _s = $RefreshSig$();









 // layout for this page

var title, category, sizes, description, price;

function addFood(_ref) {
  _s();

  var _this = this,
      _jsxDEV2,
      _jsxDEV3;

  var item = _ref.item;
  console.log("existing Food Recieved", item);

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      showSizeDiv = _useState[0],
      setShowSizeDiv = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      prices = _useState2[0],
      setPrices = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.title : ""),
      title = _useState3[0],
      setTitle = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.category : ""),
      category = _useState4[0],
      setCategory = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.alleries : []),
      allergies = _useState5[0],
      setAllergies = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.description : ""),
      description = _useState6[0],
      setDescription = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.url : ""),
      imageUrl = _useState7[0],
      setImageUrl = _useState7[1];

  var _useState8 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      isextras = _useState8[0],
      setIsextras = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      sizes = _useState9[0],
      setSizes = _useState9[1];

  var _useState10 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentSize = _useState10[0],
      setCurrentSize = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentPrice = _useState11[0],
      setCurrentPrice = _useState11[1];

  var foods = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.FOODS;
  });
  var categories = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.CATEGORIES;
  });
  console.log(Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state;
  }));
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"])();

  function Submitter(e) {
    e.preventDefault();
    sizes.map(function (size, index) {
      console.log(document.getElementById("input-price".concat(index + 1)).value);
      prices.push(document.getElementById("input-price".concat(index + 1)).value);
    });
    var price = document.getElementById("input-price").value;
    var food = sizes.length === 0 ? {
      foodNo: (foods !== null && foods !== void 0 && foods.length ? length : 0) + 1,
      title: title,
      price: price,
      allergies: allergies,
      description: description,
      extras: isextras,
      // imageUrl: imageUrl,
      category: category,
      size: null
    } : sizes.map(function (size, index) {
      return {
        foodNo: (foods !== null && foods !== void 0 && foods.length ? length : 0) + index + 1,
        title: title,
        price: prices[index],
        allergies: allergies,
        description: description,
        extras: isextras,
        category: category,
        size: size
      };
    }); // if(sizes.length > 0 ){
    // food.map(fo=>{
    //   foods.push(fo);
    // });
    // }
    // else{
    //   foods.push(food);
    // }

    if (sizes.length === 0) {
      _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].post("/food", food);
      console.log("one product ", food);
    } else {
      food.map(function (f) {
        return _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].post("/food", f);
      });
      console.log("products ", food);
    }

    Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.mark(function _callee() {
      return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].get("/food").then(function (c) {
                return console.log(c.data);
              });

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))(); // console.log(food);

  }

  var onCategoryChange = function onCategoryChange(e) {
    setCategory(e.value);
  };

  var onPriceChanger = function onPriceChanger(e) {
    prices.push(Number(e.target.value));
    setPrices(prices);
  };

  var onTitleChanger = function onTitleChanger(e) {
    setTitle(e.target.value);
  };

  var onImageUrlChange = function onImageUrlChange(e) {
    setImageUrl(e.target.value);
  };

  var onDescriptionChanger = function onDescriptionChanger(e) {
    setDescription(e.target.value);
  };

  var sizeAdder = function sizeAdder(e) {
    var s = sizes;
    s.push({
      price: currentPrice,
      size: currentSize
    });
    console.log("size added ", s);
    setSizes(s);
  };

  var onAllergiesChanger = function onAllergiesChanger(e) {
    var arr = "";
    arr = arr.concat("" + e.target.value);
    arr = arr.split(",", 1000);
    setAllergies(arr);
  };

  var onextrasChanger = function onextrasChanger(e) {
    // console.log(e.target.checked);
    setIsextras(e.target.checked);
  };

  var categoryOptions = categories.map(function (cat) {
    return {
      value: cat.title,
      label: cat.title
    };
  });
  var sizesOptions = [{
    value: "sm",
    label: "Small"
  }, {
    value: "md",
    label: "Medium"
  }, {
    value: "lg",
    label: "Large"
  }, {
    value: "xlg",
    label: "Extra Large"
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Container"], {
      className: "mt-7",
      fluid: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
          className: "order-xl-1",
          xl: "8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Card"], {
            className: "bg-secondary shadow",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardHeader"], {
              className: "bg-white border-0"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 176,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardBody"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                className: "align-items-center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  xs: "8",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                    className: "mb-0",
                    children: [item ? "Edit Existing Food" : "Add New Food", " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 179,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  className: "text-right",
                  xs: "4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
                    exact: true,
                    href: "/admin/manageFoods",
                    onClick: function onClick(e) {
                      return Submitter(e);
                    },
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                      onClick: function onClick(e) {
                        return Submitter(e);
                      },
                      color: item ? "success" : "primary",
                      className: "pt3 pb-3 ",
                      children: item ? "Save Changes" : "Add"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 190,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 185,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 184,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 178,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Form"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mt-2 mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 204,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 203,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 202,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 201,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                        children: "Click On Every Field at least Once"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 212,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 211,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 210,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 209,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 220,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 219,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 218,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 217,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Title"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 229,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-title",
                          placeholder: "pizza , speghati etc....",
                          autoFocus: true,
                          type: "text",
                          defaultValue: item ? item.title : "",
                          onChange: function onChange(e) {
                            onTitleChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 235,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 228,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 227,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 226,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 225,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-category",
                          children: "Select the Category"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 255,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__["default"], {
                          id: "input-category",
                          options: categoryOptions,
                          defaultValue: item ? item.category : "",
                          onChangeHandler: onCategoryChange
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 261,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 254,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 253,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 252,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 251,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                        className: "p-3 mt-2",
                        color: "primary",
                        onClick: function onClick(e) {
                          setShowSizeDiv(true);
                        },
                        children: "+ Manage Size"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 295,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 294,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 293,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 292,
                  columnNumber: 19
                }, this), showSizeDiv ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "sizesDiv",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizeSize",
                            children: "Size"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 314,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizesSize",
                            placeholder: "32x45cm",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentSize(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 320,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 313,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 312,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 311,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 310,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizePrice",
                            children: "Price"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 338,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizePrice",
                            placeholder: "4.33\u20AC",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentPrice(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 344,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 337,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 336,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 335,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 334,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                          className: "p-3 mt-2",
                          color: "primary",
                          onClick: function onClick(e) {
                            setShowSizeDiv(false);
                            sizeAdder(e);
                          },
                          children: "ADD"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 361,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 360,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 359,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 358,
                    columnNumber: 23
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 309,
                  columnNumber: 21
                }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                        className: "mt-2 ",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Table"], {
                          className: "table table-dark",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("thead", {
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                              scope: "col",
                              children: "Action"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 386,
                              columnNumber: 33
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                              scope: "col",
                              children: "Price"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 387,
                              columnNumber: 33
                            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                              scope: "col",
                              children: "Size"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 388,
                              columnNumber: 33
                            }, this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 385,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tbody", {
                            children: sizes.map(function (s) {
                              /*#__PURE__*/
                              Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tr", {
                                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                                    className: "p-3 mt-2",
                                    color: "danger",
                                    children: "Delete"
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 394,
                                    columnNumber: 39
                                  }, _this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 393,
                                  columnNumber: 37
                                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                                  children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                                    children: s.price
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 403,
                                    columnNumber: 39
                                  }, _this)]
                                }, void 0, true, {
                                  fileName: _jsxFileName,
                                  lineNumber: 401,
                                  columnNumber: 37
                                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("td", {
                                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                                    children: s.size
                                  }, void 0, false, {
                                    fileName: _jsxFileName,
                                    lineNumber: 406,
                                    columnNumber: 39
                                  }, _this)
                                }, void 0, false, {
                                  fileName: _jsxFileName,
                                  lineNumber: 405,
                                  columnNumber: 37
                                }, _this)]
                              }, s.size, true, {
                                fileName: _jsxFileName,
                                lineNumber: 392,
                                columnNumber: 35
                              }, _this);
                            })
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 390,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 384,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 383,
                        columnNumber: 27
                      }, this), ")"]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 381,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 380,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 379,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Image Url"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 423,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-imageUrl",
                          placeholder: "www.example.com/image.png",
                          type: "text",
                          defaultValue: item ? item.url : "",
                          onChange: function onChange(e, v) {
                            return onImageUrlChange(e, v);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 429,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 422,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 421,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 420,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 419,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-price",
                          children: "Price"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 446,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-price",
                          placeholder: "4.56\u20AC",
                          defaultValue: item ? item.price : "",
                          onChange: function onChange(e, v) {
                            return onPriceChanger(e, v);
                          },
                          type: "text"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 452,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 445,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 444,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 443,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 442,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-allergies",
                          children: "Allergies"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 468,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV2 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-allergies",
                          placeholder: "Allergies i,i,1,2",
                          type: "text"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "defaultValue", item ? item.allergies : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "onChange", function onChange(e, v) {
                          return onAllergiesChanger(e, v);
                        }), _jsxDEV2), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 474,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 467,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 466,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 465,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 464,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Description"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 491,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV3 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-address",
                          placeholder: "Description"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "defaultValue", item ? item.description : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "type", "textarea"), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "rows", 5), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "onChange", function onChange(e) {
                          onDescriptionChanger(e);
                        }), _jsxDEV3), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 497,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 490,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 489,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 488,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 487,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          type: "checkbox",
                          onChange: function onChange(e) {
                            onextrasChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 517,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                          children: "extras Included?"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 523,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 516,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 515,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 514,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 513,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 200,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 177,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 175,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 174,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 172,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(addFood, "zeK8nBsDwmkHoXI2DEH0KRCbtF4=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"]];
});

addFood.layout = _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__["default"];
/* harmony default export */ __webpack_exports__["default"] = (addFood);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYWRtaW4vQWRkRm9vZC5qcyJdLCJuYW1lcyI6WyJ0aXRsZSIsImNhdGVnb3J5Iiwic2l6ZXMiLCJkZXNjcmlwdGlvbiIsInByaWNlIiwiYWRkRm9vZCIsIml0ZW0iLCJjb25zb2xlIiwibG9nIiwidXNlU3RhdGUiLCJzaG93U2l6ZURpdiIsInNldFNob3dTaXplRGl2IiwicHJpY2VzIiwic2V0UHJpY2VzIiwic2V0VGl0bGUiLCJzZXRDYXRlZ29yeSIsImFsbGVyaWVzIiwiYWxsZXJnaWVzIiwic2V0QWxsZXJnaWVzIiwic2V0RGVzY3JpcHRpb24iLCJ1cmwiLCJpbWFnZVVybCIsInNldEltYWdlVXJsIiwiaXNleHRyYXMiLCJzZXRJc2V4dHJhcyIsInNldFNpemVzIiwiY3VycmVudFNpemUiLCJzZXRDdXJyZW50U2l6ZSIsImN1cnJlbnRQcmljZSIsInNldEN1cnJlbnRQcmljZSIsImZvb2RzIiwidXNlU2VsZWN0b3IiLCJzdGF0ZSIsIkZPT0RTIiwiY2F0ZWdvcmllcyIsIkNBVEVHT1JJRVMiLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwiU3VibWl0dGVyIiwiZSIsInByZXZlbnREZWZhdWx0IiwibWFwIiwic2l6ZSIsImluZGV4IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInZhbHVlIiwicHVzaCIsImZvb2QiLCJsZW5ndGgiLCJmb29kTm8iLCJleHRyYXMiLCJhcGkiLCJwb3N0IiwiZiIsImdldCIsInRoZW4iLCJjIiwiZGF0YSIsIm9uQ2F0ZWdvcnlDaGFuZ2UiLCJvblByaWNlQ2hhbmdlciIsIk51bWJlciIsInRhcmdldCIsIm9uVGl0bGVDaGFuZ2VyIiwib25JbWFnZVVybENoYW5nZSIsIm9uRGVzY3JpcHRpb25DaGFuZ2VyIiwic2l6ZUFkZGVyIiwicyIsIm9uQWxsZXJnaWVzQ2hhbmdlciIsImFyciIsImNvbmNhdCIsInNwbGl0Iiwib25leHRyYXNDaGFuZ2VyIiwiY2hlY2tlZCIsImNhdGVnb3J5T3B0aW9ucyIsImNhdCIsImxhYmVsIiwic2l6ZXNPcHRpb25zIiwidiIsImxheW91dCIsIkFkbWluIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQWNBO0FBQ0E7QUFDQTtDQUdBOztBQUNBLElBQUlBLEtBQUosRUFBV0MsUUFBWCxFQUFxQkMsS0FBckIsRUFBNEJDLFdBQTVCLEVBQXlDQyxLQUF6Qzs7QUFFQSxTQUFTQyxPQUFULE9BQTJCO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBLE1BQVJDLElBQVEsUUFBUkEsSUFBUTtBQUN6QkMsU0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBc0NGLElBQXRDOztBQUR5QixrQkFFYUcsc0RBQVEsQ0FBQyxLQUFELENBRnJCO0FBQUEsTUFFbEJDLFdBRmtCO0FBQUEsTUFFTEMsY0FGSzs7QUFBQSxtQkFJR0Ysc0RBQVEsQ0FBQyxFQUFELENBSlg7QUFBQSxNQUlsQkcsTUFKa0I7QUFBQSxNQUlWQyxTQUpVOztBQUFBLG1CQUtDSixzREFBUSxDQUFDSCxJQUFJLEdBQUdBLElBQUksQ0FBQ04sS0FBUixHQUFnQixFQUFyQixDQUxUO0FBQUEsTUFLbEJBLEtBTGtCO0FBQUEsTUFLWGMsUUFMVzs7QUFBQSxtQkFNT0wsc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNMLFFBQVIsR0FBbUIsRUFBeEIsQ0FOZjtBQUFBLE1BTWxCQSxRQU5rQjtBQUFBLE1BTVJjLFdBTlE7O0FBQUEsbUJBT1NOLHNEQUFRLENBQUNILElBQUksR0FBR0EsSUFBSSxDQUFDVSxRQUFSLEdBQW1CLEVBQXhCLENBUGpCO0FBQUEsTUFPbEJDLFNBUGtCO0FBQUEsTUFPUEMsWUFQTzs7QUFBQSxtQkFRYVQsc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNILFdBQVIsR0FBc0IsRUFBM0IsQ0FSckI7QUFBQSxNQVFsQkEsV0FSa0I7QUFBQSxNQVFMZ0IsY0FSSzs7QUFBQSxtQkFTT1Ysc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNjLEdBQVIsR0FBYyxFQUFuQixDQVRmO0FBQUEsTUFTbEJDLFFBVGtCO0FBQUEsTUFTUkMsV0FUUTs7QUFBQSxtQkFVT2Isc0RBQVEsQ0FBQyxLQUFELENBVmY7QUFBQSxNQVVsQmMsUUFWa0I7QUFBQSxNQVVSQyxXQVZROztBQUFBLG1CQVlDZixzREFBUSxDQUFDLEVBQUQsQ0FaVDtBQUFBLE1BWWxCUCxLQVprQjtBQUFBLE1BWVh1QixRQVpXOztBQUFBLG9CQWFhaEIsc0RBQVEsQ0FBQyxFQUFELENBYnJCO0FBQUEsTUFhbEJpQixXQWJrQjtBQUFBLE1BYUxDLGNBYks7O0FBQUEsb0JBY2VsQixzREFBUSxDQUFDLEVBQUQsQ0FkdkI7QUFBQSxNQWNsQm1CLFlBZGtCO0FBQUEsTUFjSkMsZUFkSTs7QUFnQnpCLE1BQU1DLEtBQUssR0FBR0MsZ0VBQVcsQ0FBQyxVQUFDQyxLQUFEO0FBQUEsV0FBV0EsS0FBSyxDQUFDQyxLQUFqQjtBQUFBLEdBQUQsQ0FBekI7QUFDQSxNQUFNQyxVQUFVLEdBQUdILGdFQUFXLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFdBQVdBLEtBQUssQ0FBQ0csVUFBakI7QUFBQSxHQUFELENBQTlCO0FBQ0E1QixTQUFPLENBQUNDLEdBQVIsQ0FBWXVCLGdFQUFXLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFdBQVdBLEtBQVg7QUFBQSxHQUFELENBQXZCO0FBRUEsTUFBTUksUUFBUSxHQUFHQyxnRUFBVyxFQUE1Qjs7QUFFQSxXQUFTQyxTQUFULENBQW1CQyxDQUFuQixFQUFzQjtBQUNwQkEsS0FBQyxDQUFDQyxjQUFGO0FBRUF0QyxTQUFLLENBQUN1QyxHQUFOLENBQVUsVUFBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQ3pCcEMsYUFBTyxDQUFDQyxHQUFSLENBQVlvQyxRQUFRLENBQUNDLGNBQVQsc0JBQXNDRixLQUFLLEdBQUcsQ0FBOUMsR0FBbURHLEtBQS9EO0FBQ0FsQyxZQUFNLENBQUNtQyxJQUFQLENBQVlILFFBQVEsQ0FBQ0MsY0FBVCxzQkFBc0NGLEtBQUssR0FBRyxDQUE5QyxHQUFtREcsS0FBL0Q7QUFDRCxLQUhEO0FBS0EsUUFBSTFDLEtBQUssR0FBR3dDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixFQUF1Q0MsS0FBbkQ7QUFFQSxRQUFNRSxJQUFJLEdBQ1I5QyxLQUFLLENBQUMrQyxNQUFOLEtBQWlCLENBQWpCLEdBQ0k7QUFDRUMsWUFBTSxFQUFFLENBQUNwQixLQUFLLFNBQUwsSUFBQUEsS0FBSyxXQUFMLElBQUFBLEtBQUssQ0FBRW1CLE1BQVAsR0FBZ0JBLE1BQWhCLEdBQXlCLENBQTFCLElBQStCLENBRHpDO0FBRUVqRCxXQUFLLEVBQUVBLEtBRlQ7QUFHRUksV0FBSyxFQUFFQSxLQUhUO0FBSUVhLGVBQVMsRUFBRUEsU0FKYjtBQUtFZCxpQkFBVyxFQUFFQSxXQUxmO0FBTUVnRCxZQUFNLEVBQUU1QixRQU5WO0FBT0U7QUFDQXRCLGNBQVEsRUFBRUEsUUFSWjtBQVNFeUMsVUFBSSxFQUFFO0FBVFIsS0FESixHQVlJeEMsS0FBSyxDQUFDdUMsR0FBTixDQUFVLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUN6QixhQUFPO0FBQ0xPLGNBQU0sRUFBRSxDQUFDcEIsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCxJQUFBQSxLQUFLLENBQUVtQixNQUFQLEdBQWdCQSxNQUFoQixHQUF5QixDQUExQixJQUErQk4sS0FBL0IsR0FBdUMsQ0FEMUM7QUFHTDNDLGFBQUssRUFBRUEsS0FIRjtBQUlMSSxhQUFLLEVBQUVRLE1BQU0sQ0FBQytCLEtBQUQsQ0FKUjtBQUtMMUIsaUJBQVMsRUFBRUEsU0FMTjtBQU1MZCxtQkFBVyxFQUFFQSxXQU5SO0FBT0xnRCxjQUFNLEVBQUU1QixRQVBIO0FBU0x0QixnQkFBUSxFQUFFQSxRQVRMO0FBVUx5QyxZQUFJLEVBQUVBO0FBVkQsT0FBUDtBQVlELEtBYkQsQ0FiTixDQVZvQixDQXNDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxRQUFJeEMsS0FBSyxDQUFDK0MsTUFBTixLQUFpQixDQUFyQixFQUF3QjtBQUN0QkcsNERBQUcsQ0FBQ0MsSUFBSixDQUFTLE9BQVQsRUFBa0JMLElBQWxCO0FBQ0F6QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCd0MsSUFBNUI7QUFDRCxLQUhELE1BR087QUFDTEEsVUFBSSxDQUFDUCxHQUFMLENBQVMsVUFBQ2EsQ0FBRDtBQUFBLGVBQU9GLHNEQUFHLENBQUNDLElBQUosQ0FBUyxPQUFULEVBQWtCQyxDQUFsQixDQUFQO0FBQUEsT0FBVDtBQUNBL0MsYUFBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QndDLElBQXpCO0FBQ0Q7O0FBQ0QsNk5BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ09JLHNEQUFHLENBQUNHLEdBQUosQ0FBUSxPQUFSLEVBQWlCQyxJQUFqQixDQUFzQixVQUFDQyxDQUFEO0FBQUEsdUJBQU9sRCxPQUFPLENBQUNDLEdBQVIsQ0FBWWlELENBQUMsQ0FBQ0MsSUFBZCxDQUFQO0FBQUEsZUFBdEIsQ0FEUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFELEtBdERvQixDQTBEcEI7O0FBQ0Q7O0FBQ0QsTUFBTUMsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixDQUFDcEIsQ0FBRCxFQUFPO0FBQzlCeEIsZUFBVyxDQUFDd0IsQ0FBQyxDQUFDTyxLQUFILENBQVg7QUFDRCxHQUZEOztBQUdBLE1BQU1jLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ3JCLENBQUQsRUFBTztBQUM1QjNCLFVBQU0sQ0FBQ21DLElBQVAsQ0FBWWMsTUFBTSxDQUFDdEIsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFsQjtBQUNBakMsYUFBUyxDQUFDRCxNQUFELENBQVQ7QUFDRCxHQUhEOztBQUlBLE1BQU1tRCxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUN4QixDQUFELEVBQU87QUFDNUJ6QixZQUFRLENBQUN5QixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFWLENBQVI7QUFDRCxHQUZEOztBQUlBLE1BQU1rQixnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUN6QixDQUFELEVBQU87QUFDOUJqQixlQUFXLENBQUNpQixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFWLENBQVg7QUFDRCxHQUZEOztBQUlBLE1BQU1tQixvQkFBb0IsR0FBRyxTQUF2QkEsb0JBQXVCLENBQUMxQixDQUFELEVBQU87QUFDbENwQixrQkFBYyxDQUFDb0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFkO0FBQ0QsR0FGRDs7QUFJQSxNQUFNb0IsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQzNCLENBQUQsRUFBTztBQUN2QixRQUFNNEIsQ0FBQyxHQUFHakUsS0FBVjtBQUVBaUUsS0FBQyxDQUFDcEIsSUFBRixDQUFPO0FBQ0wzQyxXQUFLLEVBQUV3QixZQURGO0FBRUxjLFVBQUksRUFBRWhCO0FBRkQsS0FBUDtBQUlBbkIsV0FBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQjJELENBQTNCO0FBRUExQyxZQUFRLENBQUMwQyxDQUFELENBQVI7QUFDRCxHQVZEOztBQVlBLE1BQU1DLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQzdCLENBQUQsRUFBTztBQUNoQyxRQUFJOEIsR0FBRyxHQUFHLEVBQVY7QUFDQUEsT0FBRyxHQUFHQSxHQUFHLENBQUNDLE1BQUosQ0FBVyxLQUFLL0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBekIsQ0FBTjtBQUNBdUIsT0FBRyxHQUFHQSxHQUFHLENBQUNFLEtBQUosQ0FBVSxHQUFWLEVBQWUsSUFBZixDQUFOO0FBQ0FyRCxnQkFBWSxDQUFDbUQsR0FBRCxDQUFaO0FBQ0QsR0FMRDs7QUFNQSxNQUFNRyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNqQyxDQUFELEVBQU87QUFDN0I7QUFFQWYsZUFBVyxDQUFDZSxDQUFDLENBQUN1QixNQUFGLENBQVNXLE9BQVYsQ0FBWDtBQUNELEdBSkQ7O0FBTUEsTUFBTUMsZUFBZSxHQUFHeEMsVUFBVSxDQUFDTyxHQUFYLENBQWUsVUFBQ2tDLEdBQUQsRUFBUztBQUM5QyxXQUFPO0FBQ0w3QixXQUFLLEVBQUU2QixHQUFHLENBQUMzRSxLQUROO0FBRUw0RSxXQUFLLEVBQUVELEdBQUcsQ0FBQzNFO0FBRk4sS0FBUDtBQUlELEdBTHVCLENBQXhCO0FBT0EsTUFBTTZFLFlBQVksR0FBRyxDQUNuQjtBQUFFL0IsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQURtQixFQUVuQjtBQUFFOUIsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQUZtQixFQUduQjtBQUFFOUIsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQUhtQixFQUluQjtBQUFFOUIsU0FBSyxFQUFFLEtBQVQ7QUFBZ0I4QixTQUFLLEVBQUU7QUFBdkIsR0FKbUIsQ0FBckI7QUFPQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLHdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUdFLHFFQUFDLG9EQUFEO0FBQVcsZUFBUyxFQUFDLE1BQXJCO0FBQTRCLFdBQUssTUFBakM7QUFBQSw2QkFDRSxxRUFBQyw4Q0FBRDtBQUFBLCtCQUNFLHFFQUFDLDhDQUFEO0FBQUssbUJBQVMsRUFBQyxZQUFmO0FBQTRCLFlBQUUsRUFBQyxHQUEvQjtBQUFBLGlDQUNFLHFFQUFDLCtDQUFEO0FBQU0scUJBQVMsRUFBQyxxQkFBaEI7QUFBQSxvQ0FDRSxxRUFBQyxxREFBRDtBQUFZLHVCQUFTLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUVFLHFFQUFDLG1EQUFEO0FBQUEsc0NBQ0UscUVBQUMsOENBQUQ7QUFBSyx5QkFBUyxFQUFDLG9CQUFmO0FBQUEsd0NBQ0UscUVBQUMsOENBQUQ7QUFBSyxvQkFBRSxFQUFDLEdBQVI7QUFBQSx5Q0FDRTtBQUFJLDZCQUFTLEVBQUMsTUFBZDtBQUFBLCtCQUNHdEUsSUFBSSxHQUFHLG9CQUFILEdBQTBCLGNBRGpDLEVBQ2lELEdBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFNRSxxRUFBQyw4Q0FBRDtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUE0QixvQkFBRSxFQUFDLEdBQS9CO0FBQUEseUNBQ0UscUVBQUMsZ0RBQUQ7QUFDRSx5QkFBSyxNQURQO0FBRUUsd0JBQUksRUFBQyxvQkFGUDtBQUdFLDJCQUFPLEVBQUUsaUJBQUNpQyxDQUFEO0FBQUEsNkJBQU9ELFNBQVMsQ0FBQ0MsQ0FBRCxDQUFoQjtBQUFBLHFCQUhYO0FBQUEsMkNBS0UscUVBQUMsaURBQUQ7QUFDRSw2QkFBTyxFQUFFLGlCQUFDQSxDQUFEO0FBQUEsK0JBQU9ELFNBQVMsQ0FBQ0MsQ0FBRCxDQUFoQjtBQUFBLHVCQURYO0FBRUUsMkJBQUssRUFBRWpDLElBQUksR0FBRyxTQUFILEdBQWUsU0FGNUI7QUFHRSwrQkFBUyxFQUFDLFdBSFo7QUFBQSxnQ0FLR0EsSUFBSSxHQUFHLGNBQUgsR0FBb0I7QUFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQXVCRSxxRUFBQywrQ0FBRDtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFO0FBQUksaUNBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFTRTtBQUFLLDJCQUFTLEVBQUMscUJBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVEYsZUFpQkU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0U7QUFBSSxpQ0FBUyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFqQkYsZUF5QkU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLG1DQUFTLEVBQUMsMEJBRFo7QUFFRSw0QkFBRSxFQUFDLGFBRkw7QUFHRSxxQ0FBVyxFQUFDLDBCQUhkO0FBSUUsbUNBQVMsTUFKWDtBQUtFLDhCQUFJLEVBQUMsTUFMUDtBQU1FLHNDQUFZLEVBQUVBLElBQUksR0FBR0EsSUFBSSxDQUFDTixLQUFSLEdBQWdCLEVBTnBDO0FBT0Usa0NBQVEsRUFBRSxrQkFBQ3VDLENBQUQsRUFBTztBQUNmd0IsMENBQWMsQ0FBQ3hCLENBQUQsQ0FBZDtBQUNEO0FBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBekJGLGVBbURFO0FBQUssMkJBQVMsRUFBQyxVQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxnQkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQU9FLHFFQUFDLCtFQUFEO0FBQ0UsNEJBQUUsRUFBQyxnQkFETDtBQUVFLGlDQUFPLEVBQUVtQyxlQUZYO0FBR0Usc0NBQVksRUFBRXBFLElBQUksR0FBR0EsSUFBSSxDQUFDTCxRQUFSLEdBQW1CLEVBSHZDO0FBSUUseUNBQWUsRUFBRTBEO0FBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQW5ERixlQTRGRTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxpREFBRDtBQUNFLGlDQUFTLEVBQUMsVUFEWjtBQUVFLDZCQUFLLEVBQUMsU0FGUjtBQUdFLCtCQUFPLEVBQUUsaUJBQUNwQixDQUFELEVBQU87QUFDZDVCLHdDQUFjLENBQUMsSUFBRCxDQUFkO0FBQ0QseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBNUZGLEVBNEdHRCxXQUFXLGdCQUNWO0FBQUssMkJBQVMsRUFBQyxVQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsb0RBQUQ7QUFBQSxrREFDRTtBQUNFLHFDQUFTLEVBQUMsb0JBRFo7QUFFRSxtQ0FBTyxFQUFDLGdCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxxQ0FBUyxFQUFDLDBCQURaO0FBRUUsOEJBQUUsRUFBQyxpQkFGTDtBQUdFLHVDQUFXLEVBQUMsU0FIZDtBQUlFLGdDQUFJLEVBQUMsTUFKUDtBQUtFLG9DQUFRLEVBQUUsa0JBQUM2QixDQUFELEVBQU87QUFDZmhDLHFDQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXlCK0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBbEM7QUFDQW5CLDRDQUFjLENBQUNZLENBQUMsQ0FBQ3VCLE1BQUYsQ0FBU2hCLEtBQVYsQ0FBZDtBQUNEO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUF5QkU7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsb0RBQUQ7QUFBQSxrREFDRTtBQUNFLHFDQUFTLEVBQUMsb0JBRFo7QUFFRSxtQ0FBTyxFQUFDLGlCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxxQ0FBUyxFQUFDLDBCQURaO0FBRUUsOEJBQUUsRUFBQyxpQkFGTDtBQUdFLHVDQUFXLEVBQUMsWUFIZDtBQUlFLGdDQUFJLEVBQUMsTUFKUDtBQUtFLG9DQUFRLEVBQUUsa0JBQUNQLENBQUQsRUFBTztBQUNmaEMscUNBQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBeUIrQixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFsQztBQUNBakIsNkNBQWUsQ0FBQ1UsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFmO0FBQ0Q7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkF6QkYsZUFpREU7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsaURBQUQ7QUFDRSxtQ0FBUyxFQUFDLFVBRFo7QUFFRSwrQkFBSyxFQUFDLFNBRlI7QUFHRSxpQ0FBTyxFQUFFLGlCQUFDUCxDQUFELEVBQU87QUFDZDVCLDBDQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0F1RCxxQ0FBUyxDQUFDM0IsQ0FBRCxDQUFUO0FBQ0QsMkJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFEVSxHQW9FVixFQWhMSixlQW1MRTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw4Q0FFSTtBQUFLLGlDQUFTLEVBQUMsT0FBZjtBQUFBLCtDQUNFLHFFQUFDLGdEQUFEO0FBQU8sbUNBQVMsRUFBQyxrQkFBakI7QUFBQSxrREFDRTtBQUFBLG9EQUNFO0FBQUksbUNBQUssRUFBQyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQURGLGVBRUU7QUFBSSxtQ0FBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBRkYsZUFHRTtBQUFJLG1DQUFLLEVBQUMsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0NBREYsZUFNRTtBQUFBLHNDQUNHckMsS0FBSyxDQUFDdUMsR0FBTixDQUFVLFVBQUMwQixDQUFELEVBQU87QUFDaEI7QUFBQTtBQUFBLHdEQUNFO0FBQUEseURBQ0UscUVBQUMsaURBQUQ7QUFDRSw2Q0FBUyxFQUFDLFVBRFo7QUFFRSx5Q0FBSyxFQUFDLFFBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQURGLGVBU0U7QUFBQSw2Q0FDRyxHQURILGVBRUU7QUFBQSw4Q0FBSUEsQ0FBQyxDQUFDL0Q7QUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FURixlQWFFO0FBQUEseURBQ0U7QUFBQSw4Q0FBSStELENBQUMsQ0FBQ3pCO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBYkY7QUFBQSxpQ0FBU3lCLENBQUMsQ0FBQ3pCLElBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWlCRCw2QkFsQkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbkxGLGVBMk5FO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxlQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsNEJBQUUsRUFBQyxnQkFGTDtBQUdFLHFDQUFXLEVBQUMsMkJBSGQ7QUFJRSw4QkFBSSxFQUFDLE1BSlA7QUFLRSxzQ0FBWSxFQUFFcEMsSUFBSSxHQUFHQSxJQUFJLENBQUNjLEdBQVIsR0FBYyxFQUxsQztBQU1FLGtDQUFRLEVBQUUsa0JBQUNtQixDQUFELEVBQUl1QyxDQUFKO0FBQUEsbUNBQVVkLGdCQUFnQixDQUFDekIsQ0FBRCxFQUFJdUMsQ0FBSixDQUExQjtBQUFBO0FBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBM05GLGVBa1BFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxhQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsNEJBQUUsRUFBQyxhQUZMO0FBR0UscUNBQVcsRUFBQyxZQUhkO0FBSUUsc0NBQVksRUFBRXhFLElBQUksR0FBR0EsSUFBSSxDQUFDRixLQUFSLEdBQWdCLEVBSnBDO0FBS0Usa0NBQVEsRUFBRSxrQkFBQ21DLENBQUQsRUFBSXVDLENBQUo7QUFBQSxtQ0FBVWxCLGNBQWMsQ0FBQ3JCLENBQUQsRUFBSXVDLENBQUosQ0FBeEI7QUFBQSwyQkFMWjtBQU1FLDhCQUFJLEVBQUM7QUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsUEYsZUF3UUU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGlCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsc0NBQVksRUFBQyxFQUZmO0FBR0UsNEJBQUUsRUFBQyxpQkFITDtBQUlFLHFDQUFXLEVBQUMsbUJBSmQ7QUFLRSw4QkFBSSxFQUFDO0FBTFAsbUtBTWdCeEUsSUFBSSxHQUFHQSxJQUFJLENBQUNXLFNBQVIsR0FBb0IsRUFOeEMsdUlBT1ksa0JBQUNzQixDQUFELEVBQUl1QyxDQUFKO0FBQUEsaUNBQVVWLGtCQUFrQixDQUFDN0IsQ0FBRCxFQUFJdUMsQ0FBSixDQUE1QjtBQUFBLHlCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXhRRixlQStSRTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFO0FBQ0UsbUNBQVMsRUFBQyxvQkFEWjtBQUVFLGlDQUFPLEVBQUMsZUFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQU9FLHFFQUFDLGdEQUFEO0FBQ0UsbUNBQVMsRUFBQywwQkFEWjtBQUVFLHNDQUFZLEVBQUMsRUFGZjtBQUdFLDRCQUFFLEVBQUMsZUFITDtBQUlFLHFDQUFXLEVBQUM7QUFKZCxtS0FLZ0J4RSxJQUFJLEdBQUdBLElBQUksQ0FBQ0gsV0FBUixHQUFzQixFQUwxQyxtSUFNTyxVQU5QLG1JQU9RLENBUFIsdUlBUVksa0JBQUNvQyxDQUFELEVBQU87QUFDZjBCLDhDQUFvQixDQUFDMUIsQ0FBRCxDQUFwQjtBQUNELHlCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQS9SRixlQXlURTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFLHFFQUFDLGdEQUFEO0FBQ0UsOEJBQUksRUFBQyxVQURQO0FBRUUsa0NBQVEsRUFBRSxrQkFBQ0EsQ0FBRCxFQUFPO0FBQ2ZpQywyQ0FBZSxDQUFDakMsQ0FBRCxDQUFmO0FBQ0Q7QUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXpURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFIRjtBQUFBLGtCQURGO0FBZ1hEOztHQTNmUWxDLE87VUFnQk8wQix3RCxFQUNLQSx3RCxFQUNQQSx3RCxFQUVLTSx3RDs7O0FBd2VuQmhDLE9BQU8sQ0FBQzBFLE1BQVIsR0FBaUJDLHNEQUFqQjtBQUVlM0Usc0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWRtaW4vQWRkRm9vZC5lMGQ5ZmJjZTc0MzJmMWE3OTc2MS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaW1wbGVIZWFkZXIgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvSGVhZGVycy9TaW1wbGVIZWFkZXJcIjtcclxuaW1wb3J0IEFkbWluIGZyb20gXCIuLi8uLi9sYXlvdXRzL0FkbWluXCI7XHJcblxyXG5pbXBvcnQgTGluayBmcm9tIFwibmV4dC9saW5rXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBDYXJkLFxyXG4gIENhcmRIZWFkZXIsXHJcbiAgQ2FyZEJvZHksXHJcbiAgRm9ybUdyb3VwLFxyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgQ29udGFpbmVyLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgVGFibGUsXHJcbn0gZnJvbSBcInJlYWN0c3RyYXBcIjtcclxuXHJcbmltcG9ydCBTZWxlY3RNZW51U2luZ2xlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1NlbGVjdE1lbnUvU2VsZWN0TWVudVNpbmdsZVwiO1xyXG5pbXBvcnQgU2VsZWN0TWVudU11bHRpcGxlIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL1NlbGVjdE1lbnUvU2VsZWN0TWVudU11bHRpcGxlXCI7XHJcbmltcG9ydCB7IHVzZVNlbGVjdG9yLCB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi8uLi9BUElfV09SSy9hcGlcIjtcclxuXHJcbi8vIGxheW91dCBmb3IgdGhpcyBwYWdlXHJcbmxldCB0aXRsZSwgY2F0ZWdvcnksIHNpemVzLCBkZXNjcmlwdGlvbiwgcHJpY2U7XHJcblxyXG5mdW5jdGlvbiBhZGRGb29kKHsgaXRlbSB9KSB7XHJcbiAgY29uc29sZS5sb2coXCJleGlzdGluZyBGb29kIFJlY2lldmVkXCIsIGl0ZW0pO1xyXG4gIGNvbnN0IFtzaG93U2l6ZURpdiwgc2V0U2hvd1NpemVEaXZdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbcHJpY2VzLCBzZXRQcmljZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0udGl0bGUgOiBcIlwiKTtcclxuICBjb25zdCBbY2F0ZWdvcnksIHNldENhdGVnb3J5XSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLmNhdGVnb3J5IDogXCJcIik7XHJcbiAgY29uc3QgW2FsbGVyZ2llcywgc2V0QWxsZXJnaWVzXSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLmFsbGVyaWVzIDogW10pO1xyXG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0uZGVzY3JpcHRpb24gOiBcIlwiKTtcclxuICBjb25zdCBbaW1hZ2VVcmwsIHNldEltYWdlVXJsXSA9IHVzZVN0YXRlKGl0ZW0gPyBpdGVtLnVybCA6IFwiXCIpO1xyXG4gIGNvbnN0IFtpc2V4dHJhcywgc2V0SXNleHRyYXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2l6ZXMsIHNldFNpemVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VycmVudFNpemUsIHNldEN1cnJlbnRTaXplXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjdXJyZW50UHJpY2UsIHNldEN1cnJlbnRQcmljZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgZm9vZHMgPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLkZPT0RTKTtcclxuICBjb25zdCBjYXRlZ29yaWVzID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5DQVRFR09SSUVTKTtcclxuICBjb25zb2xlLmxvZyh1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlKSk7XHJcblxyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuXHJcbiAgZnVuY3Rpb24gU3VibWl0dGVyKGUpIHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBzaXplcy5tYXAoKHNpemUsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBpbnB1dC1wcmljZSR7aW5kZXggKyAxfWApLnZhbHVlKTtcclxuICAgICAgcHJpY2VzLnB1c2goZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYGlucHV0LXByaWNlJHtpbmRleCArIDF9YCkudmFsdWUpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IHByaWNlID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJpbnB1dC1wcmljZVwiKS52YWx1ZTtcclxuXHJcbiAgICBjb25zdCBmb29kID1cclxuICAgICAgc2l6ZXMubGVuZ3RoID09PSAwXHJcbiAgICAgICAgPyB7XHJcbiAgICAgICAgICAgIGZvb2RObzogKGZvb2RzPy5sZW5ndGggPyBsZW5ndGggOiAwKSArIDEsXHJcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZSxcclxuICAgICAgICAgICAgcHJpY2U6IHByaWNlLFxyXG4gICAgICAgICAgICBhbGxlcmdpZXM6IGFsbGVyZ2llcyxcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICBleHRyYXM6IGlzZXh0cmFzLFxyXG4gICAgICAgICAgICAvLyBpbWFnZVVybDogaW1hZ2VVcmwsXHJcbiAgICAgICAgICAgIGNhdGVnb3J5OiBjYXRlZ29yeSxcclxuICAgICAgICAgICAgc2l6ZTogbnVsbCxcclxuICAgICAgICAgIH1cclxuICAgICAgICA6IHNpemVzLm1hcCgoc2l6ZSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBmb29kTm86IChmb29kcz8ubGVuZ3RoID8gbGVuZ3RoIDogMCkgKyBpbmRleCArIDEsXHJcblxyXG4gICAgICAgICAgICAgIHRpdGxlOiB0aXRsZSxcclxuICAgICAgICAgICAgICBwcmljZTogcHJpY2VzW2luZGV4XSxcclxuICAgICAgICAgICAgICBhbGxlcmdpZXM6IGFsbGVyZ2llcyxcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgZXh0cmFzOiBpc2V4dHJhcyxcclxuXHJcbiAgICAgICAgICAgICAgY2F0ZWdvcnk6IGNhdGVnb3J5LFxyXG4gICAgICAgICAgICAgIHNpemU6IHNpemUsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAvLyBpZihzaXplcy5sZW5ndGggPiAwICl7XHJcbiAgICAvLyBmb29kLm1hcChmbz0+e1xyXG4gICAgLy8gICBmb29kcy5wdXNoKGZvKTtcclxuICAgIC8vIH0pO1xyXG4gICAgLy8gfVxyXG4gICAgLy8gZWxzZXtcclxuICAgIC8vICAgZm9vZHMucHVzaChmb29kKTtcclxuICAgIC8vIH1cclxuXHJcbiAgICBpZiAoc2l6ZXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIGFwaS5wb3N0KFwiL2Zvb2RcIiwgZm9vZCk7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwib25lIHByb2R1Y3QgXCIsIGZvb2QpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9vZC5tYXAoKGYpID0+IGFwaS5wb3N0KFwiL2Zvb2RcIiwgZikpO1xyXG4gICAgICBjb25zb2xlLmxvZyhcInByb2R1Y3RzIFwiLCBmb29kKTtcclxuICAgIH1cclxuICAgIChhc3luYyAoKSA9PiB7XHJcbiAgICAgIGF3YWl0IGFwaS5nZXQoXCIvZm9vZFwiKS50aGVuKChjKSA9PiBjb25zb2xlLmxvZyhjLmRhdGEpKTtcclxuICAgIH0pKCk7XHJcblxyXG4gICAgLy8gY29uc29sZS5sb2coZm9vZCk7XHJcbiAgfVxyXG4gIGNvbnN0IG9uQ2F0ZWdvcnlDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgc2V0Q2F0ZWdvcnkoZS52YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBvblByaWNlQ2hhbmdlciA9IChlKSA9PiB7XHJcbiAgICBwcmljZXMucHVzaChOdW1iZXIoZS50YXJnZXQudmFsdWUpKTtcclxuICAgIHNldFByaWNlcyhwcmljZXMpO1xyXG4gIH07XHJcbiAgY29uc3Qgb25UaXRsZUNoYW5nZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uSW1hZ2VVcmxDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgc2V0SW1hZ2VVcmwoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uRGVzY3JpcHRpb25DaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBzaXplQWRkZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgcyA9IHNpemVzO1xyXG5cclxuICAgIHMucHVzaCh7XHJcbiAgICAgIHByaWNlOiBjdXJyZW50UHJpY2UsXHJcbiAgICAgIHNpemU6IGN1cnJlbnRTaXplLFxyXG4gICAgfSk7XHJcbiAgICBjb25zb2xlLmxvZyhcInNpemUgYWRkZWQgXCIsIHMpO1xyXG5cclxuICAgIHNldFNpemVzKHMpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uQWxsZXJnaWVzQ2hhbmdlciA9IChlKSA9PiB7XHJcbiAgICBsZXQgYXJyID0gXCJcIjtcclxuICAgIGFyciA9IGFyci5jb25jYXQoXCJcIiArIGUudGFyZ2V0LnZhbHVlKTtcclxuICAgIGFyciA9IGFyci5zcGxpdChcIixcIiwgMTAwMCk7XHJcbiAgICBzZXRBbGxlcmdpZXMoYXJyKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uZXh0cmFzQ2hhbmdlciA9IChlKSA9PiB7XHJcbiAgICAvLyBjb25zb2xlLmxvZyhlLnRhcmdldC5jaGVja2VkKTtcclxuXHJcbiAgICBzZXRJc2V4dHJhcyhlLnRhcmdldC5jaGVja2VkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjYXRlZ29yeU9wdGlvbnMgPSBjYXRlZ29yaWVzLm1hcCgoY2F0KSA9PiB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB2YWx1ZTogY2F0LnRpdGxlLFxyXG4gICAgICBsYWJlbDogY2F0LnRpdGxlLFxyXG4gICAgfTtcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgc2l6ZXNPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogXCJzbVwiLCBsYWJlbDogXCJTbWFsbFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIm1kXCIsIGxhYmVsOiBcIk1lZGl1bVwiIH0sXHJcbiAgICB7IHZhbHVlOiBcImxnXCIsIGxhYmVsOiBcIkxhcmdlXCIgfSxcclxuICAgIHsgdmFsdWU6IFwieGxnXCIsIGxhYmVsOiBcIkV4dHJhIExhcmdlXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFNpbXBsZUhlYWRlciAvPlxyXG5cclxuICAgICAgPENvbnRhaW5lciBjbGFzc05hbWU9XCJtdC03XCIgZmx1aWQ+XHJcbiAgICAgICAgPFJvdz5cclxuICAgICAgICAgIDxDb2wgY2xhc3NOYW1lPVwib3JkZXIteGwtMVwiIHhsPVwiOFwiPlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJiZy1zZWNvbmRhcnkgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLTBcIj48L0NhcmRIZWFkZXI+XHJcbiAgICAgICAgICAgICAgPENhcmRCb2R5PlxyXG4gICAgICAgICAgICAgICAgPFJvdyBjbGFzc05hbWU9XCJhbGlnbi1pdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz1cIjhcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0gPyBcIkVkaXQgRXhpc3RpbmcgRm9vZFwiIDogXCJBZGQgTmV3IEZvb2RcIn17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgIDxDb2wgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiIHhzPVwiNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICBleGFjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj1cIi9hZG1pbi9tYW5hZ2VGb29kc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gU3VibWl0dGVyKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IFN1Ym1pdHRlcihlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e2l0ZW0gPyBcInN1Y2Nlc3NcIiA6IFwicHJpbWFyeVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwdDMgcGItMyBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbSA/IFwiU2F2ZSBDaGFuZ2VzXCIgOiBcIkFkZFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgPEZvcm0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm10LTIgbWItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPkNsaWNrIE9uIEV2ZXJ5IEZpZWxkIGF0IGxlYXN0IE9uY2U8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGl0bGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJwaXp6YSAsIHNwZWdoYXRpIGV0Yy4uLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLnRpdGxlIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblRpdGxlQ2hhbmdlcihlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1jYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IHRoZSBDYXRlZ29yeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdE1lbnVTaW5nbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17Y2F0ZWdvcnlPcHRpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtpdGVtID8gaXRlbS5jYXRlZ29yeSA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZUhhbmRsZXI9e29uQ2F0ZWdvcnlDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGlkPVwic2l6ZXNEaXZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1zaXplc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBTaXplKG9wdGlvbmFsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RNZW51TXVsdGlwbGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1zaXplc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlSGFuZGxlcj17b25TaXplc0NoYW5nZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3NpemVzT3B0aW9uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00IFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBtdC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2l6ZURpdih0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKyBNYW5hZ2UgU2l6ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtzaG93U2l6ZURpdiA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpemVzRGl2XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1zaXplU2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTaXplXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1zaXplc1NpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMzJ4NDVjbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzaXplcyBnb3RcIiwgZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudFNpemUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LXNpemVQcmljZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmljZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtYWx0ZXJuYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtc2l6ZVByaWNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjQuMzPigqxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic2l6ZXMgZ290XCIsIGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRQcmljZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00IFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgbXQtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1NpemVEaXYoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemVBZGRlcihlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQUREXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYmxlIGNsYXNzTmFtZT1cInRhYmxlIHRhYmxlLWRhcmtcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiPkFjdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+UHJpY2U8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiPlNpemU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NpemVzLm1hcCgocykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17cy5zaXplfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBtdC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiZGFuZ2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD57cy5wcmljZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD57cy5zaXplfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbWFnZSBVcmxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtaW1hZ2VVcmxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJ3d3cuZXhhbXBsZS5jb20vaW1hZ2UucG5nXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0udXJsIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25JbWFnZVVybENoYW5nZShlLCB2KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtcHJpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaWNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXByaWNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNC41NuKCrFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLnByaWNlIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25QcmljZUNoYW5nZXIoZSwgdil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtYWxsZXJnaWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbGxlcmdpZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LWFsbGVyZ2llc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbGVyZ2llcyBpLGksMSwyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0uYWxsZXJnaWVzIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSwgdikgPT4gb25BbGxlcmdpZXNDaGFuZ2VyKGUsIHYpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LWFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlc2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtpdGVtID8gaXRlbS5kZXNjcmlwdGlvbiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dGFyZWFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17NX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkRlc2NyaXB0aW9uQ2hhbmdlcihlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25leHRyYXNDaGFuZ2VyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwPmV4dHJhcyBJbmNsdWRlZD88L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgICAgIDwvQ2FyZEJvZHk+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG4gICAgICA8L0NvbnRhaW5lcj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuYWRkRm9vZC5sYXlvdXQgPSBBZG1pbjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFkZEZvb2Q7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=