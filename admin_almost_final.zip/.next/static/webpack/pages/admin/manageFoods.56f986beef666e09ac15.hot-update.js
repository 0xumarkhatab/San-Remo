webpackHotUpdate_N_E("pages/admin/manageFoods",{

/***/ "./API_WORK/fetchAndDispatch.js":
/*!**************************************!*\
  !*** ./API_WORK/fetchAndDispatch.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _components_Categories_CategoriesData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Categories/CategoriesData */ "./components/Categories/CategoriesData.js");
/* harmony import */ var _components_Foods_foodsData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/Foods/foodsData */ "./components/Foods/foodsData.js");
/* harmony import */ var _components_Orders_ordersData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Orders/ordersData */ "./components/Orders/ordersData.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./api */ "./API_WORK/api.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! socket.io-client */ "./node_modules/socket.io-client/build/index.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_8__);



var _s = $RefreshSig$();









function fetchAndDispatch() {
  _s();

  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"])();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
    var _yield$api$get, data;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/category");

          case 2:
            _yield$api$get = _context.sent;
            data = _yield$api$get.data;
            dispatch({
              type: "SET_CATEGORIES",
              CATEGORIES: data
            });

          case 5:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }))();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
    var _yield$api$get2, data;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/food");

          case 2:
            _yield$api$get2 = _context2.sent;
            data = _yield$api$get2.data;
            console.log(data, "Foods");
            dispatch({
              type: "SET_FOODS",
              FOODS: data
            });

          case 6:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }))();

  Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee3() {
    var socket, _yield$api$get3, data;

    return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            socket = Object(socket_io_client__WEBPACK_IMPORTED_MODULE_8__["io"])("http://192.168.100.156:5050");
            _context3.next = 3;
            return _api__WEBPACK_IMPORTED_MODULE_7__["default"].get("/order");

          case 3:
            _yield$api$get3 = _context3.sent;
            data = _yield$api$get3.data;
            socket.on('order', function (order) {
              console.log("Order received ", order);
            });

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }))();

  return 0;
}

_s(fetchAndDispatch, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_3__["useDispatch"]];
});

/* harmony default export */ __webpack_exports__["default"] = (fetchAndDispatch);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vQVBJX1dPUksvZmV0Y2hBbmREaXNwYXRjaC5qcyJdLCJuYW1lcyI6WyJmZXRjaEFuZERpc3BhdGNoIiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsImFwaSIsImdldCIsImRhdGEiLCJ0eXBlIiwiQ0FURUdPUklFUyIsImNvbnNvbGUiLCJsb2ciLCJGT09EUyIsInNvY2tldCIsImlvIiwib24iLCJvcmRlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFNBQVNBLGdCQUFULEdBQTRCO0FBQUE7O0FBQzFCLE1BQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7O0FBRUEsMk5BQUM7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQ3dCQyw0Q0FBRyxDQUFDQyxHQUFKLENBQVEsV0FBUixDQUR4Qjs7QUFBQTtBQUFBO0FBQ1NDLGdCQURULGtCQUNTQSxJQURUO0FBR0NKLG9CQUFRLENBQUM7QUFDUEssa0JBQUksRUFBRSxnQkFEQztBQUVQQyx3QkFBVSxFQUFFRjtBQUZMLGFBQUQsQ0FBUjs7QUFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFEOztBQVNBLDJOQUFDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUNzQkYsNENBQUcsQ0FBQ0MsR0FBSixDQUFRLE9BQVIsQ0FEdEI7O0FBQUE7QUFBQTtBQUNRQyxnQkFEUixtQkFDUUEsSUFEUjtBQUVDRyxtQkFBTyxDQUFDQyxHQUFSLENBQVlKLElBQVosRUFBaUIsT0FBakI7QUFFQUosb0JBQVEsQ0FBQztBQUNQSyxrQkFBSSxFQUFFLFdBREM7QUFFUEksbUJBQUssRUFBRUw7QUFGQSxhQUFELENBQVI7O0FBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBRDs7QUFlQSwyTkFBQztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ09NLGtCQURQLEdBQ2NDLDJEQUFFLENBQUMsNkJBQUQsQ0FEaEI7QUFBQTtBQUFBLG1CQUV3QlQsNENBQUcsQ0FBQ0MsR0FBSixDQUFRLFFBQVIsQ0FGeEI7O0FBQUE7QUFBQTtBQUVTQyxnQkFGVCxtQkFFU0EsSUFGVDtBQUlDTSxrQkFBTSxDQUFDRSxFQUFQLENBQVUsT0FBVixFQUFrQixVQUFDQyxLQUFELEVBQVM7QUFDMUJOLHFCQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWixFQUE4QkssS0FBOUI7QUFJQyxhQUxGOztBQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQUQ7O0FBaUJBLFNBQU8sQ0FBUDtBQUNEOztHQTdDUWQsZ0I7VUFDVUUsdUQ7OztBQThDSkYsK0VBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWRtaW4vbWFuYWdlRm9vZHMuNTZmOTg2YmVlZjY2NmUwOWFjMTUuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlU2VsZWN0b3IsIHVzZURpc3BhdGNoIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7IGNhdGVnb3JpZXMgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9DYXRlZ29yaWVzL0NhdGVnb3JpZXNEYXRhXCI7XHJcbmltcG9ydCB7IGZvb2RzQXJyYXkgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9Gb29kcy9mb29kc0RhdGFcIjtcclxuaW1wb3J0IHsgb3JkZXJzRGF0YSB9IGZyb20gXCIuLi9jb21wb25lbnRzL09yZGVycy9vcmRlcnNEYXRhXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4vYXBpXCI7XHJcbmltcG9ydCB7IGlvIH0gZnJvbSBcInNvY2tldC5pby1jbGllbnRcIjtcclxuXHJcbmZ1bmN0aW9uIGZldGNoQW5kRGlzcGF0Y2goKSB7XHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG5cclxuICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KFwiL2NhdGVnb3J5XCIpO1xyXG5cclxuICAgIGRpc3BhdGNoKHtcclxuICAgICAgdHlwZTogXCJTRVRfQ0FURUdPUklFU1wiLFxyXG4gICAgICBDQVRFR09SSUVTOiBkYXRhLFxyXG4gICAgfSk7XHJcbiAgfSkoKTtcclxuXHJcbiAgKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHtkYXRhfSA9IGF3YWl0IGFwaS5nZXQoXCIvZm9vZFwiKTtcclxuICAgIGNvbnNvbGUubG9nKGRhdGEsXCJGb29kc1wiKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX0ZPT0RTXCIsXHJcbiAgICAgIEZPT0RTOiBkYXRhLFxyXG4gICAgfSk7XHJcbiAgICBcclxuICB9KSgpO1xyXG5cclxuXHJcbiBcclxuXHJcbiBcclxuICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3Qgc29ja2V0PWlvKFwiaHR0cDovLzE5Mi4xNjguMTAwLjE1Njo1MDUwXCIpO1xyXG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBhcGkuZ2V0KFwiL29yZGVyXCIpOyBcclxuICAgICBcclxuICAgIHNvY2tldC5vbignb3JkZXInLChvcmRlcik9PntcclxuICAgICBjb25zb2xlLmxvZyhcIk9yZGVyIHJlY2VpdmVkIFwiLG9yZGVyKVxyXG4gICAgIFxyXG4gICAgICBcclxuICAgICBcclxuICAgICB9KTtcclxuICAgICAgICBcclxuICAgIFxyXG4gIH0pKCk7XHJcblxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIHJldHVybiAwO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaEFuZERpc3BhdGNoO1xyXG4iXSwic291cmNlUm9vdCI6IiJ9