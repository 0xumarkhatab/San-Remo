webpackHotUpdate_N_E("pages/admin/AddFood",{

/***/ "./pages/admin/AddFood.js":
/*!********************************!*\
  !*** ./pages/admin/AddFood.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/Headers/SimpleHeader */ "./components/Headers/SimpleHeader.js");
/* harmony import */ var _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../layouts/Admin */ "./layouts/Admin.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! reactstrap */ "./node_modules/reactstrap/es/index.js");
/* harmony import */ var _components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuSingle */ "./components/SelectMenu/SelectMenuSingle.jsx");
/* harmony import */ var _components_SelectMenu_SelectMenuMultiple__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../components/SelectMenu/SelectMenuMultiple */ "./components/SelectMenu/SelectMenuMultiple.jsx");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../API_WORK/api */ "./API_WORK/api.js");






var _jsxFileName = "E:\\admin\\pages\\admin\\AddFood.js",
    _s = $RefreshSig$();









 // layout for this page

var title, category, sizes, description, price;

function addFood(_ref) {
  _s();

  var _this = this,
      _jsxDEV2,
      _jsxDEV3;

  var item = _ref.item;
  console.log("existing Food Recieved", item);

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      showSizeDiv = _useState[0],
      setShowSizeDiv = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      prices = _useState2[0],
      setPrices = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.title : ""),
      title = _useState3[0],
      setTitle = _useState3[1];

  var _useState4 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.category : ""),
      category = _useState4[0],
      setCategory = _useState4[1];

  var _useState5 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.alleries : []),
      allergies = _useState5[0],
      setAllergies = _useState5[1];

  var _useState6 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.description : ""),
      description = _useState6[0],
      setDescription = _useState6[1];

  var _useState7 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(item ? item.url : ""),
      imageUrl = _useState7[0],
      setImageUrl = _useState7[1];

  var _useState8 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false),
      isextras = _useState8[0],
      setIsextras = _useState8[1];

  var _useState9 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])([]),
      sizes = _useState9[0],
      setSizes = _useState9[1];

  var _useState10 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentSize = _useState10[0],
      setCurrentSize = _useState10[1];

  var _useState11 = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(""),
      currentPrice = _useState11[0],
      setCurrentPrice = _useState11[1];

  var foods = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.FOODS;
  });
  var categories = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state.CATEGORIES;
  });
  console.log(Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"])(function (state) {
    return state;
  }));
  var dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"])();

  function Submitter(e) {
    e.preventDefault();
    sizes.map(function (size, index) {
      console.log(document.getElementById("input-price".concat(index + 1)).value);
      prices.push(document.getElementById("input-price".concat(index + 1)).value);
    });
    var price = document.getElementById("input-price").value;
    var food = sizes.length === 0 ? {
      foodNo: (foods !== null && foods !== void 0 && foods.length ? length : 0) + 1,
      title: title,
      price: price,
      allergies: allergies,
      description: description,
      extras: isextras,
      // imageUrl: imageUrl,
      category: category,
      size: null
    } : sizes.map(function (size, index) {
      return {
        foodNo: (foods !== null && foods !== void 0 && foods.length ? length : 0) + index + 1,
        title: title,
        price: prices[index],
        allergies: allergies,
        description: description,
        extras: isextras,
        category: category,
        size: size
      };
    }); // if(sizes.length > 0 ){
    // food.map(fo=>{
    //   foods.push(fo);
    // });
    // }
    // else{
    //   foods.push(food);
    // }

    if (sizes.length === 0) {
      _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].post("/food", food);
      console.log("one product ", food);
    } else {
      food.map(function (f) {
        return _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].post("/food", f);
      });
      console.log("products ", food);
    }

    Object(E_admin_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.mark(function _callee() {
      return E_admin_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _API_WORK_api__WEBPACK_IMPORTED_MODULE_12__["default"].get("/food").then(function (c) {
                return console.log(c.data);
              });

            case 2:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))(); // console.log(food);

  }

  var onCategoryChange = function onCategoryChange(e) {
    setCategory(e.value);
  };

  var onPriceChanger = function onPriceChanger(e) {
    prices.push(Number(e.target.value));
    setPrices(prices);
  };

  var onTitleChanger = function onTitleChanger(e) {
    setTitle(e.target.value);
  };

  var onImageUrlChange = function onImageUrlChange(e) {
    setImageUrl(e.target.value);
  };

  var onDescriptionChanger = function onDescriptionChanger(e) {
    setDescription(e.target.value);
  };

  var sizeAdder = function sizeAdder(e) {
    var s = sizes;
    s.push({
      price: currentPrice,
      size: currentSize
    });
    console.log("size added ", s);
    setSizes(s);
  };

  var onAllergiesChanger = function onAllergiesChanger(e) {
    var arr = "";
    arr = arr.concat("" + e.target.value);
    arr = arr.split(",", 1000);
    setAllergies(arr);
  };

  var onextrasChanger = function onextrasChanger(e) {
    // console.log(e.target.checked);
    setIsextras(e.target.checked);
  };

  var categoryOptions = categories.map(function (cat) {
    return {
      value: cat.title,
      label: cat.title
    };
  });
  var sizesOptions = [{
    value: "sm",
    label: "Small"
  }, {
    value: "md",
    label: "Medium"
  }, {
    value: "lg",
    label: "Large"
  }, {
    value: "xlg",
    label: "Extra Large"
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 170,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Container"], {
      className: "mt-7",
      fluid: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
          className: "order-xl-1",
          xl: "8",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Card"], {
            className: "bg-secondary shadow",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardHeader"], {
              className: "bg-white border-0"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 176,
              columnNumber: 15
            }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["CardBody"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                className: "align-items-center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  xs: "8",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h3", {
                    className: "mb-0",
                    children: [item ? "Edit Existing Food" : "Add New Food", " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 180,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 179,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                  className: "text-right",
                  xs: "4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_link__WEBPACK_IMPORTED_MODULE_7___default.a, {
                    exact: true,
                    href: "/admin/manageFoods",
                    onClick: function onClick(e) {
                      return Submitter(e);
                    },
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                      onClick: function onClick(e) {
                        return Submitter(e);
                      },
                      color: item ? "success" : "primary",
                      className: "pt3 pb-3 ",
                      children: item ? "Save Changes" : "Add"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 190,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 185,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 184,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 178,
                columnNumber: 17
              }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Form"], {
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mt-2 mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 204,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 203,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 202,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 201,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 text-center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                        children: "Click On Every Field at least Once"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 212,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 211,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 210,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 209,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        className: "mb-2"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 220,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 219,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 218,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 217,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Title"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 229,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-title",
                          placeholder: "pizza , speghati etc....",
                          autoFocus: true,
                          type: "text",
                          defaultValue: item ? item.title : "",
                          onChange: function onChange(e) {
                            onTitleChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 235,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 228,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 227,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 226,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 225,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-category",
                          children: "Select the Category"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 255,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_SelectMenu_SelectMenuSingle__WEBPACK_IMPORTED_MODULE_9__["default"], {
                          id: "input-category",
                          options: categoryOptions,
                          defaultValue: item ? item.category : "",
                          onChangeHandler: onCategoryChange
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 261,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 254,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 253,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 252,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 251,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                        className: "p-3 mt-2",
                        color: "primary",
                        onClick: function onClick(e) {
                          setShowSizeDiv(true);
                        },
                        children: "+ Manage Size"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 295,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 294,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 293,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 292,
                  columnNumber: 19
                }, this), showSizeDiv ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "sizesDiv",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizeSize",
                            children: "Size"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 314,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizesSize",
                            placeholder: "32x45cm",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentSize(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 320,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 313,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 312,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 311,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 310,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                            className: "form-control-label",
                            htmlFor: "input-sizePrice",
                            children: "Price"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 338,
                            columnNumber: 31
                          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                            className: "form-control-alternative",
                            id: "input-sizePrice",
                            placeholder: "4.33\u20AC",
                            type: "text",
                            onChange: function onChange(e) {
                              console.log("sizes got", e.target.value);
                              setCurrentPrice(e.target.value);
                            }
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 344,
                            columnNumber: 31
                          }, this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 337,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 336,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 335,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 334,
                    columnNumber: 23
                  }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    className: "pl-lg-4 ",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                        md: "12",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                          className: "p-3 mt-2",
                          color: "primary",
                          onClick: function onClick(e) {
                            setShowSizeDiv(false);
                            sizeAdder(e);
                          },
                          children: "ADD"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 361,
                          columnNumber: 29
                        }, this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 360,
                        columnNumber: 27
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 359,
                      columnNumber: 25
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 358,
                    columnNumber: 23
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 309,
                  columnNumber: 21
                }, this) : "", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4 ",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: sizes.map(function (s) {
                        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                          className: "mt-2 ",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Table"], {
                            className: "table table-dark",
                            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("thead", {
                              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                                scope: "col",
                                children: "Action"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 388,
                                columnNumber: 35
                              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                                scope: "col",
                                children: "Price"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 389,
                                columnNumber: 35
                              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("th", {
                                scope: "col",
                                children: "Action"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 390,
                                columnNumber: 35
                              }, _this)]
                            }, void 0, true, {
                              fileName: _jsxFileName,
                              lineNumber: 387,
                              columnNumber: 31
                            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("tbody", {}, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 393,
                              columnNumber: 31
                            }, _this)]
                          }, void 0, true, {
                            fileName: _jsxFileName,
                            lineNumber: 386,
                            columnNumber: 31
                          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Button"], {
                            className: "p-3 mt-2",
                            color: "danger",
                            children: "Delete"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 398,
                            columnNumber: 29
                          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                            children: s.price
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 399,
                            columnNumber: 29
                          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                            children: s.size
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 400,
                            columnNumber: 29
                          }, _this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 385,
                          columnNumber: 29
                        }, _this);
                      })
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 381,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 380,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 379,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Image Url"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 420,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-imageUrl",
                          placeholder: "www.example.com/image.png",
                          type: "text",
                          defaultValue: item ? item.url : "",
                          onChange: function onChange(e, v) {
                            return onImageUrlChange(e, v);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 426,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 419,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 418,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 417,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 416,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-price",
                          children: "Price"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 443,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          className: "form-control-alternative",
                          id: "input-price",
                          placeholder: "4.56\u20AC",
                          defaultValue: item ? item.price : "",
                          onChange: function onChange(e, v) {
                            return onPriceChanger(e, v);
                          },
                          type: "text"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 449,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 442,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 441,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 440,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 439,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-allergies",
                          children: "Allergies"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 465,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV2 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-allergies",
                          placeholder: "Allergies i,i,1,2",
                          type: "text"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "defaultValue", item ? item.allergies : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV2, "onChange", function onChange(e, v) {
                          return onAllergiesChanger(e, v);
                        }), _jsxDEV2), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 471,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 464,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 463,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 462,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 461,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
                          className: "form-control-label",
                          htmlFor: "input-address",
                          children: "Description"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 488,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], (_jsxDEV3 = {
                          className: "form-control-alternative",
                          defaultValue: "",
                          id: "input-address",
                          placeholder: "Description"
                        }, Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "defaultValue", item ? item.description : ""), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "type", "textarea"), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "rows", 5), Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_jsxDEV3, "onChange", function onChange(e) {
                          onDescriptionChanger(e);
                        }), _jsxDEV3), void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 494,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 487,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 486,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 485,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 484,
                  columnNumber: 19
                }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "pl-lg-4",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Row"], {
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Col"], {
                      md: "12",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["FormGroup"], {
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_8__["Input"], {
                          type: "checkbox",
                          onChange: function onChange(e) {
                            onextrasChanger(e);
                          }
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 514,
                          columnNumber: 27
                        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                          children: "extras Included?"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 520,
                          columnNumber: 27
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 513,
                        columnNumber: 25
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 512,
                      columnNumber: 23
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 511,
                    columnNumber: 21
                  }, this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 510,
                  columnNumber: 19
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 200,
                columnNumber: 17
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 177,
              columnNumber: 15
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 175,
            columnNumber: 13
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 174,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 172,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(addFood, "zeK8nBsDwmkHoXI2DEH0KRCbtF4=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useSelector"], react_redux__WEBPACK_IMPORTED_MODULE_11__["useDispatch"]];
});

addFood.layout = _layouts_Admin__WEBPACK_IMPORTED_MODULE_6__["default"];
/* harmony default export */ __webpack_exports__["default"] = (addFood);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYWRtaW4vQWRkRm9vZC5qcyJdLCJuYW1lcyI6WyJ0aXRsZSIsImNhdGVnb3J5Iiwic2l6ZXMiLCJkZXNjcmlwdGlvbiIsInByaWNlIiwiYWRkRm9vZCIsIml0ZW0iLCJjb25zb2xlIiwibG9nIiwidXNlU3RhdGUiLCJzaG93U2l6ZURpdiIsInNldFNob3dTaXplRGl2IiwicHJpY2VzIiwic2V0UHJpY2VzIiwic2V0VGl0bGUiLCJzZXRDYXRlZ29yeSIsImFsbGVyaWVzIiwiYWxsZXJnaWVzIiwic2V0QWxsZXJnaWVzIiwic2V0RGVzY3JpcHRpb24iLCJ1cmwiLCJpbWFnZVVybCIsInNldEltYWdlVXJsIiwiaXNleHRyYXMiLCJzZXRJc2V4dHJhcyIsInNldFNpemVzIiwiY3VycmVudFNpemUiLCJzZXRDdXJyZW50U2l6ZSIsImN1cnJlbnRQcmljZSIsInNldEN1cnJlbnRQcmljZSIsImZvb2RzIiwidXNlU2VsZWN0b3IiLCJzdGF0ZSIsIkZPT0RTIiwiY2F0ZWdvcmllcyIsIkNBVEVHT1JJRVMiLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwiU3VibWl0dGVyIiwiZSIsInByZXZlbnREZWZhdWx0IiwibWFwIiwic2l6ZSIsImluZGV4IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInZhbHVlIiwicHVzaCIsImZvb2QiLCJsZW5ndGgiLCJmb29kTm8iLCJleHRyYXMiLCJhcGkiLCJwb3N0IiwiZiIsImdldCIsInRoZW4iLCJjIiwiZGF0YSIsIm9uQ2F0ZWdvcnlDaGFuZ2UiLCJvblByaWNlQ2hhbmdlciIsIk51bWJlciIsInRhcmdldCIsIm9uVGl0bGVDaGFuZ2VyIiwib25JbWFnZVVybENoYW5nZSIsIm9uRGVzY3JpcHRpb25DaGFuZ2VyIiwic2l6ZUFkZGVyIiwicyIsIm9uQWxsZXJnaWVzQ2hhbmdlciIsImFyciIsImNvbmNhdCIsInNwbGl0Iiwib25leHRyYXNDaGFuZ2VyIiwiY2hlY2tlZCIsImNhdGVnb3J5T3B0aW9ucyIsImNhdCIsImxhYmVsIiwic2l6ZXNPcHRpb25zIiwidiIsImxheW91dCIsIkFkbWluIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQWNBO0FBQ0E7QUFDQTtDQUdBOztBQUNBLElBQUlBLEtBQUosRUFBV0MsUUFBWCxFQUFxQkMsS0FBckIsRUFBNEJDLFdBQTVCLEVBQXlDQyxLQUF6Qzs7QUFFQSxTQUFTQyxPQUFULE9BQTJCO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBLE1BQVJDLElBQVEsUUFBUkEsSUFBUTtBQUN6QkMsU0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQVosRUFBc0NGLElBQXRDOztBQUR5QixrQkFFYUcsc0RBQVEsQ0FBQyxLQUFELENBRnJCO0FBQUEsTUFFbEJDLFdBRmtCO0FBQUEsTUFFTEMsY0FGSzs7QUFBQSxtQkFJR0Ysc0RBQVEsQ0FBQyxFQUFELENBSlg7QUFBQSxNQUlsQkcsTUFKa0I7QUFBQSxNQUlWQyxTQUpVOztBQUFBLG1CQUtDSixzREFBUSxDQUFDSCxJQUFJLEdBQUdBLElBQUksQ0FBQ04sS0FBUixHQUFnQixFQUFyQixDQUxUO0FBQUEsTUFLbEJBLEtBTGtCO0FBQUEsTUFLWGMsUUFMVzs7QUFBQSxtQkFNT0wsc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNMLFFBQVIsR0FBbUIsRUFBeEIsQ0FOZjtBQUFBLE1BTWxCQSxRQU5rQjtBQUFBLE1BTVJjLFdBTlE7O0FBQUEsbUJBT1NOLHNEQUFRLENBQUNILElBQUksR0FBR0EsSUFBSSxDQUFDVSxRQUFSLEdBQW1CLEVBQXhCLENBUGpCO0FBQUEsTUFPbEJDLFNBUGtCO0FBQUEsTUFPUEMsWUFQTzs7QUFBQSxtQkFRYVQsc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNILFdBQVIsR0FBc0IsRUFBM0IsQ0FSckI7QUFBQSxNQVFsQkEsV0FSa0I7QUFBQSxNQVFMZ0IsY0FSSzs7QUFBQSxtQkFTT1Ysc0RBQVEsQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLENBQUNjLEdBQVIsR0FBYyxFQUFuQixDQVRmO0FBQUEsTUFTbEJDLFFBVGtCO0FBQUEsTUFTUkMsV0FUUTs7QUFBQSxtQkFVT2Isc0RBQVEsQ0FBQyxLQUFELENBVmY7QUFBQSxNQVVsQmMsUUFWa0I7QUFBQSxNQVVSQyxXQVZROztBQUFBLG1CQVlDZixzREFBUSxDQUFDLEVBQUQsQ0FaVDtBQUFBLE1BWWxCUCxLQVprQjtBQUFBLE1BWVh1QixRQVpXOztBQUFBLG9CQWFhaEIsc0RBQVEsQ0FBQyxFQUFELENBYnJCO0FBQUEsTUFhbEJpQixXQWJrQjtBQUFBLE1BYUxDLGNBYks7O0FBQUEsb0JBY2VsQixzREFBUSxDQUFDLEVBQUQsQ0FkdkI7QUFBQSxNQWNsQm1CLFlBZGtCO0FBQUEsTUFjSkMsZUFkSTs7QUFnQnpCLE1BQU1DLEtBQUssR0FBR0MsZ0VBQVcsQ0FBQyxVQUFDQyxLQUFEO0FBQUEsV0FBV0EsS0FBSyxDQUFDQyxLQUFqQjtBQUFBLEdBQUQsQ0FBekI7QUFDQSxNQUFNQyxVQUFVLEdBQUdILGdFQUFXLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFdBQVdBLEtBQUssQ0FBQ0csVUFBakI7QUFBQSxHQUFELENBQTlCO0FBQ0E1QixTQUFPLENBQUNDLEdBQVIsQ0FBWXVCLGdFQUFXLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFdBQVdBLEtBQVg7QUFBQSxHQUFELENBQXZCO0FBRUEsTUFBTUksUUFBUSxHQUFHQyxnRUFBVyxFQUE1Qjs7QUFFQSxXQUFTQyxTQUFULENBQW1CQyxDQUFuQixFQUFzQjtBQUNwQkEsS0FBQyxDQUFDQyxjQUFGO0FBRUF0QyxTQUFLLENBQUN1QyxHQUFOLENBQVUsVUFBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQ3pCcEMsYUFBTyxDQUFDQyxHQUFSLENBQVlvQyxRQUFRLENBQUNDLGNBQVQsc0JBQXNDRixLQUFLLEdBQUcsQ0FBOUMsR0FBbURHLEtBQS9EO0FBQ0FsQyxZQUFNLENBQUNtQyxJQUFQLENBQVlILFFBQVEsQ0FBQ0MsY0FBVCxzQkFBc0NGLEtBQUssR0FBRyxDQUE5QyxHQUFtREcsS0FBL0Q7QUFDRCxLQUhEO0FBS0EsUUFBSTFDLEtBQUssR0FBR3dDLFFBQVEsQ0FBQ0MsY0FBVCxDQUF3QixhQUF4QixFQUF1Q0MsS0FBbkQ7QUFFQSxRQUFNRSxJQUFJLEdBQ1I5QyxLQUFLLENBQUMrQyxNQUFOLEtBQWlCLENBQWpCLEdBQ0k7QUFDRUMsWUFBTSxFQUFFLENBQUNwQixLQUFLLFNBQUwsSUFBQUEsS0FBSyxXQUFMLElBQUFBLEtBQUssQ0FBRW1CLE1BQVAsR0FBZ0JBLE1BQWhCLEdBQXlCLENBQTFCLElBQStCLENBRHpDO0FBRUVqRCxXQUFLLEVBQUVBLEtBRlQ7QUFHRUksV0FBSyxFQUFFQSxLQUhUO0FBSUVhLGVBQVMsRUFBRUEsU0FKYjtBQUtFZCxpQkFBVyxFQUFFQSxXQUxmO0FBTUVnRCxZQUFNLEVBQUU1QixRQU5WO0FBT0U7QUFDQXRCLGNBQVEsRUFBRUEsUUFSWjtBQVNFeUMsVUFBSSxFQUFFO0FBVFIsS0FESixHQVlJeEMsS0FBSyxDQUFDdUMsR0FBTixDQUFVLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUN6QixhQUFPO0FBQ0xPLGNBQU0sRUFBRSxDQUFDcEIsS0FBSyxTQUFMLElBQUFBLEtBQUssV0FBTCxJQUFBQSxLQUFLLENBQUVtQixNQUFQLEdBQWdCQSxNQUFoQixHQUF5QixDQUExQixJQUErQk4sS0FBL0IsR0FBdUMsQ0FEMUM7QUFHTDNDLGFBQUssRUFBRUEsS0FIRjtBQUlMSSxhQUFLLEVBQUVRLE1BQU0sQ0FBQytCLEtBQUQsQ0FKUjtBQUtMMUIsaUJBQVMsRUFBRUEsU0FMTjtBQU1MZCxtQkFBVyxFQUFFQSxXQU5SO0FBT0xnRCxjQUFNLEVBQUU1QixRQVBIO0FBU0x0QixnQkFBUSxFQUFFQSxRQVRMO0FBVUx5QyxZQUFJLEVBQUVBO0FBVkQsT0FBUDtBQVlELEtBYkQsQ0FiTixDQVZvQixDQXNDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxRQUFJeEMsS0FBSyxDQUFDK0MsTUFBTixLQUFpQixDQUFyQixFQUF3QjtBQUN0QkcsNERBQUcsQ0FBQ0MsSUFBSixDQUFTLE9BQVQsRUFBa0JMLElBQWxCO0FBQ0F6QyxhQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTRCd0MsSUFBNUI7QUFDRCxLQUhELE1BR087QUFDTEEsVUFBSSxDQUFDUCxHQUFMLENBQVMsVUFBQ2EsQ0FBRDtBQUFBLGVBQU9GLHNEQUFHLENBQUNDLElBQUosQ0FBUyxPQUFULEVBQWtCQyxDQUFsQixDQUFQO0FBQUEsT0FBVDtBQUNBL0MsYUFBTyxDQUFDQyxHQUFSLENBQVksV0FBWixFQUF5QndDLElBQXpCO0FBQ0Q7O0FBQ0QsNk5BQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ09JLHNEQUFHLENBQUNHLEdBQUosQ0FBUSxPQUFSLEVBQWlCQyxJQUFqQixDQUFzQixVQUFDQyxDQUFEO0FBQUEsdUJBQU9sRCxPQUFPLENBQUNDLEdBQVIsQ0FBWWlELENBQUMsQ0FBQ0MsSUFBZCxDQUFQO0FBQUEsZUFBdEIsQ0FEUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFELEtBdERvQixDQTBEcEI7O0FBQ0Q7O0FBQ0QsTUFBTUMsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixDQUFDcEIsQ0FBRCxFQUFPO0FBQzlCeEIsZUFBVyxDQUFDd0IsQ0FBQyxDQUFDTyxLQUFILENBQVg7QUFDRCxHQUZEOztBQUdBLE1BQU1jLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsQ0FBQ3JCLENBQUQsRUFBTztBQUM1QjNCLFVBQU0sQ0FBQ21DLElBQVAsQ0FBWWMsTUFBTSxDQUFDdEIsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFsQjtBQUNBakMsYUFBUyxDQUFDRCxNQUFELENBQVQ7QUFDRCxHQUhEOztBQUlBLE1BQU1tRCxjQUFjLEdBQUcsU0FBakJBLGNBQWlCLENBQUN4QixDQUFELEVBQU87QUFDNUJ6QixZQUFRLENBQUN5QixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFWLENBQVI7QUFDRCxHQUZEOztBQUlBLE1BQU1rQixnQkFBZ0IsR0FBRyxTQUFuQkEsZ0JBQW1CLENBQUN6QixDQUFELEVBQU87QUFDOUJqQixlQUFXLENBQUNpQixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFWLENBQVg7QUFDRCxHQUZEOztBQUlBLE1BQU1tQixvQkFBb0IsR0FBRyxTQUF2QkEsb0JBQXVCLENBQUMxQixDQUFELEVBQU87QUFDbENwQixrQkFBYyxDQUFDb0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFkO0FBQ0QsR0FGRDs7QUFJQSxNQUFNb0IsU0FBUyxHQUFHLFNBQVpBLFNBQVksQ0FBQzNCLENBQUQsRUFBTztBQUN2QixRQUFNNEIsQ0FBQyxHQUFHakUsS0FBVjtBQUVBaUUsS0FBQyxDQUFDcEIsSUFBRixDQUFPO0FBQ0wzQyxXQUFLLEVBQUV3QixZQURGO0FBRUxjLFVBQUksRUFBRWhCO0FBRkQsS0FBUDtBQUlBbkIsV0FBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQjJELENBQTNCO0FBRUExQyxZQUFRLENBQUMwQyxDQUFELENBQVI7QUFDRCxHQVZEOztBQVlBLE1BQU1DLGtCQUFrQixHQUFHLFNBQXJCQSxrQkFBcUIsQ0FBQzdCLENBQUQsRUFBTztBQUNoQyxRQUFJOEIsR0FBRyxHQUFHLEVBQVY7QUFDQUEsT0FBRyxHQUFHQSxHQUFHLENBQUNDLE1BQUosQ0FBVyxLQUFLL0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBekIsQ0FBTjtBQUNBdUIsT0FBRyxHQUFHQSxHQUFHLENBQUNFLEtBQUosQ0FBVSxHQUFWLEVBQWUsSUFBZixDQUFOO0FBQ0FyRCxnQkFBWSxDQUFDbUQsR0FBRCxDQUFaO0FBQ0QsR0FMRDs7QUFNQSxNQUFNRyxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUNqQyxDQUFELEVBQU87QUFDN0I7QUFFQWYsZUFBVyxDQUFDZSxDQUFDLENBQUN1QixNQUFGLENBQVNXLE9BQVYsQ0FBWDtBQUNELEdBSkQ7O0FBTUEsTUFBTUMsZUFBZSxHQUFHeEMsVUFBVSxDQUFDTyxHQUFYLENBQWUsVUFBQ2tDLEdBQUQsRUFBUztBQUM5QyxXQUFPO0FBQ0w3QixXQUFLLEVBQUU2QixHQUFHLENBQUMzRSxLQUROO0FBRUw0RSxXQUFLLEVBQUVELEdBQUcsQ0FBQzNFO0FBRk4sS0FBUDtBQUlELEdBTHVCLENBQXhCO0FBT0EsTUFBTTZFLFlBQVksR0FBRyxDQUNuQjtBQUFFL0IsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQURtQixFQUVuQjtBQUFFOUIsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQUZtQixFQUduQjtBQUFFOUIsU0FBSyxFQUFFLElBQVQ7QUFBZThCLFNBQUssRUFBRTtBQUF0QixHQUhtQixFQUluQjtBQUFFOUIsU0FBSyxFQUFFLEtBQVQ7QUFBZ0I4QixTQUFLLEVBQUU7QUFBdkIsR0FKbUIsQ0FBckI7QUFPQSxzQkFDRTtBQUFBLDRCQUNFLHFFQUFDLHdFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQUdFLHFFQUFDLG9EQUFEO0FBQVcsZUFBUyxFQUFDLE1BQXJCO0FBQTRCLFdBQUssTUFBakM7QUFBQSw2QkFDRSxxRUFBQyw4Q0FBRDtBQUFBLCtCQUNFLHFFQUFDLDhDQUFEO0FBQUssbUJBQVMsRUFBQyxZQUFmO0FBQTRCLFlBQUUsRUFBQyxHQUEvQjtBQUFBLGlDQUNFLHFFQUFDLCtDQUFEO0FBQU0scUJBQVMsRUFBQyxxQkFBaEI7QUFBQSxvQ0FDRSxxRUFBQyxxREFBRDtBQUFZLHVCQUFTLEVBQUM7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFERixlQUVFLHFFQUFDLG1EQUFEO0FBQUEsc0NBQ0UscUVBQUMsOENBQUQ7QUFBSyx5QkFBUyxFQUFDLG9CQUFmO0FBQUEsd0NBQ0UscUVBQUMsOENBQUQ7QUFBSyxvQkFBRSxFQUFDLEdBQVI7QUFBQSx5Q0FDRTtBQUFJLDZCQUFTLEVBQUMsTUFBZDtBQUFBLCtCQUNHdEUsSUFBSSxHQUFHLG9CQUFILEdBQTBCLGNBRGpDLEVBQ2lELEdBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFNRSxxRUFBQyw4Q0FBRDtBQUFLLDJCQUFTLEVBQUMsWUFBZjtBQUE0QixvQkFBRSxFQUFDLEdBQS9CO0FBQUEseUNBQ0UscUVBQUMsZ0RBQUQ7QUFDRSx5QkFBSyxNQURQO0FBRUUsd0JBQUksRUFBQyxvQkFGUDtBQUdFLDJCQUFPLEVBQUUsaUJBQUNpQyxDQUFEO0FBQUEsNkJBQU9ELFNBQVMsQ0FBQ0MsQ0FBRCxDQUFoQjtBQUFBLHFCQUhYO0FBQUEsMkNBS0UscUVBQUMsaURBQUQ7QUFDRSw2QkFBTyxFQUFFLGlCQUFDQSxDQUFEO0FBQUEsK0JBQU9ELFNBQVMsQ0FBQ0MsQ0FBRCxDQUFoQjtBQUFBLHVCQURYO0FBRUUsMkJBQUssRUFBRWpDLElBQUksR0FBRyxTQUFILEdBQWUsU0FGNUI7QUFHRSwrQkFBUyxFQUFDLFdBSFo7QUFBQSxnQ0FLR0EsSUFBSSxHQUFHLGNBQUgsR0FBb0I7QUFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFERixlQXVCRSxxRUFBQywrQ0FBRDtBQUFBLHdDQUNFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFO0FBQUksaUNBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREYsZUFTRTtBQUFLLDJCQUFTLEVBQUMscUJBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVEYsZUFpQkU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0U7QUFBSSxpQ0FBUyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFqQkYsZUF5QkU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLG1DQUFTLEVBQUMsMEJBRFo7QUFFRSw0QkFBRSxFQUFDLGFBRkw7QUFHRSxxQ0FBVyxFQUFDLDBCQUhkO0FBSUUsbUNBQVMsTUFKWDtBQUtFLDhCQUFJLEVBQUMsTUFMUDtBQU1FLHNDQUFZLEVBQUVBLElBQUksR0FBR0EsSUFBSSxDQUFDTixLQUFSLEdBQWdCLEVBTnBDO0FBT0Usa0NBQVEsRUFBRSxrQkFBQ3VDLENBQUQsRUFBTztBQUNmd0IsMENBQWMsQ0FBQ3hCLENBQUQsQ0FBZDtBQUNEO0FBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBekJGLGVBbURFO0FBQUssMkJBQVMsRUFBQyxVQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxnQkFGVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FERixlQU9FLHFFQUFDLCtFQUFEO0FBQ0UsNEJBQUUsRUFBQyxnQkFETDtBQUVFLGlDQUFPLEVBQUVtQyxlQUZYO0FBR0Usc0NBQVksRUFBRXBFLElBQUksR0FBR0EsSUFBSSxDQUFDTCxRQUFSLEdBQW1CLEVBSHZDO0FBSUUseUNBQWUsRUFBRTBEO0FBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQW5ERixlQTRGRTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxpREFBRDtBQUNFLGlDQUFTLEVBQUMsVUFEWjtBQUVFLDZCQUFLLEVBQUMsU0FGUjtBQUdFLCtCQUFPLEVBQUUsaUJBQUNwQixDQUFELEVBQU87QUFDZDVCLHdDQUFjLENBQUMsSUFBRCxDQUFkO0FBQ0QseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBNUZGLEVBNEdHRCxXQUFXLGdCQUNWO0FBQUssMkJBQVMsRUFBQyxVQUFmO0FBQUEsMENBQ0U7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsb0RBQUQ7QUFBQSxrREFDRTtBQUNFLHFDQUFTLEVBQUMsb0JBRFo7QUFFRSxtQ0FBTyxFQUFDLGdCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxxQ0FBUyxFQUFDLDBCQURaO0FBRUUsOEJBQUUsRUFBQyxpQkFGTDtBQUdFLHVDQUFXLEVBQUMsU0FIZDtBQUlFLGdDQUFJLEVBQUMsTUFKUDtBQUtFLG9DQUFRLEVBQUUsa0JBQUM2QixDQUFELEVBQU87QUFDZmhDLHFDQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXlCK0IsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBbEM7QUFDQW5CLDRDQUFjLENBQUNZLENBQUMsQ0FBQ3VCLE1BQUYsQ0FBU2hCLEtBQVYsQ0FBZDtBQUNEO0FBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREYsZUF5QkU7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsb0RBQUQ7QUFBQSxrREFDRTtBQUNFLHFDQUFTLEVBQUMsb0JBRFo7QUFFRSxtQ0FBTyxFQUFDLGlCQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxxQ0FBUyxFQUFDLDBCQURaO0FBRUUsOEJBQUUsRUFBQyxpQkFGTDtBQUdFLHVDQUFXLEVBQUMsWUFIZDtBQUlFLGdDQUFJLEVBQUMsTUFKUDtBQUtFLG9DQUFRLEVBQUUsa0JBQUNQLENBQUQsRUFBTztBQUNmaEMscUNBQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBeUIrQixDQUFDLENBQUN1QixNQUFGLENBQVNoQixLQUFsQztBQUNBakIsNkNBQWUsQ0FBQ1UsQ0FBQyxDQUFDdUIsTUFBRixDQUFTaEIsS0FBVixDQUFmO0FBQ0Q7QUFSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkF6QkYsZUFpREU7QUFBSyw2QkFBUyxFQUFDLFVBQWY7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDZDQUNFLHFFQUFDLDhDQUFEO0FBQUssMEJBQUUsRUFBQyxJQUFSO0FBQUEsK0NBQ0UscUVBQUMsaURBQUQ7QUFDRSxtQ0FBUyxFQUFDLFVBRFo7QUFFRSwrQkFBSyxFQUFDLFNBRlI7QUFHRSxpQ0FBTyxFQUFFLGlCQUFDUCxDQUFELEVBQU87QUFDZDVCLDBDQUFjLENBQUMsS0FBRCxDQUFkO0FBQ0F1RCxxQ0FBUyxDQUFDM0IsQ0FBRCxDQUFUO0FBQ0QsMkJBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFEVSxHQW9FVixFQWhMSixlQW1MRTtBQUFLLDJCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSxnQ0FFRXJDLEtBQUssQ0FBQ3VDLEdBQU4sQ0FBVSxVQUFBMEIsQ0FBQyxFQUFFO0FBQ1gsNENBQ0U7QUFBSyxtQ0FBUyxFQUFDLE9BQWY7QUFBQSxrREFDRSxxRUFBQyxnREFBRDtBQUFPLHFDQUFTLEVBQUMsa0JBQWpCO0FBQUEsb0RBQ0E7QUFBQSxzREFDSTtBQUFJLHFDQUFLLEVBQUMsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FESixlQUVJO0FBQUkscUNBQUssRUFBQyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUZKLGVBR0k7QUFBSSxxQ0FBSyxFQUFDLEtBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURBLGVBT0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FQQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREYsZUFhQSxxRUFBQyxpREFBRDtBQUFRLHFDQUFTLEVBQUMsVUFBbEI7QUFBNkIsaUNBQUssRUFBQyxRQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FiQSxlQWNBO0FBQUEsc0NBQUlBLENBQUMsQ0FBQy9EO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FkQSxlQWVBO0FBQUEsc0NBQUkrRCxDQUFDLENBQUN6QjtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBZkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURGO0FBb0JELHVCQXJCRDtBQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuTEYsZUF3TkU7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGVBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLG1DQUFTLEVBQUMsMEJBRFo7QUFFRSw0QkFBRSxFQUFDLGdCQUZMO0FBR0UscUNBQVcsRUFBQywyQkFIZDtBQUlFLDhCQUFJLEVBQUMsTUFKUDtBQUtFLHNDQUFZLEVBQUVwQyxJQUFJLEdBQUdBLElBQUksQ0FBQ2MsR0FBUixHQUFjLEVBTGxDO0FBTUUsa0NBQVEsRUFBRSxrQkFBQ21CLENBQUQsRUFBSXVDLENBQUo7QUFBQSxtQ0FBVWQsZ0JBQWdCLENBQUN6QixDQUFELEVBQUl1QyxDQUFKLENBQTFCO0FBQUE7QUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkF4TkYsZUErT0U7QUFBSywyQkFBUyxFQUFDLFNBQWY7QUFBQSx5Q0FDRSxxRUFBQyw4Q0FBRDtBQUFBLDJDQUNFLHFFQUFDLDhDQUFEO0FBQUssd0JBQUUsRUFBQyxJQUFSO0FBQUEsNkNBQ0UscUVBQUMsb0RBQUQ7QUFBQSxnREFDRTtBQUNFLG1DQUFTLEVBQUMsb0JBRFo7QUFFRSxpQ0FBTyxFQUFDLGFBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLG1DQUFTLEVBQUMsMEJBRFo7QUFFRSw0QkFBRSxFQUFDLGFBRkw7QUFHRSxxQ0FBVyxFQUFDLFlBSGQ7QUFJRSxzQ0FBWSxFQUFFeEUsSUFBSSxHQUFHQSxJQUFJLENBQUNGLEtBQVIsR0FBZ0IsRUFKcEM7QUFLRSxrQ0FBUSxFQUFFLGtCQUFDbUMsQ0FBRCxFQUFJdUMsQ0FBSjtBQUFBLG1DQUFVbEIsY0FBYyxDQUFDckIsQ0FBRCxFQUFJdUMsQ0FBSixDQUF4QjtBQUFBLDJCQUxaO0FBTUUsOEJBQUksRUFBQztBQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQS9PRixlQXFRRTtBQUFLLDJCQUFTLEVBQUMsU0FBZjtBQUFBLHlDQUNFLHFFQUFDLDhDQUFEO0FBQUEsMkNBQ0UscUVBQUMsOENBQUQ7QUFBSyx3QkFBRSxFQUFDLElBQVI7QUFBQSw2Q0FDRSxxRUFBQyxvREFBRDtBQUFBLGdEQUNFO0FBQ0UsbUNBQVMsRUFBQyxvQkFEWjtBQUVFLGlDQUFPLEVBQUMsaUJBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRSxxRUFBQyxnREFBRDtBQUNFLG1DQUFTLEVBQUMsMEJBRFo7QUFFRSxzQ0FBWSxFQUFDLEVBRmY7QUFHRSw0QkFBRSxFQUFDLGlCQUhMO0FBSUUscUNBQVcsRUFBQyxtQkFKZDtBQUtFLDhCQUFJLEVBQUM7QUFMUCxtS0FNZ0J4RSxJQUFJLEdBQUdBLElBQUksQ0FBQ1csU0FBUixHQUFvQixFQU54Qyx1SUFPWSxrQkFBQ3NCLENBQUQsRUFBSXVDLENBQUo7QUFBQSxpQ0FBVVYsa0JBQWtCLENBQUM3QixDQUFELEVBQUl1QyxDQUFKLENBQTVCO0FBQUEseUJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBclFGLGVBNFJFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0U7QUFDRSxtQ0FBUyxFQUFDLG9CQURaO0FBRUUsaUNBQU8sRUFBQyxlQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdDQURGLGVBT0UscUVBQUMsZ0RBQUQ7QUFDRSxtQ0FBUyxFQUFDLDBCQURaO0FBRUUsc0NBQVksRUFBQyxFQUZmO0FBR0UsNEJBQUUsRUFBQyxlQUhMO0FBSUUscUNBQVcsRUFBQztBQUpkLG1LQUtnQnhFLElBQUksR0FBR0EsSUFBSSxDQUFDSCxXQUFSLEdBQXNCLEVBTDFDLG1JQU1PLFVBTlAsbUlBT1EsQ0FQUix1SUFRWSxrQkFBQ29DLENBQUQsRUFBTztBQUNmMEIsOENBQW9CLENBQUMxQixDQUFELENBQXBCO0FBQ0QseUJBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBNVJGLGVBc1RFO0FBQUssMkJBQVMsRUFBQyxTQUFmO0FBQUEseUNBQ0UscUVBQUMsOENBQUQ7QUFBQSwyQ0FDRSxxRUFBQyw4Q0FBRDtBQUFLLHdCQUFFLEVBQUMsSUFBUjtBQUFBLDZDQUNFLHFFQUFDLG9EQUFEO0FBQUEsZ0RBQ0UscUVBQUMsZ0RBQUQ7QUFDRSw4QkFBSSxFQUFDLFVBRFA7QUFFRSxrQ0FBUSxFQUFFLGtCQUFDQSxDQUFELEVBQU87QUFDZmlDLDJDQUFlLENBQUNqQyxDQUFELENBQWY7QUFDRDtBQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBREYsZUFPRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBdFRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUhGO0FBQUEsa0JBREY7QUE2V0Q7O0dBeGZRbEMsTztVQWdCTzBCLHdELEVBQ0tBLHdELEVBQ1BBLHdELEVBRUtNLHdEOzs7QUFxZW5CaEMsT0FBTyxDQUFDMEUsTUFBUixHQUFpQkMsc0RBQWpCO0FBRWUzRSxzRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9hZG1pbi9BZGRGb29kLmI1ZmU1Zjg5NTA1NjQwOWY0MzE3LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpbXBsZUhlYWRlciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9IZWFkZXJzL1NpbXBsZUhlYWRlclwiO1xyXG5pbXBvcnQgQWRtaW4gZnJvbSBcIi4uLy4uL2xheW91dHMvQWRtaW5cIjtcclxuXHJcbmltcG9ydCBMaW5rIGZyb20gXCJuZXh0L2xpbmtcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgQnV0dG9uLFxyXG4gIENhcmQsXHJcbiAgQ2FyZEhlYWRlcixcclxuICBDYXJkQm9keSxcclxuICBGb3JtR3JvdXAsXHJcbiAgRm9ybSxcclxuICBJbnB1dCxcclxuICBDb250YWluZXIsXHJcbiAgUm93LFxyXG4gIENvbCxcclxuICBUYWJsZSxcclxufSBmcm9tIFwicmVhY3RzdHJhcFwiO1xyXG5cclxuaW1wb3J0IFNlbGVjdE1lbnVTaW5nbGUgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvU2VsZWN0TWVudS9TZWxlY3RNZW51U2luZ2xlXCI7XHJcbmltcG9ydCBTZWxlY3RNZW51TXVsdGlwbGUgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvU2VsZWN0TWVudS9TZWxlY3RNZW51TXVsdGlwbGVcIjtcclxuaW1wb3J0IHsgdXNlU2VsZWN0b3IsIHVzZURpc3BhdGNoIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uLy4uL0FQSV9XT1JLL2FwaVwiO1xyXG5cclxuLy8gbGF5b3V0IGZvciB0aGlzIHBhZ2VcclxubGV0IHRpdGxlLCBjYXRlZ29yeSwgc2l6ZXMsIGRlc2NyaXB0aW9uLCBwcmljZTtcclxuXHJcbmZ1bmN0aW9uIGFkZEZvb2QoeyBpdGVtIH0pIHtcclxuICBjb25zb2xlLmxvZyhcImV4aXN0aW5nIEZvb2QgUmVjaWV2ZWRcIiwgaXRlbSk7XHJcbiAgY29uc3QgW3Nob3dTaXplRGl2LCBzZXRTaG93U2l6ZURpdl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtwcmljZXMsIHNldFByaWNlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShpdGVtID8gaXRlbS50aXRsZSA6IFwiXCIpO1xyXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0uY2F0ZWdvcnkgOiBcIlwiKTtcclxuICBjb25zdCBbYWxsZXJnaWVzLCBzZXRBbGxlcmdpZXNdID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0uYWxsZXJpZXMgOiBbXSk7XHJcbiAgY29uc3QgW2Rlc2NyaXB0aW9uLCBzZXREZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZShpdGVtID8gaXRlbS5kZXNjcmlwdGlvbiA6IFwiXCIpO1xyXG4gIGNvbnN0IFtpbWFnZVVybCwgc2V0SW1hZ2VVcmxdID0gdXNlU3RhdGUoaXRlbSA/IGl0ZW0udXJsIDogXCJcIik7XHJcbiAgY29uc3QgW2lzZXh0cmFzLCBzZXRJc2V4dHJhc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtzaXplcywgc2V0U2l6ZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXJyZW50U2l6ZSwgc2V0Q3VycmVudFNpemVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2N1cnJlbnRQcmljZSwgc2V0Q3VycmVudFByaWNlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBmb29kcyA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuRk9PRFMpO1xyXG4gIGNvbnN0IGNhdGVnb3JpZXMgPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLkNBVEVHT1JJRVMpO1xyXG4gIGNvbnNvbGUubG9nKHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUpKTtcclxuXHJcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG5cclxuICBmdW5jdGlvbiBTdWJtaXR0ZXIoZSkge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIHNpemVzLm1hcCgoc2l6ZSwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc29sZS5sb2coZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYGlucHV0LXByaWNlJHtpbmRleCArIDF9YCkudmFsdWUpO1xyXG4gICAgICBwcmljZXMucHVzaChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgaW5wdXQtcHJpY2Uke2luZGV4ICsgMX1gKS52YWx1ZSk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBsZXQgcHJpY2UgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImlucHV0LXByaWNlXCIpLnZhbHVlO1xyXG5cclxuICAgIGNvbnN0IGZvb2QgPVxyXG4gICAgICBzaXplcy5sZW5ndGggPT09IDBcclxuICAgICAgICA/IHtcclxuICAgICAgICAgICAgZm9vZE5vOiAoZm9vZHM/Lmxlbmd0aCA/IGxlbmd0aCA6IDApICsgMSxcclxuICAgICAgICAgICAgdGl0bGU6IHRpdGxlLFxyXG4gICAgICAgICAgICBwcmljZTogcHJpY2UsXHJcbiAgICAgICAgICAgIGFsbGVyZ2llczogYWxsZXJnaWVzLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIGV4dHJhczogaXNleHRyYXMsXHJcbiAgICAgICAgICAgIC8vIGltYWdlVXJsOiBpbWFnZVVybCxcclxuICAgICAgICAgICAgY2F0ZWdvcnk6IGNhdGVnb3J5LFxyXG4gICAgICAgICAgICBzaXplOiBudWxsLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDogc2l6ZXMubWFwKChzaXplLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIGZvb2RObzogKGZvb2RzPy5sZW5ndGggPyBsZW5ndGggOiAwKSArIGluZGV4ICsgMSxcclxuXHJcbiAgICAgICAgICAgICAgdGl0bGU6IHRpdGxlLFxyXG4gICAgICAgICAgICAgIHByaWNlOiBwcmljZXNbaW5kZXhdLFxyXG4gICAgICAgICAgICAgIGFsbGVyZ2llczogYWxsZXJnaWVzLFxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbixcclxuICAgICAgICAgICAgICBleHRyYXM6IGlzZXh0cmFzLFxyXG5cclxuICAgICAgICAgICAgICBjYXRlZ29yeTogY2F0ZWdvcnksXHJcbiAgICAgICAgICAgICAgc2l6ZTogc2l6ZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgIC8vIGlmKHNpemVzLmxlbmd0aCA+IDAgKXtcclxuICAgIC8vIGZvb2QubWFwKGZvPT57XHJcbiAgICAvLyAgIGZvb2RzLnB1c2goZm8pO1xyXG4gICAgLy8gfSk7XHJcbiAgICAvLyB9XHJcbiAgICAvLyBlbHNle1xyXG4gICAgLy8gICBmb29kcy5wdXNoKGZvb2QpO1xyXG4gICAgLy8gfVxyXG5cclxuICAgIGlmIChzaXplcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXBpLnBvc3QoXCIvZm9vZFwiLCBmb29kKTtcclxuICAgICAgY29uc29sZS5sb2coXCJvbmUgcHJvZHVjdCBcIiwgZm9vZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb29kLm1hcCgoZikgPT4gYXBpLnBvc3QoXCIvZm9vZFwiLCBmKSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwicHJvZHVjdHMgXCIsIGZvb2QpO1xyXG4gICAgfVxyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgYXdhaXQgYXBpLmdldChcIi9mb29kXCIpLnRoZW4oKGMpID0+IGNvbnNvbGUubG9nKGMuZGF0YSkpO1xyXG4gICAgfSkoKTtcclxuXHJcbiAgICAvLyBjb25zb2xlLmxvZyhmb29kKTtcclxuICB9XHJcbiAgY29uc3Qgb25DYXRlZ29yeUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRDYXRlZ29yeShlLnZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uUHJpY2VDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIHByaWNlcy5wdXNoKE51bWJlcihlLnRhcmdldC52YWx1ZSkpO1xyXG4gICAgc2V0UHJpY2VzKHByaWNlcyk7XHJcbiAgfTtcclxuICBjb25zdCBvblRpdGxlQ2hhbmdlciA9IChlKSA9PiB7XHJcbiAgICBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25JbWFnZVVybENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBzZXRJbWFnZVVybChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25EZXNjcmlwdGlvbkNoYW5nZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0RGVzY3JpcHRpb24oZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNpemVBZGRlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzID0gc2l6ZXM7XHJcblxyXG4gICAgcy5wdXNoKHtcclxuICAgICAgcHJpY2U6IGN1cnJlbnRQcmljZSxcclxuICAgICAgc2l6ZTogY3VycmVudFNpemUsXHJcbiAgICB9KTtcclxuICAgIGNvbnNvbGUubG9nKFwic2l6ZSBhZGRlZCBcIiwgcyk7XHJcblxyXG4gICAgc2V0U2l6ZXMocyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25BbGxlcmdpZXNDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIGxldCBhcnIgPSBcIlwiO1xyXG4gICAgYXJyID0gYXJyLmNvbmNhdChcIlwiICsgZS50YXJnZXQudmFsdWUpO1xyXG4gICAgYXJyID0gYXJyLnNwbGl0KFwiLFwiLCAxMDAwKTtcclxuICAgIHNldEFsbGVyZ2llcyhhcnIpO1xyXG4gIH07XHJcbiAgY29uc3Qgb25leHRyYXNDaGFuZ2VyID0gKGUpID0+IHtcclxuICAgIC8vIGNvbnNvbGUubG9nKGUudGFyZ2V0LmNoZWNrZWQpO1xyXG5cclxuICAgIHNldElzZXh0cmFzKGUudGFyZ2V0LmNoZWNrZWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhdGVnb3J5T3B0aW9ucyA9IGNhdGVnb3JpZXMubWFwKChjYXQpID0+IHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHZhbHVlOiBjYXQudGl0bGUsXHJcbiAgICAgIGxhYmVsOiBjYXQudGl0bGUsXHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBzaXplc09wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiBcInNtXCIsIGxhYmVsOiBcIlNtYWxsXCIgfSxcclxuICAgIHsgdmFsdWU6IFwibWRcIiwgbGFiZWw6IFwiTWVkaXVtXCIgfSxcclxuICAgIHsgdmFsdWU6IFwibGdcIiwgbGFiZWw6IFwiTGFyZ2VcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJ4bGdcIiwgbGFiZWw6IFwiRXh0cmEgTGFyZ2VcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8U2ltcGxlSGVhZGVyIC8+XHJcblxyXG4gICAgICA8Q29udGFpbmVyIGNsYXNzTmFtZT1cIm10LTdcIiBmbHVpZD5cclxuICAgICAgICA8Um93PlxyXG4gICAgICAgICAgPENvbCBjbGFzc05hbWU9XCJvcmRlci14bC0xXCIgeGw9XCI4XCI+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXNlY29uZGFyeSBzaGFkb3dcIj5cclxuICAgICAgICAgICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXItMFwiPjwvQ2FyZEhlYWRlcj5cclxuICAgICAgICAgICAgICA8Q2FyZEJvZHk+XHJcbiAgICAgICAgICAgICAgICA8Um93IGNsYXNzTmFtZT1cImFsaWduLWl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPVwiOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbSA/IFwiRWRpdCBFeGlzdGluZyBGb29kXCIgOiBcIkFkZCBOZXcgRm9vZFwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgPENvbCBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCIgeHM9XCI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIGV4YWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiL2FkbWluL21hbmFnZUZvb2RzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBTdWJtaXR0ZXIoZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gU3VibWl0dGVyKGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17aXRlbSA/IFwic3VjY2Vzc1wiIDogXCJwcmltYXJ5XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB0MyBwYi0zIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtID8gXCJTYXZlIENoYW5nZXNcIiA6IFwiQWRkXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybT5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwibXQtMiBtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+Q2xpY2sgT24gRXZlcnkgRmllbGQgYXQgbGVhc3QgT25jZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm1iLTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtYWx0ZXJuYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC10aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInBpenphICwgc3BlZ2hhdGkgZXRjLi4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0udGl0bGUgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uVGl0bGVDaGFuZ2VyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LWNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgdGhlIENhdGVnb3J5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0TWVudVNpbmdsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1jYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtjYXRlZ29yeU9wdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLmNhdGVnb3J5IDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlSGFuZGxlcj17b25DYXRlZ29yeUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXYgaWQ9XCJzaXplc0RpdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LXNpemVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkIFNpemUob3B0aW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdE1lbnVNdWx0aXBsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXNpemVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2VIYW5kbGVyPXtvblNpemVzQ2hhbmdlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17c2l6ZXNPcHRpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0zIG10LTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dTaXplRGl2KHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICArIE1hbmFnZSBTaXplXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge3Nob3dTaXplRGl2ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l6ZXNEaXZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LXNpemVTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNpemVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LXNpemVzU2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIzMng0NWNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInNpemVzIGdvdFwiLCBlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50U2l6ZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00IFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtc2l6ZVByaWNlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaWNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1hbHRlcm5hdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1zaXplUHJpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiNC4zM+KCrFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzaXplcyBnb3RcIiwgZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudFByaWNlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyBtdC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93U2l6ZURpdihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZUFkZGVyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBRERcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNCBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+IFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZXMubWFwKHM9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFibGUgY2xhc3NOYW1lPVwidGFibGUgdGFibGUtZGFya1wiPiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCI+QWN0aW9uPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiPlByaWNlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiPkFjdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJsZT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGNsYXNzTmFtZT1cInAtMyBtdC0yXCIgY29sb3I9XCJkYW5nZXJcIj5EZWxldGU8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntzLnByaWNlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPntzLnNpemV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsLWxnLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Um93PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENvbCBtZD1cIjEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtbGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlucHV0LWFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEltYWdlIFVybFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtYWx0ZXJuYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJpbnB1dC1pbWFnZVVybFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInd3dy5leGFtcGxlLmNvbS9pbWFnZS5wbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtpdGVtID8gaXRlbS51cmwgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlLCB2KSA9PiBvbkltYWdlVXJsQ2hhbmdlKGUsIHYpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1wcmljZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtcHJpY2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI0LjU24oKsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17aXRlbSA/IGl0ZW0ucHJpY2UgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlLCB2KSA9PiBvblByaWNlQ2hhbmdlcihlLCB2KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJpbnB1dC1hbGxlcmdpZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFsbGVyZ2llc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNvbnRyb2wtYWx0ZXJuYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiaW5wdXQtYWxsZXJnaWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsZXJnaWVzIGksaSwxLDJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtpdGVtID8gaXRlbS5hbGxlcmdpZXMgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlLCB2KSA9PiBvbkFsbGVyZ2llc0NoYW5nZXIoZSwgdil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGwtbGctNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3c+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q29sIG1kPVwiMTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tY29udHJvbC1sYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5wdXQtYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jb250cm9sLWFsdGVybmF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImlucHV0LWFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e2l0ZW0gPyBpdGVtLmRlc2NyaXB0aW9uIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0YXJlYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzPXs1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRGVzY3JpcHRpb25DaGFuZ2VyKGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbC1sZy00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDb2wgbWQ9XCIxMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUdyb3VwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbmV4dHJhc0NoYW5nZXIoZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+ZXh0cmFzIEluY2x1ZGVkPzwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICAgICAgPC9DYXJkQm9keT5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPC9Sb3c+XHJcbiAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5hZGRGb29kLmxheW91dCA9IEFkbWluO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYWRkRm9vZDtcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==