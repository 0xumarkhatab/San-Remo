module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "./API_WORK/api.js":
/*!*************************!*\
  !*** ./API_WORK/api.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (axios__WEBPACK_IMPORTED_MODULE_0___default.a.create({
  baseURL: "http://192.168.100.156:5050/api/v1"
}));

/***/ }),

/***/ "./API_WORK/fetchAndDispatch.js":
/*!**************************************!*\
  !*** ./API_WORK/fetchAndDispatch.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Categories_CategoriesData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Categories/CategoriesData */ "./components/Categories/CategoriesData.js");
/* harmony import */ var _components_Foods_foodsData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Foods/foodsData */ "./components/Foods/foodsData.js");
/* harmony import */ var _components_Orders_ordersData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Orders/ordersData */ "./components/Orders/ordersData.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./api */ "./API_WORK/api.js");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! socket.io-client */ "socket.io-client");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_6__);








function fetchAndDispatch() {
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["useDispatch"])();

  (async () => {
    const {
      data
    } = await _api__WEBPACK_IMPORTED_MODULE_5__["default"].get("/category");
    dispatch({
      type: "SET_CATEGORIES",
      CATEGORIES: data
    });
  })();

  (async () => {
    const {
      data
    } = await _api__WEBPACK_IMPORTED_MODULE_5__["default"].get("/food");
    console.log(data, "Foods");
    dispatch({
      type: "SET_FOODS",
      FOODS: data
    });
  })(); // (async () => {
  //   const { data } = await api.get("/order");
  //   const socket=io("http://192.168.100.156:5050");
  //   socket.on('order',(order)=>{
  //    console.log("Order received ",order)
  //    });
  //    dispatch({
  //      type: "SET_ORDERS",
  //      ORDERS: data ,
  //    });
  // })();


  return 0;
}

/* harmony default export */ __webpack_exports__["default"] = (fetchAndDispatch);

/***/ }),

/***/ "./Reducers/reducer.js":
/*!*****************************!*\
  !*** ./Reducers/reducer.js ***!
  \*****************************/
/*! exports provided: default, store */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "store", function() { return store; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  FOODS: [],
  CATEGORIES: [],
  ORDERS: [],
  EDIT_PROPS: {},
  DELETE_PROPS: {},
  VIEW_PROPS: null
};

const reducer = (state = initialState, action) => {
  console.log(action);

  switch (action.type) {
    case 'SET_FOODS':
      return _objectSpread(_objectSpread({}, state), {}, {
        FOODS: action.FOODS
      });

    case 'SET_CATEGORIES':
      return _objectSpread(_objectSpread({}, state), {}, {
        CATEGORIES: action.CATEGORIES
      });

    case 'SET_EDIT_PROPS':
      return _objectSpread(_objectSpread({}, state), {}, {
        EDIT_PROPS: action.EDIT_PROPS
      });

    case 'SET_VIEW_PROPS':
      console.log("set");
      return _objectSpread(_objectSpread({}, state), {}, {
        VIEW_PROPS: action.VIEW_PROPS
      });

    case 'SET_DELETE_PROPS':
      return _objectSpread(_objectSpread({}, state), {}, {
        DELETE_PROPS: action.DELETE_PROPS
      });

    case 'SET_ORDERS':
      return _objectSpread(_objectSpread({}, state), {}, {
        ORDERS: action.ORDERS
      });

    default:
      return _objectSpread({}, state);
  }
};

/* harmony default export */ __webpack_exports__["default"] = (reducer);
const store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(reducer);

/***/ }),

/***/ "./assets/plugins/nucleo/css/nucleo.css":
/*!**********************************************!*\
  !*** ./assets/plugins/nucleo/css/nucleo.css ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./assets/scss/nextjs-argon-dashboard.scss":
/*!*************************************************!*\
  !*** ./assets/scss/nextjs-argon-dashboard.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Categories/CategoriesData.js":
/*!*************************************************!*\
  !*** ./components/Categories/CategoriesData.js ***!
  \*************************************************/
/*! exports provided: categories */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categories", function() { return categories; });
const categories = [{
  id: 1,
  title: "American Style Pizza",
  url: "https://www.teahub.io/photos/full/23-232612_large-pizza-wallpaper-src-large-pizza-wallpaper-pizza.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 2,
  title: "Calzone",
  url: "https://thumbs.dreamstime.com/b/italian-food-closed-pizza-calzone-spinach-cheese-wooden-background-copy-space-calzone-spinach-cheese-107729251.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 3,
  title: "Gemusegerichte",
  url: "https://cdn.pixabay.com/photo/2016/02/19/10/00/food-1209007_960_720.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 4,
  title: "Brot  & Brotchen",
  url: "https://st.depositphotos.com/2226532/3034/i/950/depositphotos_30345395-stock-photo-brot-und-brtchen.jpg",
  description: "This item is made in Germany",
  variants: [{
    title: "variant1"
  }, {
    id: 1,
    title: "variant2"
  }],
  size: 'lg'
}];

/***/ }),

/***/ "./components/Foods/foodsData.js":
/*!***************************************!*\
  !*** ./components/Foods/foodsData.js ***!
  \***************************************/
/*! exports provided: foodsArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "foodsArray", function() { return foodsArray; });
const foodsArray = [{
  id: 1,
  title: "Pizza Familia",
  url: "https://media-cdn.tripadvisor.com/media/photo-s/11/49/b4/56/photo0jpg.jpg",
  size: "sm",
  category: "Angebot",
  price: "43",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: [{
    name: "liter Coca Cola",
    quantity: 1
  }, {
    name: "mini Fries",
    quantity: 2
  }]
}, {
  id: 2,
  title: "FlamKuchen",
  url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
  price: "23",
  category: "American Pizza",
  url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}, {
  id: 3,
  title: "Gazzo",
  size: "xlg",
  category: "Pizza",
  url: "https://prod-wolt-venue-images-cdn.wolt.com/5f914334e8bd89fc65eb4647/53630304-17b1-11eb-9229-3e9ff85dedc2_pizza_no_8_2.jpg",
  price: "1441",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}, {
  id: 4,
  title: "Margherita",
  size: "md",
  category: "Pizza",
  price: "65",
  url: "https://i.pinimg.com/originals/7d/4c/ea/7d4cea99d73d2ea82549de0ea4b80198.jpg",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}];

/***/ }),

/***/ "./components/Orders/ordersData.js":
/*!*****************************************!*\
  !*** ./components/Orders/ordersData.js ***!
  \*****************************************/
/*! exports provided: ordersData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ordersData", function() { return ordersData; });
const ordersData = [{
  id: 1,
  time: "12 Nov 2021 3:34Pm",
  paymentMode: "PayPal",
  paymentId: "san-remo-dh2g3h21321f3",
  phone: "+1(7842)-6532",
  name: "Arnold Jems",
  adress: "45 Oregon Street Los Angels",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 2,
    category: "Pizza",
    Extras: [{
      name: "liter Coca Cola",
      quantity: 1
    }, {
      name: "mini Fries",
      quantity: 2
    }]
  }, {
    id: 2,
    title: "FlamKuchen",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
    price: 23,
    quantity: 4,
    category: "American Pizza",
    Extras: []
  }],
  type: "pick-up",
  status: "pending"
}, {
  id: 2,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(342)-34532",
  name: "Jessca",
  adress: "24 T-Block West Cost Asia",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 5,
    category: "American Fa,ilia  Pizza",
    Extras: [{
      name: "liter Coca Cola",
      quantity: 1
    }, {
      name: "mini Fries",
      quantity: 2
    }]
  }],
  type: "pick-up",
  status: "pending"
}, {
  id: 3,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(45432)-34532",
  name: "Alisa",
  adress: "13 Linkin Park Street USA",
  items: [{
    id: 1,
    title: "Camilion Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 53,
    category: "Camilion Pizza",
    Extras: []
  }],
  type: "Cash On Delivery",
  status: "new"
}, {
  id: 4,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(3432)-34532",
  name: "Rochelle",
  adress: "12 DownStreet London",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 10,
    category: "American Pizza"
  }, {
    id: 2,
    title: "Hunre Pizza",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 5,
    category: "American Fa,ilia  Pizza"
  }],
  type: "pick-up",
  status: "completed"
}];

/***/ }),

/***/ "./components/PageChange/PageChange.js":
/*!*********************************************!*\
  !*** ./components/PageChange/PageChange.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PageChange; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "E:\\admin\\components\\PageChange\\PageChange.js";
 // reactstrap components

 // core components

function PageChange(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "page-transition-wrapper-div",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "page-transition-icon-wrapper mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Spinner"], {
          color: "white",
          style: {
            width: "6rem",
            height: "6rem",
            borderWidth: ".3rem"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
        className: "title text-white",
        children: "Loading"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@fortawesome/fontawesome-free/css/all.min.css":
/*!********************************************************************!*\
  !*** ./node_modules/@fortawesome/fontawesome-free/css/all.min.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.AppInitialProps = _utils.AppInitialProps;
exports.NextWebVitalsMetric = _utils.NextWebVitalsMetric;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps({
  Component,
  ctx
}) {
  const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    const {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return /*#__PURE__*/_react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
let warnContainer;
let warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn(`Warning: the \`Container\` in \`_app\` has been deprecated and should be removed. https://nextjs.org/docs/messages/app-container-deprecated`);
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error(`Warning: the 'url' property is deprecated. https://nextjs.org/docs/messages/url-deprecated`);
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  const {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      const pushRoute = as ? href : '';
      const pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      const replaceRoute = as ? href : '';
      const replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyApp; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_PageChange_PageChange_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/PageChange/PageChange.js */ "./components/PageChange/PageChange.js");
/* harmony import */ var _Reducers_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Reducers/reducer */ "./Reducers/reducer.js");
/* harmony import */ var assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! assets/plugins/nucleo/css/nucleo.css */ "./assets/plugins/nucleo/css/nucleo.css");
/* harmony import */ var assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ "./node_modules/@fortawesome/fontawesome-free/css/all.min.css");
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! assets/scss/nextjs-argon-dashboard.scss */ "./assets/scss/nextjs-argon-dashboard.scss");
/* harmony import */ var assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _API_WORK_fetchAndDispatch__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../API_WORK/fetchAndDispatch */ "./API_WORK/fetchAndDispatch.js");


var _jsxFileName = "E:\\admin\\pages\\_app.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeStart", url => {
  console.log(`Loading: ${url}`);
  document.body.classList.add("body-page-transition");
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.render( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_PageChange_PageChange_js__WEBPACK_IMPORTED_MODULE_8__["default"], {
    path: url
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 22,
    columnNumber: 5
  }, undefined), document.getElementById("page-transition"));
});
next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeComplete", () => {
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});
next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeError", () => {
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});
class MyApp extends next_app__WEBPACK_IMPORTED_MODULE_3___default.a {
  componentDidMount() {
    let comment = document.createComment(`

=========================================================
* * NextJS Argon Dashboard v1.1.0 based on Argon Dashboard React v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/nextjs-argon-dashboard
* Copyright 2021 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/nextjs-argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

`);
    document.insertBefore(comment, document.documentElement);
  }

  static async getInitialProps({
    Component,
    router,
    ctx
  }) {
    let pageProps = {};

    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }

    return {
      pageProps
    };
  }

  render() {
    const {
      Component,
      pageProps
    } = this.props;

    const Layout = Component.layout || (({
      children
    }) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: children
    }, void 0, false));

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_4___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
          name: "viewport",
          content: "width=device-width, initial-scale=1, shrink-to-fit=no"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "San Remo Admin Panel"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          src: "https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Layout, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_redux__WEBPACK_IMPORTED_MODULE_6__["Provider"], {
          store: _Reducers_reducer__WEBPACK_IMPORTED_MODULE_9__["store"],
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_API_WORK_fetchAndDispatch__WEBPACK_IMPORTED_MODULE_13__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 11
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 78,
      columnNumber: 7
    }, this);
  }

}

/***/ }),

/***/ 0:
/*!****************************************!*\
  !*** multi private-next-pages/_app.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.js */"./pages/_app.js");


/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("reactstrap");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "socket.io-client":
/*!***********************************!*\
  !*** external "socket.io-client" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("socket.io-client");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovLy8uL0FQSV9XT1JLL2FwaS5qcyIsIndlYnBhY2s6Ly8vLi9BUElfV09SSy9mZXRjaEFuZERpc3BhdGNoLmpzIiwid2VicGFjazovLy8uL1JlZHVjZXJzL3JlZHVjZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9DYXRlZ29yaWVzL0NhdGVnb3JpZXNEYXRhLmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvRm9vZHMvZm9vZHNEYXRhLmpzIiwid2VicGFjazovLy8uL2NvbXBvbmVudHMvT3JkZXJzL29yZGVyc0RhdGEuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9QYWdlQ2hhbmdlL1BhZ2VDaGFuZ2UuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2FwcC5qcyIsIndlYnBhY2s6Ly8vLi4vLi4vcGFnZXMvX2FwcC50c3giLCJ3ZWJwYWNrOi8vLy4vcGFnZXMvX2FwcC5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJheGlvc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvcm91dGVyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1kb21cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1yZWR1eFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0c3RyYXBcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInNvY2tldC5pby1jbGllbnRcIiJdLCJuYW1lcyI6WyJheGlvcyIsImNyZWF0ZSIsImJhc2VVUkwiLCJmZXRjaEFuZERpc3BhdGNoIiwiZGlzcGF0Y2giLCJ1c2VEaXNwYXRjaCIsImRhdGEiLCJhcGkiLCJnZXQiLCJ0eXBlIiwiQ0FURUdPUklFUyIsImNvbnNvbGUiLCJsb2ciLCJGT09EUyIsImluaXRpYWxTdGF0ZSIsIk9SREVSUyIsIkVESVRfUFJPUFMiLCJERUxFVEVfUFJPUFMiLCJWSUVXX1BST1BTIiwicmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwic3RvcmUiLCJjcmVhdGVTdG9yZSIsImNhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwidXJsIiwiZGVzY3JpcHRpb24iLCJ2YXJpYW50cyIsInNpemUiLCJmb29kc0FycmF5IiwiY2F0ZWdvcnkiLCJwcmljZSIsImFsbGVyZ2llcyIsIkV4dHJhcyIsIm5hbWUiLCJxdWFudGl0eSIsIm9yZGVyc0RhdGEiLCJ0aW1lIiwicGF5bWVudE1vZGUiLCJwYXltZW50SWQiLCJwaG9uZSIsImFkcmVzcyIsIml0ZW1zIiwic3RhdHVzIiwiUGFnZUNoYW5nZSIsInByb3BzIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJXaWR0aCIsInBhZ2VQcm9wcyIsIlJlYWN0IiwiQ29tcG9uZW50IiwiY29tcG9uZW50RGlkQ2F0Y2giLCJyZW5kZXIiLCJfX05fU1NHIiwiY3JlYXRlVXJsIiwiQXBwIiwib3JpZ0dldEluaXRpYWxQcm9wcyIsImFwcEdldEluaXRpYWxQcm9wcyIsImdldEluaXRpYWxQcm9wcyIsIndhcm5Db250YWluZXIiLCJ3YXJuVXJsIiwicCIsImJhY2siLCJyb3V0ZXIiLCJwdXNoIiwicHVzaFRvIiwicHVzaFJvdXRlIiwiYXMiLCJwdXNoVXJsIiwicmVwbGFjZSIsInJlcGxhY2VUbyIsInJlcGxhY2VSb3V0ZSIsInJlcGxhY2VVcmwiLCJSb3V0ZXIiLCJldmVudHMiLCJvbiIsImRvY3VtZW50IiwiYm9keSIsImNsYXNzTGlzdCIsImFkZCIsIlJlYWN0RE9NIiwiZ2V0RWxlbWVudEJ5SWQiLCJ1bm1vdW50Q29tcG9uZW50QXROb2RlIiwicmVtb3ZlIiwiTXlBcHAiLCJjb21wb25lbnREaWRNb3VudCIsImNvbW1lbnQiLCJjcmVhdGVDb21tZW50IiwiaW5zZXJ0QmVmb3JlIiwiZG9jdW1lbnRFbGVtZW50IiwiY3R4IiwiTGF5b3V0IiwibGF5b3V0IiwiY2hpbGRyZW4iXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ3hGQSwrRDs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFBO0FBQUE7QUFDZUEsMkdBQUssQ0FBQ0MsTUFBTixDQUFhO0FBQzFCQyxTQUFPLEVBQUU7QUFEaUIsQ0FBYixDQUFmLEU7Ozs7Ozs7Ozs7OztBQ0RBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxTQUFTQyxnQkFBVCxHQUE0QjtBQUMxQixRQUFNQyxRQUFRLEdBQUdDLCtEQUFXLEVBQTVCOztBQUVBLEdBQUMsWUFBWTtBQUNYLFVBQU07QUFBRUM7QUFBRixRQUFXLE1BQU1DLDRDQUFHLENBQUNDLEdBQUosQ0FBUSxXQUFSLENBQXZCO0FBRUFKLFlBQVEsQ0FBQztBQUNQSyxVQUFJLEVBQUUsZ0JBREM7QUFFUEMsZ0JBQVUsRUFBRUo7QUFGTCxLQUFELENBQVI7QUFJRCxHQVBEOztBQVNBLEdBQUMsWUFBWTtBQUNYLFVBQU07QUFBQ0E7QUFBRCxRQUFTLE1BQU1DLDRDQUFHLENBQUNDLEdBQUosQ0FBUSxPQUFSLENBQXJCO0FBQ0FHLFdBQU8sQ0FBQ0MsR0FBUixDQUFZTixJQUFaLEVBQWlCLE9BQWpCO0FBRUFGLFlBQVEsQ0FBQztBQUNQSyxVQUFJLEVBQUUsV0FEQztBQUVQSSxXQUFLLEVBQUVQO0FBRkEsS0FBRCxDQUFSO0FBS0QsR0FURCxJQVowQixDQXlCMUI7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUlBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFHQTs7O0FBS0EsU0FBTyxDQUFQO0FBQ0Q7O0FBRWNILCtFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxREE7QUFFQSxNQUFNVyxZQUFZLEdBQUc7QUFDbkJELE9BQUssRUFBRSxFQURZO0FBRW5CSCxZQUFVLEVBQUMsRUFGUTtBQUduQkssUUFBTSxFQUFDLEVBSFk7QUFJbkJDLFlBQVUsRUFBQyxFQUpRO0FBS25CQyxjQUFZLEVBQUMsRUFMTTtBQU1uQkMsWUFBVSxFQUFDO0FBTlEsQ0FBckI7O0FBYUEsTUFBTUMsT0FBTyxHQUFHLENBQUNDLEtBQUssR0FBR04sWUFBVCxFQUF1Qk8sTUFBdkIsS0FBa0M7QUFDaERWLFNBQU8sQ0FBQ0MsR0FBUixDQUFZUyxNQUFaOztBQUdBLFVBQVFBLE1BQU0sQ0FBQ1osSUFBZjtBQUNFLFNBQUssV0FBTDtBQUNFLDZDQUNLVyxLQURMO0FBRUNQLGFBQUssRUFBQ1EsTUFBTSxDQUFDUjtBQUZkOztBQUlKLFNBQUssZ0JBQUw7QUFDRSw2Q0FDS08sS0FETDtBQUVFVixrQkFBVSxFQUFDVyxNQUFNLENBQUNYO0FBRnBCOztBQUlKLFNBQUssZ0JBQUw7QUFDRSw2Q0FDS1UsS0FETDtBQUVFSixrQkFBVSxFQUFDSyxNQUFNLENBQUNMO0FBRnBCOztBQU1GLFNBQUssZ0JBQUw7QUFDRUwsYUFBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBLDZDQUNLUSxLQURMO0FBRUVGLGtCQUFVLEVBQUNHLE1BQU0sQ0FBQ0g7QUFGcEI7O0FBS0EsU0FBSyxrQkFBTDtBQUNFLDZDQUNLRSxLQURMO0FBRUVILG9CQUFZLEVBQUNJLE1BQU0sQ0FBQ0o7QUFGdEI7O0FBSUYsU0FBSyxZQUFMO0FBQ0UsNkNBQ0tHLEtBREw7QUFFRUwsY0FBTSxFQUFDTSxNQUFNLENBQUNOO0FBRmhCOztBQU1BO0FBQ0UsK0JBQ0tLLEtBREw7QUF0Q0o7QUEwQ0QsQ0E5Q0Q7O0FBZ0RlRCxzRUFBZjtBQUNPLE1BQU1HLEtBQUssR0FBR0MseURBQVcsQ0FBQ0osT0FBRCxDQUF6QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEVQO0FBQUE7QUFBTyxNQUFNSyxVQUFVLEdBQUcsQ0FHeEI7QUFDRUMsSUFBRSxFQUFDLENBREw7QUFFRUMsT0FBSyxFQUFFLHNCQUZUO0FBR0VDLEtBQUcsRUFBRSx1R0FIUDtBQUlFQyxhQUFXLEVBQUMsOEJBSmQ7QUFLRUMsVUFBUSxFQUNSLENBQ0U7QUFDRUosTUFBRSxFQUFDLENBREw7QUFFQUMsU0FBSyxFQUFDO0FBRk4sR0FERixFQUtBO0FBQ0VELE1BQUUsRUFBQyxDQURMO0FBRUVDLFNBQUssRUFBQztBQUZSLEdBTEEsQ0FORjtBQWtCRUksTUFBSSxFQUFDO0FBbEJQLENBSHdCLEVBdUJ4QjtBQUNFTCxJQUFFLEVBQUMsQ0FETDtBQUVFQyxPQUFLLEVBQUUsU0FGVDtBQUdFQyxLQUFHLEVBQUUsb0pBSFA7QUFJRUMsYUFBVyxFQUFDLDhCQUpkO0FBS0VDLFVBQVEsRUFBQyxDQUFDO0FBQ1JKLE1BQUUsRUFBQyxDQURLO0FBRVJDLFNBQUssRUFBQztBQUZFLEdBQUQsRUFJVDtBQUNFRCxNQUFFLEVBQUMsQ0FETDtBQUVFQyxTQUFLLEVBQUM7QUFGUixHQUpTLENBTFg7QUFnQkVJLE1BQUksRUFBQztBQWhCUCxDQXZCd0IsRUF5Q3hCO0FBQ0VMLElBQUUsRUFBQyxDQURMO0FBRUVDLE9BQUssRUFBRSxnQkFGVDtBQUdFQyxLQUFHLEVBQUUseUVBSFA7QUFJRUMsYUFBVyxFQUFDLDhCQUpkO0FBS0VDLFVBQVEsRUFBQyxDQUFDO0FBQ1JKLE1BQUUsRUFBQyxDQURLO0FBRVJDLFNBQUssRUFBQztBQUZFLEdBQUQsRUFJVDtBQUNFRCxNQUFFLEVBQUMsQ0FETDtBQUVFQyxTQUFLLEVBQUM7QUFGUixHQUpTLENBTFg7QUFlQ0ksTUFBSSxFQUFDO0FBZk4sQ0F6Q3dCLEVBMER4QjtBQUNFTCxJQUFFLEVBQUMsQ0FETDtBQUVFQyxPQUFLLEVBQUUsa0JBRlQ7QUFHRUMsS0FBRyxFQUFDLHlHQUhOO0FBSUVDLGFBQVcsRUFBQyw4QkFKZDtBQUtFQyxVQUFRLEVBQUMsQ0FBQztBQUNSSCxTQUFLLEVBQUM7QUFERSxHQUFELEVBR1Q7QUFDRUQsTUFBRSxFQUFDLENBREw7QUFFRUMsU0FBSyxFQUFDO0FBRlIsR0FIUyxDQUxYO0FBZUVJLE1BQUksRUFBQztBQWZQLENBMUR3QixDQUFuQixDOzs7Ozs7Ozs7Ozs7QUNBUDtBQUFBO0FBQU8sTUFBTUMsVUFBVSxHQUFDLENBQ3BCO0FBQ0lOLElBQUUsRUFBQyxDQURQO0FBRUlDLE9BQUssRUFBQyxlQUZWO0FBR0lDLEtBQUcsRUFBQywyRUFIUjtBQUtJRyxNQUFJLEVBQUMsSUFMVDtBQU1JRSxVQUFRLEVBQUMsU0FOYjtBQU9JQyxPQUFLLEVBQUMsSUFQVjtBQVFJTCxhQUFXLEVBQUMscUJBUmhCO0FBU0lNLFdBQVMsRUFBQyxTQVRkO0FBV0lDLFFBQU0sRUFBQyxDQUNmO0FBQ0NDLFFBQUksRUFBQyxpQkFETjtBQUVDQyxZQUFRLEVBQUM7QUFGVixHQURlLEVBS2Y7QUFDQUQsUUFBSSxFQUFDLFlBREw7QUFFQUMsWUFBUSxFQUFDO0FBRlQsR0FMZTtBQVhYLENBRG9CLEVBeUJwQjtBQUNJWixJQUFFLEVBQUMsQ0FEUDtBQUVJQyxPQUFLLEVBQUMsWUFGVjtBQUdJQyxLQUFHLEVBQUMseUdBSFI7QUFJSU0sT0FBSyxFQUFDLElBSlY7QUFNSUQsVUFBUSxFQUFDLGdCQU5iO0FBT0lMLEtBQUcsRUFBQyx5R0FQUjtBQVNJQyxhQUFXLEVBQUMscUJBVGhCO0FBVUlNLFdBQVMsRUFBQyxTQVZkO0FBWUlDLFFBQU0sRUFBQztBQVpYLENBekJvQixFQTBDcEI7QUFDSVYsSUFBRSxFQUFDLENBRFA7QUFFSUMsT0FBSyxFQUFDLE9BRlY7QUFHSUksTUFBSSxFQUFDLEtBSFQ7QUFJSUUsVUFBUSxFQUFDLE9BSmI7QUFLSUwsS0FBRyxFQUFDLDRIQUxSO0FBT0lNLE9BQUssRUFBQyxNQVBWO0FBUUlMLGFBQVcsRUFBQyxxQkFSaEI7QUFTSU0sV0FBUyxFQUFDLFNBVGQ7QUFXSUMsUUFBTSxFQUFDO0FBWFgsQ0ExQ29CLEVBeURwQjtBQUNJVixJQUFFLEVBQUMsQ0FEUDtBQUVJQyxPQUFLLEVBQUMsWUFGVjtBQUlJSSxNQUFJLEVBQUMsSUFKVDtBQUtJRSxVQUFRLEVBQUMsT0FMYjtBQU1JQyxPQUFLLEVBQUMsSUFOVjtBQU9JTixLQUFHLEVBQUMsOEVBUFI7QUFTSUMsYUFBVyxFQUFDLHFCQVRoQjtBQVVJTSxXQUFTLEVBQUMsU0FWZDtBQVlJQyxRQUFNLEVBQUM7QUFaWCxDQXpEb0IsQ0FBakIsQzs7Ozs7Ozs7Ozs7O0FDQVA7QUFBQTtBQUFPLE1BQU1HLFVBQVUsR0FBRyxDQUd4QjtBQUNFYixJQUFFLEVBQUUsQ0FETjtBQUVFYyxNQUFJLEVBQUUsb0JBRlI7QUFHRUMsYUFBVyxFQUFFLFFBSGY7QUFJRUMsV0FBUyxFQUFFLHdCQUpiO0FBS0VDLE9BQUssRUFBRSxlQUxUO0FBTUVOLE1BQUksRUFBRSxhQU5SO0FBT0VPLFFBQU0sRUFBRSw2QkFQVjtBQVNFQyxPQUFLLEVBQUUsQ0FDTDtBQUNFbkIsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGVBRlQ7QUFHRUMsT0FBRyxFQUFFLGtGQUhQO0FBSUVNLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRSxPQU5aO0FBUUVHLFVBQU0sRUFBRSxDQUNOO0FBQ0VDLFVBQUksRUFBRSxpQkFEUjtBQUVFQyxjQUFRLEVBQUU7QUFGWixLQURNLEVBS047QUFDRUQsVUFBSSxFQUFFLFlBRFI7QUFFRUMsY0FBUSxFQUFFO0FBRlosS0FMTTtBQVJWLEdBREssRUFxQkw7QUFDRVosTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLFlBRlQ7QUFHRUMsT0FBRyxFQUFFLHlHQUhQO0FBSUVNLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRSxnQkFOWjtBQU9FRyxVQUFNLEVBQUU7QUFQVixHQXJCSyxDQVRUO0FBd0NFMUIsTUFBSSxFQUFFLFNBeENSO0FBeUNFb0MsUUFBTSxFQUFFO0FBekNWLENBSHdCLEVBOEN4QjtBQUNFcEIsSUFBRSxFQUFFLENBRE47QUFFRWMsTUFBSSxFQUFFLG9CQUZSO0FBR0VDLGFBQVcsRUFBRSxRQUhmO0FBSUVDLFdBQVMsRUFBRSx5QkFKYjtBQUtFQyxPQUFLLEVBQUUsZUFMVDtBQU1FTixNQUFJLEVBQUUsUUFOUjtBQU9FTyxRQUFNLEVBQUUsMkJBUFY7QUFTRUMsT0FBSyxFQUFFLENBQ0w7QUFDRW5CLE1BQUUsRUFBRSxDQUROO0FBRUVDLFNBQUssRUFBRSxlQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFTSxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsQ0FMWjtBQU1FTCxZQUFRLEVBQUUseUJBTlo7QUFPRUcsVUFBTSxFQUFFLENBQ047QUFDRUMsVUFBSSxFQUFFLGlCQURSO0FBRUVDLGNBQVEsRUFBRTtBQUZaLEtBRE0sRUFLTjtBQUNFRCxVQUFJLEVBQUUsWUFEUjtBQUVFQyxjQUFRLEVBQUU7QUFGWixLQUxNO0FBUFYsR0FESyxDQVRUO0FBNkJFNUIsTUFBSSxFQUFFLFNBN0JSO0FBOEJFb0MsUUFBTSxFQUFFO0FBOUJWLENBOUN3QixFQThFeEI7QUFDRXBCLElBQUUsRUFBRSxDQUROO0FBRUVjLE1BQUksRUFBRSxvQkFGUjtBQUdFQyxhQUFXLEVBQUUsUUFIZjtBQUlFQyxXQUFTLEVBQUUseUJBSmI7QUFLRUMsT0FBSyxFQUFFLGlCQUxUO0FBTUVOLE1BQUksRUFBRSxPQU5SO0FBT0VPLFFBQU0sRUFBRSwyQkFQVjtBQVNFQyxPQUFLLEVBQUUsQ0FDTDtBQUNFbkIsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGtCQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFTSxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsRUFMWjtBQU1FTCxZQUFRLEVBQUUsZ0JBTlo7QUFPRUcsVUFBTSxFQUFFO0FBUFYsR0FESyxDQVRUO0FBb0JFMUIsTUFBSSxFQUFFLGtCQXBCUjtBQXFCRW9DLFFBQU0sRUFBRTtBQXJCVixDQTlFd0IsRUFxR3hCO0FBQ0VwQixJQUFFLEVBQUUsQ0FETjtBQUVFYyxNQUFJLEVBQUUsb0JBRlI7QUFHRUMsYUFBVyxFQUFFLFFBSGY7QUFJRUMsV0FBUyxFQUFFLHlCQUpiO0FBS0VDLE9BQUssRUFBRSxnQkFMVDtBQU1FTixNQUFJLEVBQUUsVUFOUjtBQU9FTyxRQUFNLEVBQUUsc0JBUFY7QUFTRUMsT0FBSyxFQUFFLENBQ0w7QUFDRW5CLE1BQUUsRUFBRSxDQUROO0FBRUVDLFNBQUssRUFBRSxlQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFTSxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsRUFMWjtBQU1FTCxZQUFRLEVBQUU7QUFOWixHQURLLEVBVUw7QUFDRVAsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGFBRlQ7QUFHRUMsT0FBRyxFQUFFLGtGQUhQO0FBSUVNLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRTtBQU5aLEdBVkssQ0FUVDtBQTZCRXZCLE1BQUksRUFBRSxTQTdCUjtBQThCRW9DLFFBQU0sRUFBRTtBQTlCVixDQXJHd0IsQ0FBbkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQ0VQOztDQUdBOztBQUVlLFNBQVNDLFVBQVQsQ0FBb0JDLEtBQXBCLEVBQTJCO0FBQ3hDLHNCQUNFO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsNkJBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsbUNBQWY7QUFBQSwrQkFDRSxxRUFBQyxrREFBRDtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUsZUFBSyxFQUFFO0FBQUVDLGlCQUFLLEVBQUUsTUFBVDtBQUFpQkMsa0JBQU0sRUFBRSxNQUF6QjtBQUFpQ0MsdUJBQVcsRUFBRTtBQUE5QztBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFPRTtBQUFJLGlCQUFTLEVBQUMsa0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFlRCxDOzs7Ozs7Ozs7OztBQ3ZCRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHdDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkEsaUJBQWlCLG1CQUFPLENBQUMsaUVBQW1COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTVDOztBQUNBOzs7O0FBa0JBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGtDQUFrQztBQUFBO0FBQWxDO0FBQWtDLENBQWxDLEVBR3lDO0FBQ3ZDLFFBQU1DLFNBQVMsR0FBRyxNQUFNLDJDQUF4QixHQUF3QixDQUF4QjtBQUNBLFNBQU87QUFBUDtBQUFPLEdBQVA7QUFHYTs7QUFBQSxrQkFBMkNDLGVBQU1DLFNBQWpELENBR2I7QUFJQTtBQUNBO0FBQ0E7QUFDQUMsbUJBQWlCLG9CQUE0QztBQUMzRDtBQUdGQzs7QUFBQUEsUUFBTSxHQUFHO0FBQ1AsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUFxRCxLQUEzRDtBQUdBLHdCQUNFLHFFQUdJO0FBQ0E7QUFDSSxNQUFFQyxPQUFPLElBQVQsV0FBd0I7QUFBRTdCLFNBQUcsRUFBRThCLFNBQVMsQ0FBeEMsTUFBd0M7QUFBaEIsS0FBeEIsR0FOVixFQUNFLEVBREY7QUFmRjs7QUFBQTs7O0FBSG1CQyxHLENBSVpDLG1CQUpZRCxHQUlVRSxrQkFKVkY7QUFBQUEsRyxDQUtaRyxlQUxZSCxHQUtNRSxrQkFMTkY7QUErQnJCO0FBQ0E7O0FBRUEsVUFBMkM7QUFDekNJLGVBQWEsR0FBRyxxQkFBUyxNQUFNO0FBQzdCbkQsV0FBTyxDQUFQQTtBQURGbUQsR0FBZ0IsQ0FBaEJBO0FBTUFDLFNBQU8sR0FBRyxxQkFBUyxNQUFNO0FBQ3ZCcEQsV0FBTyxDQUFQQTtBQURGb0QsR0FBVSxDQUFWQTtBQU9GLEMsQ0FBQTs7O0FBQ08sc0JBQTJCO0FBQ2hDLFlBQTJDRCxhQUFhO0FBQ3hELFNBQU9FLENBQUMsQ0FBUjtBQUdLOztBQUFBLDJCQUFtQztBQUN4QztBQUNBLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFOO0FBQ0EsU0FBTztBQUNMLGdCQUFZO0FBQ1YsZ0JBQTJDRCxPQUFPO0FBQ2xEO0FBSEc7O0FBS0wsbUJBQWU7QUFDYixnQkFBMkNBLE9BQU87QUFDbEQ7QUFQRzs7QUFTTCxpQkFBYTtBQUNYLGdCQUEyQ0EsT0FBTztBQUNsRDtBQVhHOztBQWFMRSxRQUFJLEVBQUUsTUFBTTtBQUNWLGdCQUEyQ0YsT0FBTztBQUNsREcsWUFBTSxDQUFOQTtBQWZHO0FBaUJMQyxRQUFJLEVBQUUsYUFBOEI7QUFDbEMsZ0JBQTJDSixPQUFPO0FBQ2xELGFBQU9HLE1BQU0sQ0FBTkEsVUFBUCxFQUFPQSxDQUFQO0FBbkJHO0FBcUJMRSxVQUFNLEVBQUUsY0FBK0I7QUFDckMsZ0JBQTJDTCxPQUFPO0FBQ2xELFlBQU1NLFNBQVMsR0FBR0MsRUFBRSxVQUFwQjtBQUNBLFlBQU1DLE9BQU8sR0FBR0QsRUFBRSxJQUFsQjtBQUVBLGFBQU9KLE1BQU0sQ0FBTkEsZ0JBQVAsT0FBT0EsQ0FBUDtBQTFCRztBQTRCTE0sV0FBTyxFQUFFLGFBQThCO0FBQ3JDLGdCQUEyQ1QsT0FBTztBQUNsRCxhQUFPRyxNQUFNLENBQU5BLGFBQVAsRUFBT0EsQ0FBUDtBQTlCRztBQWdDTE8sYUFBUyxFQUFFLGNBQStCO0FBQ3hDLGdCQUEyQ1YsT0FBTztBQUNsRCxZQUFNVyxZQUFZLEdBQUdKLEVBQUUsVUFBdkI7QUFDQSxZQUFNSyxVQUFVLEdBQUdMLEVBQUUsSUFBckI7QUFFQSxhQUFPSixNQUFNLENBQU5BLHNCQUFQLFVBQU9BLENBQVA7QUFyQ0o7QUFBTyxHQUFQO0FBd0NELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBVSxrREFBTSxDQUFDQyxNQUFQLENBQWNDLEVBQWQsQ0FBaUIsa0JBQWpCLEVBQXNDbkQsR0FBRCxJQUFTO0FBQzVDaEIsU0FBTyxDQUFDQyxHQUFSLENBQWEsWUFBV2UsR0FBSSxFQUE1QjtBQUNBb0QsVUFBUSxDQUFDQyxJQUFULENBQWNDLFNBQWQsQ0FBd0JDLEdBQXhCLENBQTRCLHNCQUE1QjtBQUNBQyxrREFBUSxDQUFDNUIsTUFBVCxlQUNFLHFFQUFDLDJFQUFEO0FBQVksUUFBSSxFQUFFNUI7QUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLEVBRUVvRCxRQUFRLENBQUNLLGNBQVQsQ0FBd0IsaUJBQXhCLENBRkY7QUFJRCxDQVBEO0FBUUFSLGtEQUFNLENBQUNDLE1BQVAsQ0FBY0MsRUFBZCxDQUFpQixxQkFBakIsRUFBd0MsTUFBTTtBQUM1Q0ssa0RBQVEsQ0FBQ0Usc0JBQVQsQ0FBZ0NOLFFBQVEsQ0FBQ0ssY0FBVCxDQUF3QixpQkFBeEIsQ0FBaEM7QUFDQUwsVUFBUSxDQUFDQyxJQUFULENBQWNDLFNBQWQsQ0FBd0JLLE1BQXhCLENBQStCLHNCQUEvQjtBQUNELENBSEQ7QUFJQVYsa0RBQU0sQ0FBQ0MsTUFBUCxDQUFjQyxFQUFkLENBQWlCLGtCQUFqQixFQUFxQyxNQUFNO0FBQ3pDSyxrREFBUSxDQUFDRSxzQkFBVCxDQUFnQ04sUUFBUSxDQUFDSyxjQUFULENBQXdCLGlCQUF4QixDQUFoQztBQUNBTCxVQUFRLENBQUNDLElBQVQsQ0FBY0MsU0FBZCxDQUF3QkssTUFBeEIsQ0FBK0Isc0JBQS9CO0FBQ0QsQ0FIRDtBQUtlLE1BQU1DLEtBQU4sU0FBb0I3QiwrQ0FBcEIsQ0FBd0I7QUFFckM4QixtQkFBaUIsR0FBRztBQUVsQixRQUFJQyxPQUFPLEdBQUdWLFFBQVEsQ0FBQ1csYUFBVCxDQUF3QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQWhCa0IsQ0FBZDtBQWlCQVgsWUFBUSxDQUFDWSxZQUFULENBQXNCRixPQUF0QixFQUErQlYsUUFBUSxDQUFDYSxlQUF4QztBQUNEOztBQUNELGVBQWEvQixlQUFiLENBQTZCO0FBQUVSLGFBQUY7QUFBYWEsVUFBYjtBQUFxQjJCO0FBQXJCLEdBQTdCLEVBQXlEO0FBQ3ZELFFBQUkxQyxTQUFTLEdBQUcsRUFBaEI7O0FBRUEsUUFBSUUsU0FBUyxDQUFDUSxlQUFkLEVBQStCO0FBQzdCVixlQUFTLEdBQUcsTUFBTUUsU0FBUyxDQUFDUSxlQUFWLENBQTBCZ0MsR0FBMUIsQ0FBbEI7QUFDRDs7QUFFRCxXQUFPO0FBQUUxQztBQUFGLEtBQVA7QUFDRDs7QUFJREksUUFBTSxHQUFHO0FBR1AsVUFBTTtBQUFFRixlQUFGO0FBQWFGO0FBQWIsUUFBMkIsS0FBS0osS0FBdEM7O0FBRUEsVUFBTStDLE1BQU0sR0FBR3pDLFNBQVMsQ0FBQzBDLE1BQVYsS0FBcUIsQ0FBQztBQUFFQztBQUFGLEtBQUQsa0JBQWtCO0FBQUEsZ0JBQUdBO0FBQUgscUJBQXZDLENBQWY7O0FBRUEsd0JBQ0UscUVBQUMsNENBQUQsQ0FBTyxRQUFQO0FBQUEsOEJBQ0UscUVBQUMsZ0RBQUQ7QUFBQSxnQ0FDRTtBQUNFLGNBQUksRUFBQyxVQURQO0FBRUUsaUJBQU8sRUFBQztBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFLRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFMRixlQU1FO0FBQVEsYUFBRyxFQUFDO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQVNFLHFFQUFDLE1BQUQ7QUFBQSwrQkFDRSxxRUFBQyxvREFBRDtBQUFVLGVBQUssRUFBRTFFLHVEQUFqQjtBQUFBLGtDQUNBLHFFQUFDLG1FQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREEsZUFFQSxxRUFBQyxTQUFELG9CQUFlNkIsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERjtBQW9CRDs7QUE5RG9DLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEN2QyxrQzs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7QUNBQSx3Qzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSxzQzs7Ozs7Ozs7Ozs7QUNBQSx3Qzs7Ozs7Ozs7Ozs7QUNBQSxrRDs7Ozs7Ozs7Ozs7QUNBQSx1Qzs7Ozs7Ozs7Ozs7QUNBQSxrQzs7Ozs7Ozs7Ozs7QUNBQSw2QyIsImZpbGUiOiJwYWdlcy9fYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDApO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiKTsiLCJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmV4cG9ydCBkZWZhdWx0IGF4aW9zLmNyZWF0ZSh7XHJcbiAgYmFzZVVSTDogXCJodHRwOi8vMTkyLjE2OC4xMDAuMTU2OjUwNTAvYXBpL3YxXCIsXHJcbn0pO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVNlbGVjdG9yLCB1c2VEaXNwYXRjaCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiO1xyXG5pbXBvcnQgeyBjYXRlZ29yaWVzIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQ2F0ZWdvcmllcy9DYXRlZ29yaWVzRGF0YVwiO1xyXG5pbXBvcnQgeyBmb29kc0FycmF5IH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRm9vZHMvZm9vZHNEYXRhXCI7XHJcbmltcG9ydCB7IG9yZGVyc0RhdGEgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9PcmRlcnMvb3JkZXJzRGF0YVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuL2FwaVwiO1xyXG5pbXBvcnQgeyBpbyB9IGZyb20gXCJzb2NrZXQuaW8tY2xpZW50XCI7XHJcblxyXG5mdW5jdGlvbiBmZXRjaEFuZERpc3BhdGNoKCkge1xyXG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcclxuXHJcbiAgKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcIi9jYXRlZ29yeVwiKTtcclxuXHJcbiAgICBkaXNwYXRjaCh7XHJcbiAgICAgIHR5cGU6IFwiU0VUX0NBVEVHT1JJRVNcIixcclxuICAgICAgQ0FURUdPUklFUzogZGF0YSxcclxuICAgIH0pO1xyXG4gIH0pKCk7XHJcblxyXG4gIChhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCB7ZGF0YX0gPSBhd2FpdCBhcGkuZ2V0KFwiL2Zvb2RcIik7XHJcbiAgICBjb25zb2xlLmxvZyhkYXRhLFwiRm9vZHNcIik7XHJcblxyXG4gICAgZGlzcGF0Y2goe1xyXG4gICAgICB0eXBlOiBcIlNFVF9GT09EU1wiLFxyXG4gICAgICBGT09EUzogZGF0YSxcclxuICAgIH0pO1xyXG4gICAgXHJcbiAgfSkoKTtcclxuXHJcbiBcclxuXHJcbiAgLy8gKGFzeW5jICgpID0+IHtcclxuICAvLyAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcIi9vcmRlclwiKTtcclxuICAvLyAgIGNvbnN0IHNvY2tldD1pbyhcImh0dHA6Ly8xOTIuMTY4LjEwMC4xNTY6NTA1MFwiKTtcclxuIFxyXG4gIC8vICAgc29ja2V0Lm9uKCdvcmRlcicsKG9yZGVyKT0+e1xyXG4gIC8vICAgIGNvbnNvbGUubG9nKFwiT3JkZXIgcmVjZWl2ZWQgXCIsb3JkZXIpXHJcbiAgICAgXHJcbiAgICAgIFxyXG4gICAgICBcclxuICAvLyAgICB9KTtcclxuICAgXHJcbiAgLy8gICAgZGlzcGF0Y2goe1xyXG4gIC8vICAgICAgdHlwZTogXCJTRVRfT1JERVJTXCIsXHJcbiAgLy8gICAgICBPUkRFUlM6IGRhdGEgLFxyXG4gIC8vICAgIH0pO1xyXG4gICAgICAgICBcclxuICAgIFxyXG4gIC8vIH0pKCk7XHJcblxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIHJldHVybiAwO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmZXRjaEFuZERpc3BhdGNoO1xyXG4iLCJpbXBvcnQgeyBjcmVhdGVTdG9yZSB9IGZyb20gXCJyZWR1eFwiO1xyXG5cclxuY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gIEZPT0RTOiBbXSxcclxuICBDQVRFR09SSUVTOltdLFxyXG4gIE9SREVSUzpbXSxcclxuICBFRElUX1BST1BTOnt9LFxyXG4gIERFTEVURV9QUk9QUzp7fSxcclxuICBWSUVXX1BST1BTOm51bGwsXHJcblxyXG5cclxuXHJcblxyXG59O1xyXG5cclxuY29uc3QgcmVkdWNlciA9IChzdGF0ZSA9IGluaXRpYWxTdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgY29uc29sZS5sb2coYWN0aW9uKTtcclxuXHJcblxyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgJ1NFVF9GT09EUyc6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICBGT09EUzphY3Rpb24uRk9PRFMgLFxyXG4gIH1cclxuICBjYXNlICdTRVRfQ0FURUdPUklFUyc6XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi5zdGF0ZSxcclxuICAgICAgQ0FURUdPUklFUzphY3Rpb24uQ0FURUdPUklFUyAsXHJcbn1cclxuY2FzZSAnU0VUX0VESVRfUFJPUFMnOlxyXG4gIHJldHVybiB7XHJcbiAgICAuLi5zdGF0ZSxcclxuICAgIEVESVRfUFJPUFM6YWN0aW9uLkVESVRfUFJPUFMsXHJcbiAgfVxyXG5cclxuXHJcbmNhc2UgJ1NFVF9WSUVXX1BST1BTJzpcclxuICBjb25zb2xlLmxvZyhcInNldFwiKTtcclxuICByZXR1cm4ge1xyXG4gICAgLi4uc3RhdGUsXHJcbiAgICBWSUVXX1BST1BTOmFjdGlvbi5WSUVXX1BST1BTLFxyXG4gIH1cclxuXHJcbiAgY2FzZSAnU0VUX0RFTEVURV9QUk9QUyc6XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi5zdGF0ZSxcclxuICAgICAgREVMRVRFX1BST1BTOmFjdGlvbi5ERUxFVEVfUFJPUFMsXHJcbiAgICB9XHJcbiAgY2FzZSAnU0VUX09SREVSUyc6XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAuLi5zdGF0ZSxcclxuICAgICAgT1JERVJTOmFjdGlvbi5PUkRFUlMsXHJcbiAgICB9XHJcbiAgXHJcbiAgICAgIFxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgfTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCByZWR1Y2VyO1xyXG5leHBvcnQgY29uc3Qgc3RvcmUgPSBjcmVhdGVTdG9yZShyZWR1Y2VyKTtcclxuIiwiZXhwb3J0IGNvbnN0IGNhdGVnb3JpZXMgPSBbXHJcbiBcclxuXHJcbiAge1xyXG4gICAgaWQ6MSxcclxuICAgIHRpdGxlOiBcIkFtZXJpY2FuIFN0eWxlIFBpenphXCIsXHJcbiAgICB1cmw6IFwiaHR0cHM6Ly93d3cudGVhaHViLmlvL3Bob3Rvcy9mdWxsLzIzLTIzMjYxMl9sYXJnZS1waXp6YS13YWxscGFwZXItc3JjLWxhcmdlLXBpenphLXdhbGxwYXBlci1waXp6YS5qcGdcIixcclxuICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBpdGVtIGlzIG1hZGUgaW4gR2VybWFueVwiLFxyXG4gICAgdmFyaWFudHM6XHJcbiAgICBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDoxLFxyXG4gICAgICB0aXRsZTpcInZhcmlhbnQxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDoyLFxyXG4gICAgICB0aXRsZTpcInZhcmlhbnQyXCIsXHJcbiAgICB9LFxyXG5cclxuICBdLFxyXG4gIFxyXG4gICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDoyLFxyXG4gICAgdGl0bGU6IFwiQ2Fsem9uZVwiLFxyXG4gICAgdXJsOiBcImh0dHBzOi8vdGh1bWJzLmRyZWFtc3RpbWUuY29tL2IvaXRhbGlhbi1mb29kLWNsb3NlZC1waXp6YS1jYWx6b25lLXNwaW5hY2gtY2hlZXNlLXdvb2Rlbi1iYWNrZ3JvdW5kLWNvcHktc3BhY2UtY2Fsem9uZS1zcGluYWNoLWNoZWVzZS0xMDc3MjkyNTEuanBnXCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcIlRoaXMgaXRlbSBpcyBtYWRlIGluIEdlcm1hbnlcIixcclxuICAgIHZhcmlhbnRzOlt7XHJcbiAgICAgIGlkOjEsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDFcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOjIsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDJcIixcclxuICAgIH0sXHJcblxyXG4gIF0sXHJcbiAgXHJcbiAgICBzaXplOidsZydcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOjMsXHJcbiAgICB0aXRsZTogXCJHZW11c2VnZXJpY2h0ZVwiLFxyXG4gICAgdXJsOiBcImh0dHBzOi8vY2RuLnBpeGFiYXkuY29tL3Bob3RvLzIwMTYvMDIvMTkvMTAvMDAvZm9vZC0xMjA5MDA3Xzk2MF83MjAuanBnXCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcIlRoaXMgaXRlbSBpcyBtYWRlIGluIEdlcm1hbnlcIixcclxuICAgIHZhcmlhbnRzOlt7XHJcbiAgICAgIGlkOjEsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDFcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOjIsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDJcIixcclxuICAgIH0sXHJcblxyXG4gIF0sXHJcbiAgIHNpemU6J2xnJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6NCxcclxuICAgIHRpdGxlOiBcIkJyb3QgICYgQnJvdGNoZW5cIixcclxuICAgIHVybDpcImh0dHBzOi8vc3QuZGVwb3NpdHBob3Rvcy5jb20vMjIyNjUzMi8zMDM0L2kvOTUwL2RlcG9zaXRwaG90b3NfMzAzNDUzOTUtc3RvY2stcGhvdG8tYnJvdC11bmQtYnJ0Y2hlbi5qcGdcIixcclxuICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBpdGVtIGlzIG1hZGUgaW4gR2VybWFueVwiLFxyXG4gICAgdmFyaWFudHM6W3tcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6MSxcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MlwiLFxyXG4gICAgfSxcclxuXHJcbiAgXSxcclxuICBcclxuICAgIHNpemU6J2xnJ1xyXG4gIH0sXHJcbiAgXHJcblxyXG5dO1xyXG4iLCJleHBvcnQgY29uc3QgZm9vZHNBcnJheT1bXHJcbiAgICB7XHJcbiAgICAgICAgaWQ6MSxcclxuICAgICAgICB0aXRsZTpcIlBpenphIEZhbWlsaWFcIixcclxuICAgICAgICB1cmw6XCJodHRwczovL21lZGlhLWNkbi50cmlwYWR2aXNvci5jb20vbWVkaWEvcGhvdG8tcy8xMS80OS9iNC81Ni9waG90bzBqcGcuanBnXCIsXHJcblxyXG4gICAgICAgIHNpemU6XCJzbVwiLFxyXG4gICAgICAgIGNhdGVnb3J5OlwiQW5nZWJvdFwiLFxyXG4gICAgICAgIHByaWNlOlwiNDNcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjpcIlRoaXMgRm9vZCBJcyBHZXJtYW5cIixcclxuICAgICAgICBhbGxlcmdpZXM6XCJhLGUscix0XCIsXHJcblxyXG4gICAgICAgIEV4dHJhczpbXHJcbntcclxuIG5hbWU6XCJsaXRlciBDb2NhIENvbGFcIixcclxuIHF1YW50aXR5OjFcclxufSxcclxue1xyXG5uYW1lOlwibWluaSBGcmllc1wiLFxyXG5xdWFudGl0eToyLFxyXG59LFxyXG5cclxuXSxcclxuXHJcbn0sXHJcbiAgICB7XHJcbiAgICAgICAgaWQ6MixcclxuICAgICAgICB0aXRsZTpcIkZsYW1LdWNoZW5cIixcclxuICAgICAgICB1cmw6XCJodHRwczovL3VwbG9hZC53aWtpbWVkaWEub3JnL3dpa2lwZWRpYS9jb21tb25zL3RodW1iL2QvZGYvRmxhbWV1a2V1c2NoZV8yLmpwZy8zNzVweC1GbGFtZXVrZXVzY2hlXzIuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6XCIyM1wiLFxyXG4gICAgICBcclxuICAgICAgICBjYXRlZ29yeTpcIkFtZXJpY2FuIFBpenphXCIsXHJcbiAgICAgICAgdXJsOlwiaHR0cHM6Ly91cGxvYWQud2lraW1lZGlhLm9yZy93aWtpcGVkaWEvY29tbW9ucy90aHVtYi9kL2RmL0ZsYW1ldWtldXNjaGVfMi5qcGcvMzc1cHgtRmxhbWV1a2V1c2NoZV8yLmpwZ1wiLFxyXG5cclxuICAgICAgICBkZXNjcmlwdGlvbjpcIlRoaXMgRm9vZCBJcyBHZXJtYW5cIixcclxuICAgICAgICBhbGxlcmdpZXM6XCJhLGUscix0XCIsXHJcbiAgICAgICAgXHJcbiAgICAgICAgRXh0cmFzOltdLFxyXG5cclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHtcclxuICAgICAgICBpZDozLFxyXG4gICAgICAgIHRpdGxlOlwiR2F6em9cIixcclxuICAgICAgICBzaXplOlwieGxnXCIsXHJcbiAgICAgICAgY2F0ZWdvcnk6XCJQaXp6YVwiLFxyXG4gICAgICAgIHVybDpcImh0dHBzOi8vcHJvZC13b2x0LXZlbnVlLWltYWdlcy1jZG4ud29sdC5jb20vNWY5MTQzMzRlOGJkODlmYzY1ZWI0NjQ3LzUzNjMwMzA0LTE3YjEtMTFlYi05MjI5LTNlOWZmODVkZWRjMl9waXp6YV9ub184XzIuanBnXCIsXHJcblxyXG4gICAgICAgIHByaWNlOlwiMTQ0MVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBGb29kIElzIEdlcm1hblwiLFxyXG4gICAgICAgIGFsbGVyZ2llczpcImEsZSxyLHRcIixcclxuICAgICAgICBcclxuICAgICAgICBFeHRyYXM6W10sXHJcblxyXG5cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgICAgaWQ6NCxcclxuICAgICAgICB0aXRsZTpcIk1hcmdoZXJpdGFcIixcclxuICAgICAgICBcclxuICAgICAgICBzaXplOlwibWRcIixcclxuICAgICAgICBjYXRlZ29yeTpcIlBpenphXCIsXHJcbiAgICAgICAgcHJpY2U6XCI2NVwiLFxyXG4gICAgICAgIHVybDpcImh0dHBzOi8vaS5waW5pbWcuY29tL29yaWdpbmFscy83ZC80Yy9lYS83ZDRjZWE5OWQ3M2QyZWE4MjU0OWRlMGVhNGI4MDE5OC5qcGdcIixcclxuXHJcbiAgICAgICAgZGVzY3JpcHRpb246XCJUaGlzIEZvb2QgSXMgR2VybWFuXCIsXHJcbiAgICAgICAgYWxsZXJnaWVzOlwiYSxlLHIsdFwiLFxyXG4gICAgICAgIFxyXG4gICAgICAgIEV4dHJhczpbXSxcclxuXHJcblxyXG4gICAgfSxcclxuICAgIFxyXG5dXHJcblxyXG5cclxuIiwiZXhwb3J0IGNvbnN0IG9yZGVyc0RhdGEgPSBbXHJcbiAgXHJcbiAgXHJcbiAge1xyXG4gICAgaWQ6IDEsXHJcbiAgICB0aW1lOiBcIjEyIE5vdiAyMDIxIDM6MzRQbVwiLFxyXG4gICAgcGF5bWVudE1vZGU6IFwiUGF5UGFsXCIsXHJcbiAgICBwYXltZW50SWQ6IFwic2FuLXJlbW8tZGgyZzNoMjEzMjFmM1wiLFxyXG4gICAgcGhvbmU6IFwiKzEoNzg0MiktNjUzMlwiLFxyXG4gICAgbmFtZTogXCJBcm5vbGQgSmVtc1wiLFxyXG4gICAgYWRyZXNzOiBcIjQ1IE9yZWdvbiBTdHJlZXQgTG9zIEFuZ2Vsc1wiLFxyXG5cclxuICAgIGl0ZW1zOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICB0aXRsZTogXCJQaXp6YSBGYW1pbGlhXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vaW1ncy5taTkuY29tL3VwbG9hZHMvb3RoZXIvNDYxMy9waXp6YS1mcmVlLXdhbGxwYXBlcl8xOTIweDEyMDBfODIxNTcuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6IDQ1LFxyXG4gICAgICAgIHF1YW50aXR5OiAyLFxyXG4gICAgICAgIGNhdGVnb3J5OiBcIlBpenphXCIsXHJcblxyXG4gICAgICAgIEV4dHJhczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOiBcImxpdGVyIENvY2EgQ29sYVwiLFxyXG4gICAgICAgICAgICBxdWFudGl0eTogMSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6IFwibWluaSBGcmllc1wiLFxyXG4gICAgICAgICAgICBxdWFudGl0eTogMixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogMixcclxuICAgICAgICB0aXRsZTogXCJGbGFtS3VjaGVuXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vdXBsb2FkLndpa2ltZWRpYS5vcmcvd2lraXBlZGlhL2NvbW1vbnMvdGh1bWIvZC9kZi9GbGFtZXVrZXVzY2hlXzIuanBnLzM3NXB4LUZsYW1ldWtldXNjaGVfMi5qcGdcIixcclxuICAgICAgICBwcmljZTogMjMsXHJcbiAgICAgICAgcXVhbnRpdHk6IDQsXHJcbiAgICAgICAgY2F0ZWdvcnk6IFwiQW1lcmljYW4gUGl6emFcIixcclxuICAgICAgICBFeHRyYXM6IFtdLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICAgIHR5cGU6IFwicGljay11cFwiLFxyXG4gICAgc3RhdHVzOiBcInBlbmRpbmdcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAyLFxyXG4gICAgdGltZTogXCIxNCBkZWMgMjAyMSAzOjM0UG1cIixcclxuICAgIHBheW1lbnRNb2RlOiBcIlJheXpvclwiLFxyXG4gICAgcGF5bWVudElkOiBcInNhbi1yZW1vLWRoMmczaDIxMzIxd2VyXCIsXHJcbiAgICBwaG9uZTogXCIrMSgzNDIpLTM0NTMyXCIsXHJcbiAgICBuYW1lOiBcIkplc3NjYVwiLFxyXG4gICAgYWRyZXNzOiBcIjI0IFQtQmxvY2sgV2VzdCBDb3N0IEFzaWFcIixcclxuXHJcbiAgICBpdGVtczogW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAgdGl0bGU6IFwiUGl6emEgRmFtaWxpYVwiLFxyXG4gICAgICAgIHVybDogXCJodHRwczovL2ltZ3MubWk5LmNvbS91cGxvYWRzL290aGVyLzQ2MTMvcGl6emEtZnJlZS13YWxscGFwZXJfMTkyMHgxMjAwXzgyMTU3LmpwZ1wiLFxyXG4gICAgICAgIHByaWNlOiA0NSxcclxuICAgICAgICBxdWFudGl0eTogNSxcclxuICAgICAgICBjYXRlZ29yeTogXCJBbWVyaWNhbiBGYSxpbGlhICBQaXp6YVwiLFxyXG4gICAgICAgIEV4dHJhczogW1xyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBuYW1lOiBcImxpdGVyIENvY2EgQ29sYVwiLFxyXG4gICAgICAgICAgICBxdWFudGl0eTogMSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6IFwibWluaSBGcmllc1wiLFxyXG4gICAgICAgICAgICBxdWFudGl0eTogMixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgICB0eXBlOiBcInBpY2stdXBcIixcclxuICAgIHN0YXR1czogXCJwZW5kaW5nXCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogMyxcclxuICAgIHRpbWU6IFwiMTQgZGVjIDIwMjEgMzozNFBtXCIsXHJcbiAgICBwYXltZW50TW9kZTogXCJSYXl6b3JcIixcclxuICAgIHBheW1lbnRJZDogXCJzYW4tcmVtby1kaDJnM2gyMTMyMXdlclwiLFxyXG4gICAgcGhvbmU6IFwiKzEoNDU0MzIpLTM0NTMyXCIsXHJcbiAgICBuYW1lOiBcIkFsaXNhXCIsXHJcbiAgICBhZHJlc3M6IFwiMTMgTGlua2luIFBhcmsgU3RyZWV0IFVTQVwiLFxyXG5cclxuICAgIGl0ZW1zOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICB0aXRsZTogXCJDYW1pbGlvbiBGYW1pbGlhXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vaW1ncy5taTkuY29tL3VwbG9hZHMvb3RoZXIvNDYxMy9waXp6YS1mcmVlLXdhbGxwYXBlcl8xOTIweDEyMDBfODIxNTcuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6IDQ1LFxyXG4gICAgICAgIHF1YW50aXR5OiA1MyxcclxuICAgICAgICBjYXRlZ29yeTogXCJDYW1pbGlvbiBQaXp6YVwiLFxyXG4gICAgICAgIEV4dHJhczogW10sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgdHlwZTogXCJDYXNoIE9uIERlbGl2ZXJ5XCIsXHJcbiAgICBzdGF0dXM6IFwibmV3XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogNCxcclxuICAgIHRpbWU6IFwiMTQgZGVjIDIwMjEgMzozNFBtXCIsXHJcbiAgICBwYXltZW50TW9kZTogXCJSYXl6b3JcIixcclxuICAgIHBheW1lbnRJZDogXCJzYW4tcmVtby1kaDJnM2gyMTMyMXdlclwiLFxyXG4gICAgcGhvbmU6IFwiKzEoMzQzMiktMzQ1MzJcIixcclxuICAgIG5hbWU6IFwiUm9jaGVsbGVcIixcclxuICAgIGFkcmVzczogXCIxMiBEb3duU3RyZWV0IExvbmRvblwiLFxyXG5cclxuICAgIGl0ZW1zOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICB0aXRsZTogXCJQaXp6YSBGYW1pbGlhXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vaW1ncy5taTkuY29tL3VwbG9hZHMvb3RoZXIvNDYxMy9waXp6YS1mcmVlLXdhbGxwYXBlcl8xOTIweDEyMDBfODIxNTcuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6IDQ1LFxyXG4gICAgICAgIHF1YW50aXR5OiAxMCxcclxuICAgICAgICBjYXRlZ29yeTogXCJBbWVyaWNhbiBQaXp6YVwiLFxyXG4gICAgICB9LFxyXG5cclxuICAgICAge1xyXG4gICAgICAgIGlkOiAyLFxyXG4gICAgICAgIHRpdGxlOiBcIkh1bnJlIFBpenphXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vaW1ncy5taTkuY29tL3VwbG9hZHMvb3RoZXIvNDYxMy9waXp6YS1mcmVlLXdhbGxwYXBlcl8xOTIweDEyMDBfODIxNTcuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6IDQ1LFxyXG4gICAgICAgIHF1YW50aXR5OiA1LFxyXG4gICAgICAgIGNhdGVnb3J5OiBcIkFtZXJpY2FuIEZhLGlsaWEgIFBpenphXCIsXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG5cclxuICAgIHR5cGU6IFwicGljay11cFwiLFxyXG4gICAgc3RhdHVzOiBcImNvbXBsZXRlZFwiLFxyXG4gIH0sXHJcbl07XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuLy8gcmVhY3RzdHJhcCBjb21wb25lbnRzXG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSBcInJlYWN0c3RyYXBcIjtcblxuLy8gY29yZSBjb21wb25lbnRzXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBhZ2VDaGFuZ2UocHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLXRyYW5zaXRpb24td3JhcHBlci1kaXZcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLXRyYW5zaXRpb24taWNvbi13cmFwcGVyIG1iLTNcIj5cbiAgICAgICAgICA8U3Bpbm5lclxuICAgICAgICAgICAgY29sb3I9XCJ3aGl0ZVwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCI2cmVtXCIsIGhlaWdodDogXCI2cmVtXCIsIGJvcmRlcldpZHRoOiBcIi4zcmVtXCIgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRpdGxlIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICBMb2FkaW5nXG4gICAgICAgIDwvaDQ+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvcGFnZXMvX2FwcCcpXG4iLCJpbXBvcnQgUmVhY3QsIHsgRXJyb3JJbmZvIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQge1xuICBleGVjT25jZSxcbiAgbG9hZEdldEluaXRpYWxQcm9wcyxcbiAgQXBwQ29udGV4dFR5cGUsXG4gIEFwcEluaXRpYWxQcm9wcyxcbiAgQXBwUHJvcHNUeXBlLFxuICBOZXh0V2ViVml0YWxzTWV0cmljLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvdXRpbHMnXG5pbXBvcnQgeyBSb3V0ZXIgfSBmcm9tICcuLi9jbGllbnQvcm91dGVyJ1xuXG5leHBvcnQgeyBBcHBJbml0aWFsUHJvcHMgfVxuXG5leHBvcnQgeyBOZXh0V2ViVml0YWxzTWV0cmljIH1cblxuZXhwb3J0IHR5cGUgQXBwQ29udGV4dCA9IEFwcENvbnRleHRUeXBlPFJvdXRlcj5cblxuZXhwb3J0IHR5cGUgQXBwUHJvcHM8UCA9IHt9PiA9IEFwcFByb3BzVHlwZTxSb3V0ZXIsIFA+XG5cbi8qKlxuICogYEFwcGAgY29tcG9uZW50IGlzIHVzZWQgZm9yIGluaXRpYWxpemUgb2YgcGFnZXMuIEl0IGFsbG93cyBmb3Igb3ZlcndyaXRpbmcgYW5kIGZ1bGwgY29udHJvbCBvZiB0aGUgYHBhZ2VgIGluaXRpYWxpemF0aW9uLlxuICogVGhpcyBhbGxvd3MgZm9yIGtlZXBpbmcgc3RhdGUgYmV0d2VlbiBuYXZpZ2F0aW9uLCBjdXN0b20gZXJyb3IgaGFuZGxpbmcsIGluamVjdGluZyBhZGRpdGlvbmFsIGRhdGEuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGFwcEdldEluaXRpYWxQcm9wcyh7XG4gIENvbXBvbmVudCxcbiAgY3R4LFxufTogQXBwQ29udGV4dCk6IFByb21pc2U8QXBwSW5pdGlhbFByb3BzPiB7XG4gIGNvbnN0IHBhZ2VQcm9wcyA9IGF3YWl0IGxvYWRHZXRJbml0aWFsUHJvcHMoQ29tcG9uZW50LCBjdHgpXG4gIHJldHVybiB7IHBhZ2VQcm9wcyB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEFwcDxQID0ge30sIENQID0ge30sIFMgPSB7fT4gZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQ8XG4gIFAgJiBBcHBQcm9wczxDUD4sXG4gIFNcbj4ge1xuICBzdGF0aWMgb3JpZ0dldEluaXRpYWxQcm9wcyA9IGFwcEdldEluaXRpYWxQcm9wc1xuICBzdGF0aWMgZ2V0SW5pdGlhbFByb3BzID0gYXBwR2V0SW5pdGlhbFByb3BzXG5cbiAgLy8gS2VwdCBoZXJlIGZvciBiYWNrd2FyZHMgY29tcGF0aWJpbGl0eS5cbiAgLy8gV2hlbiBzb21lb25lIGVuZGVkIEFwcCB0aGV5IGNvdWxkIGNhbGwgYHN1cGVyLmNvbXBvbmVudERpZENhdGNoYC5cbiAgLy8gQGRlcHJlY2F0ZWQgVGhpcyBtZXRob2QgaXMgbm8gbG9uZ2VyIG5lZWRlZC4gRXJyb3JzIGFyZSBjYXVnaHQgYXQgdGhlIHRvcCBsZXZlbFxuICBjb21wb25lbnREaWRDYXRjaChlcnJvcjogRXJyb3IsIF9lcnJvckluZm86IEVycm9ySW5mbyk6IHZvaWQge1xuICAgIHRocm93IGVycm9yXG4gIH1cblxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyByb3V0ZXIsIENvbXBvbmVudCwgcGFnZVByb3BzLCBfX05fU1NHLCBfX05fU1NQIH0gPSB0aGlzXG4gICAgICAucHJvcHMgYXMgQXBwUHJvcHM8Q1A+XG5cbiAgICByZXR1cm4gKFxuICAgICAgPENvbXBvbmVudFxuICAgICAgICB7Li4ucGFnZVByb3BzfVxuICAgICAgICB7XG4gICAgICAgICAgLy8gd2UgZG9uJ3QgYWRkIHRoZSBsZWdhY3kgVVJMIHByb3AgaWYgaXQncyB1c2luZyBub24tbGVnYWN5XG4gICAgICAgICAgLy8gbWV0aG9kcyBsaWtlIGdldFN0YXRpY1Byb3BzIGFuZCBnZXRTZXJ2ZXJTaWRlUHJvcHNcbiAgICAgICAgICAuLi4oIShfX05fU1NHIHx8IF9fTl9TU1ApID8geyB1cmw6IGNyZWF0ZVVybChyb3V0ZXIpIH0gOiB7fSlcbiAgICAgICAgfVxuICAgICAgLz5cbiAgICApXG4gIH1cbn1cblxubGV0IHdhcm5Db250YWluZXI6ICgpID0+IHZvaWRcbmxldCB3YXJuVXJsOiAoKSA9PiB2b2lkXG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIHdhcm5Db250YWluZXIgPSBleGVjT25jZSgoKSA9PiB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgYFdhcm5pbmc6IHRoZSBcXGBDb250YWluZXJcXGAgaW4gXFxgX2FwcFxcYCBoYXMgYmVlbiBkZXByZWNhdGVkIGFuZCBzaG91bGQgYmUgcmVtb3ZlZC4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvYXBwLWNvbnRhaW5lci1kZXByZWNhdGVkYFxuICAgIClcbiAgfSlcblxuICB3YXJuVXJsID0gZXhlY09uY2UoKCkgPT4ge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBgV2FybmluZzogdGhlICd1cmwnIHByb3BlcnR5IGlzIGRlcHJlY2F0ZWQuIGh0dHBzOi8vbmV4dGpzLm9yZy9kb2NzL21lc3NhZ2VzL3VybC1kZXByZWNhdGVkYFxuICAgIClcbiAgfSlcbn1cblxuLy8gQGRlcHJlY2F0ZWQgbm9vcCBmb3Igbm93IHVudGlsIHJlbW92YWxcbmV4cG9ydCBmdW5jdGlvbiBDb250YWluZXIocDogYW55KSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuQ29udGFpbmVyKClcbiAgcmV0dXJuIHAuY2hpbGRyZW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVVybChyb3V0ZXI6IFJvdXRlcikge1xuICAvLyBUaGlzIGlzIHRvIG1ha2Ugc3VyZSB3ZSBkb24ndCByZWZlcmVuY2VzIHRoZSByb3V0ZXIgb2JqZWN0IGF0IGNhbGwgdGltZVxuICBjb25zdCB7IHBhdGhuYW1lLCBhc1BhdGgsIHF1ZXJ5IH0gPSByb3V0ZXJcbiAgcmV0dXJuIHtcbiAgICBnZXQgcXVlcnkoKSB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByZXR1cm4gcXVlcnlcbiAgICB9LFxuICAgIGdldCBwYXRobmFtZSgpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiBwYXRobmFtZVxuICAgIH0sXG4gICAgZ2V0IGFzUGF0aCgpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiBhc1BhdGhcbiAgICB9LFxuICAgIGJhY2s6ICgpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJvdXRlci5iYWNrKClcbiAgICB9LFxuICAgIHB1c2g6ICh1cmw6IHN0cmluZywgYXM/OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiByb3V0ZXIucHVzaCh1cmwsIGFzKVxuICAgIH0sXG4gICAgcHVzaFRvOiAoaHJlZjogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgY29uc3QgcHVzaFJvdXRlID0gYXMgPyBocmVmIDogJydcbiAgICAgIGNvbnN0IHB1c2hVcmwgPSBhcyB8fCBocmVmXG5cbiAgICAgIHJldHVybiByb3V0ZXIucHVzaChwdXNoUm91dGUsIHB1c2hVcmwpXG4gICAgfSxcbiAgICByZXBsYWNlOiAodXJsOiBzdHJpbmcsIGFzPzogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICByZXR1cm4gcm91dGVyLnJlcGxhY2UodXJsLCBhcylcbiAgICB9LFxuICAgIHJlcGxhY2VUbzogKGhyZWY6IHN0cmluZywgYXM/OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIGNvbnN0IHJlcGxhY2VSb3V0ZSA9IGFzID8gaHJlZiA6ICcnXG4gICAgICBjb25zdCByZXBsYWNlVXJsID0gYXMgfHwgaHJlZlxuXG4gICAgICByZXR1cm4gcm91dGVyLnJlcGxhY2UocmVwbGFjZVJvdXRlLCByZXBsYWNlVXJsKVxuICAgIH0sXG4gIH1cbn1cbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBSZWFjdERPTSBmcm9tIFwicmVhY3QtZG9tXCI7XG5pbXBvcnQgQXBwIGZyb20gXCJuZXh0L2FwcFwiO1xuaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCB7IFByb3ZpZGVyIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XG5pbXBvcnQgeyBjcmVhdGVTdG9yZSB9IGZyb20gXCJyZWR1eFwiO1xuaW1wb3J0IFBhZ2VDaGFuZ2UgZnJvbSBcImNvbXBvbmVudHMvUGFnZUNoYW5nZS9QYWdlQ2hhbmdlLmpzXCI7XG5pbXBvcnQgcmVkdWNlciBmcm9tIFwiLi4vUmVkdWNlcnMvcmVkdWNlclwiO1xuaW1wb3J0IFwiYXNzZXRzL3BsdWdpbnMvbnVjbGVvL2Nzcy9udWNsZW8uY3NzXCI7XG5pbXBvcnQgXCJAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtZnJlZS9jc3MvYWxsLm1pbi5jc3NcIjtcbmltcG9ydCBcImFzc2V0cy9zY3NzL25leHRqcy1hcmdvbi1kYXNoYm9hcmQuc2Nzc1wiO1xuaW1wb3J0IHtzdG9yZX0gZnJvbSBcIi4uL1JlZHVjZXJzL3JlZHVjZXJcIjtcbmltcG9ydCBGZXRjaEFuZERpc3BhdGNoIGZyb20gXCIuLi9BUElfV09SSy9mZXRjaEFuZERpc3BhdGNoXCI7XG5cblxuXG5Sb3V0ZXIuZXZlbnRzLm9uKFwicm91dGVDaGFuZ2VTdGFydFwiLCAodXJsKSA9PiB7XG4gIGNvbnNvbGUubG9nKGBMb2FkaW5nOiAke3VybH1gKTtcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwiYm9keS1wYWdlLXRyYW5zaXRpb25cIik7XG4gIFJlYWN0RE9NLnJlbmRlcihcbiAgICA8UGFnZUNoYW5nZSBwYXRoPXt1cmx9IC8+LFxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGFnZS10cmFuc2l0aW9uXCIpXG4gICk7XG59KTtcblJvdXRlci5ldmVudHMub24oXCJyb3V0ZUNoYW5nZUNvbXBsZXRlXCIsICgpID0+IHtcbiAgUmVhY3RET00udW5tb3VudENvbXBvbmVudEF0Tm9kZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBhZ2UtdHJhbnNpdGlvblwiKSk7XG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcImJvZHktcGFnZS10cmFuc2l0aW9uXCIpO1xufSk7XG5Sb3V0ZXIuZXZlbnRzLm9uKFwicm91dGVDaGFuZ2VFcnJvclwiLCAoKSA9PiB7XG4gIFJlYWN0RE9NLnVubW91bnRDb21wb25lbnRBdE5vZGUoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlLXRyYW5zaXRpb25cIikpO1xuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5yZW1vdmUoXCJib2R5LXBhZ2UtdHJhbnNpdGlvblwiKTtcbn0pO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeUFwcCBleHRlbmRzIEFwcCB7XG5cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgXG4gICAgbGV0IGNvbW1lbnQgPSBkb2N1bWVudC5jcmVhdGVDb21tZW50KGBcblxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG4qICogTmV4dEpTIEFyZ29uIERhc2hib2FyZCB2MS4xLjAgYmFzZWQgb24gQXJnb24gRGFzaGJvYXJkIFJlYWN0IHYxLjEuMFxuPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cbiogUHJvZHVjdCBQYWdlOiBodHRwczovL3d3dy5jcmVhdGl2ZS10aW0uY29tL3Byb2R1Y3QvbmV4dGpzLWFyZ29uLWRhc2hib2FyZFxuKiBDb3B5cmlnaHQgMjAyMSBDcmVhdGl2ZSBUaW0gKGh0dHBzOi8vd3d3LmNyZWF0aXZlLXRpbS5jb20pXG4qIExpY2Vuc2VkIHVuZGVyIE1JVCAoaHR0cHM6Ly9naXRodWIuY29tL2NyZWF0aXZldGltb2ZmaWNpYWwvbmV4dGpzLWFyZ29uLWRhc2hib2FyZC9ibG9iL21hc3Rlci9MSUNFTlNFLm1kKVxuXG4qIENvZGVkIGJ5IENyZWF0aXZlIFRpbVxuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuKiBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZCBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cblxuYCk7XG4gICAgZG9jdW1lbnQuaW5zZXJ0QmVmb3JlKGNvbW1lbnQsIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCk7XG4gIH1cbiAgc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyh7IENvbXBvbmVudCwgcm91dGVyLCBjdHggfSkge1xuICAgIGxldCBwYWdlUHJvcHMgPSB7fTtcblxuICAgIGlmIChDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzKSB7XG4gICAgICBwYWdlUHJvcHMgPSBhd2FpdCBDb21wb25lbnQuZ2V0SW5pdGlhbFByb3BzKGN0eCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgcGFnZVByb3BzIH07XG4gIH1cblxuXG5cbiAgcmVuZGVyKCkge1xuICAgIFxuICAgIFxuICAgIGNvbnN0IHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSA9IHRoaXMucHJvcHM7XG5cbiAgICBjb25zdCBMYXlvdXQgPSBDb21wb25lbnQubGF5b3V0IHx8ICgoeyBjaGlsZHJlbiB9KSA9PiA8PntjaGlsZHJlbn08Lz4pO1xuXG4gICAgcmV0dXJuIChcbiAgICAgIDxSZWFjdC5GcmFnbWVudD5cbiAgICAgICAgPEhlYWQ+XG4gICAgICAgICAgPG1ldGFcbiAgICAgICAgICAgIG5hbWU9XCJ2aWV3cG9ydFwiXG4gICAgICAgICAgICBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEsIHNocmluay10by1maXQ9bm9cIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPHRpdGxlPlNhbiBSZW1vIEFkbWluIFBhbmVsPC90aXRsZT5cbiAgICAgICAgICA8c2NyaXB0IHNyYz1cImh0dHBzOi8vbWFwcy5nb29nbGVhcGlzLmNvbS9tYXBzL2FwaS9qcz9rZXk9WU9VUl9LRVlfSEVSRVwiPjwvc2NyaXB0PlxuICAgICAgICA8L0hlYWQ+XG4gICAgICAgIDxMYXlvdXQ+XG4gICAgICAgICAgPFByb3ZpZGVyIHN0b3JlPXtzdG9yZX0gPlxuICAgICAgICAgIDxGZXRjaEFuZERpc3BhdGNoIC8+XG4gICAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgICAgIFxuICAgICAgICAgIDwvUHJvdmlkZXI+XG5cbiAgICAgICAgPC9MYXlvdXQ+XG4gICAgICA8L1JlYWN0LkZyYWdtZW50PlxuICAgICk7XG4gIH1cbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF4aW9zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L3JvdXRlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1kb21cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtcmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0c3RyYXBcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic29ja2V0LmlvLWNsaWVudFwiKTsiXSwic291cmNlUm9vdCI6IiJ9