export const categories = [
 

  {
    id:1,
    title: "American Style Pizza",
    url: "https://www.teahub.io/photos/full/23-232612_large-pizza-wallpaper-src-large-pizza-wallpaper-pizza.jpg",
    description:"This item is made in Germany",
    variants:
    [
      {
        id:1,
      title:"variant1",
    },
    {
      id:2,
      title:"variant2",
    },

  ],
  
    size:'lg'
  },
  {
    id:2,
    title: "Calzone",
    url: "https://thumbs.dreamstime.com/b/italian-food-closed-pizza-calzone-spinach-cheese-wooden-background-copy-space-calzone-spinach-cheese-107729251.jpg",
    description:"This item is made in Germany",
    variants:[{
      id:1,
      title:"variant1",
    },
    {
      id:2,
      title:"variant2",
    },

  ],
  
    size:'lg'
  },
  {
    id:3,
    title: "Gemusegerichte",
    url: "https://cdn.pixabay.com/photo/2016/02/19/10/00/food-1209007_960_720.jpg",
    description:"This item is made in Germany",
    variants:[{
      id:1,
      title:"variant1",
    },
    {
      id:2,
      title:"variant2",
    },

  ],
   size:'lg'
  },
  {
    id:4,
    title: "Brot  & Brotchen",
    url:"https://st.depositphotos.com/2226532/3034/i/950/depositphotos_30345395-stock-photo-brot-und-brtchen.jpg",
    description:"This item is made in Germany",
    variants:[{
      title:"variant1",
    },
    {
      id:1,
      title:"variant2",
    },

  ],
  
    size:'lg'
  },
  

];
