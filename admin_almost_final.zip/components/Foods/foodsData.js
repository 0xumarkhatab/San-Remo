export const foodsArray=[
    {
        id:1,
        title:"Pizza Familia",
        url:"https://media-cdn.tripadvisor.com/media/photo-s/11/49/b4/56/photo0jpg.jpg",

        size:"sm",
        category:"Angebot",
        price:"43",
        description:"This Food Is German",
        allergies:"a,e,r,t",

        Extras:[
{
 name:"liter Coca Cola",
 quantity:1
},
{
name:"mini Fries",
quantity:2,
},

],

},
    {
        id:2,
        title:"FlamKuchen",
        url:"https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
        price:"23",
      
        category:"American Pizza",
        url:"https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",

        description:"This Food Is German",
        allergies:"a,e,r,t",
        
        Extras:[],


    },

    {
        id:3,
        title:"Gazzo",
        size:"xlg",
        category:"Pizza",
        url:"https://prod-wolt-venue-images-cdn.wolt.com/5f914334e8bd89fc65eb4647/53630304-17b1-11eb-9229-3e9ff85dedc2_pizza_no_8_2.jpg",

        price:"1441",
        description:"This Food Is German",
        allergies:"a,e,r,t",
        
        Extras:[],


    },
    {
        id:4,
        title:"Margherita",
        
        size:"md",
        category:"Pizza",
        price:"65",
        url:"https://i.pinimg.com/originals/7d/4c/ea/7d4cea99d73d2ea82549de0ea4b80198.jpg",

        description:"This Food Is German",
        allergies:"a,e,r,t",
        
        Extras:[],


    },
    
]


