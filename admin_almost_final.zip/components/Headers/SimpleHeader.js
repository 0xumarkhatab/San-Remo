import React from "react";

// reactstrap components

function SimpleHeader() {
  return (
    <>
      <div className="header mb-4 pb-6 pb-md-4 pt-md-4"></div>
    </>
  );
}

export default SimpleHeader;
