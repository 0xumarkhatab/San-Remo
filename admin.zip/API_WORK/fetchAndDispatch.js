import React from 'react'
import {useSelector,useDispatch} from "react-redux";
import {categories} from "../components/Categories/CategoriesData";
import {foodsArray} from "../components/Foods/foodsData";
import {ordersData} from "../components/Orders/ordersData";


function fetchAndDispatch() {
const dispatch = useDispatch();
 
  dispatch({
    type:'SET_CATEGORIES',
    CATEGORIES:categories,
  }
  );
  dispatch({
    type:'SET_FOODS',
    FOODS:foodsArray,
  }
  );
  dispatch({
    type:'SET_ORDERS',
    ORDERS:ordersData,
    
  }
  );

  
    return 0;

}

export default fetchAndDispatch

