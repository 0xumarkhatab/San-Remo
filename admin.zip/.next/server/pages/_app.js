module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "./API_WORK/fetchAndDispatch.js":
/*!**************************************!*\
  !*** ./API_WORK/fetchAndDispatch.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Categories_CategoriesData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Categories/CategoriesData */ "./components/Categories/CategoriesData.js");
/* harmony import */ var _components_Foods_foodsData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../components/Foods/foodsData */ "./components/Foods/foodsData.js");
/* harmony import */ var _components_Orders_ordersData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/Orders/ordersData */ "./components/Orders/ordersData.js");






function fetchAndDispatch() {
  const dispatch = Object(react_redux__WEBPACK_IMPORTED_MODULE_1__["useDispatch"])();
  dispatch({
    type: 'SET_CATEGORIES',
    CATEGORIES: _components_Categories_CategoriesData__WEBPACK_IMPORTED_MODULE_2__["categories"]
  });
  dispatch({
    type: 'SET_FOODS',
    FOODS: _components_Foods_foodsData__WEBPACK_IMPORTED_MODULE_3__["foodsArray"]
  });
  dispatch({
    type: 'SET_ORDERS',
    ORDERS: _components_Orders_ordersData__WEBPACK_IMPORTED_MODULE_4__["ordersData"]
  });
  return 0;
}

/* harmony default export */ __webpack_exports__["default"] = (fetchAndDispatch);

/***/ }),

/***/ "./Reducers/reducer.js":
/*!*****************************!*\
  !*** ./Reducers/reducer.js ***!
  \*****************************/
/*! exports provided: default, store */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "store", function() { return store; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  FOODS: [],
  CATEGORIES: [],
  ORDERS: [],
  EDIT_PROPS: {},
  DELETE_PROPS: {},
  VIEW_PROPS: null
};

const reducer = (state = initialState, action) => {
  console.log(action);

  switch (action.type) {
    case 'SET_FOODS':
      return _objectSpread(_objectSpread({}, state), {}, {
        FOODS: action.FOODS
      });

    case 'SET_CATEGORIES':
      return _objectSpread(_objectSpread({}, state), {}, {
        CATEGORIES: action.CATEGORIES
      });

    case 'SET_EDIT_PROPS':
      return _objectSpread(_objectSpread({}, state), {}, {
        EDIT_PROPS: action.EDIT_PROPS
      });

    case 'SET_VIEW_PROPS':
      console.log("set");
      return _objectSpread(_objectSpread({}, state), {}, {
        VIEW_PROPS: action.VIEW_PROPS
      });

    case 'SET_DELETE_PROPS':
      return _objectSpread(_objectSpread({}, state), {}, {
        DELETE_PROPS: action.DELETE_PROPS
      });

    case 'SET_ORDERS':
      return _objectSpread(_objectSpread({}, state), {}, {
        ORDERS: action.ORDERS
      });

    default:
      return _objectSpread({}, state);
  }
};

/* harmony default export */ __webpack_exports__["default"] = (reducer);
const store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(reducer);

/***/ }),

/***/ "./assets/plugins/nucleo/css/nucleo.css":
/*!**********************************************!*\
  !*** ./assets/plugins/nucleo/css/nucleo.css ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./assets/scss/nextjs-argon-dashboard.scss":
/*!*************************************************!*\
  !*** ./assets/scss/nextjs-argon-dashboard.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./components/Categories/CategoriesData.js":
/*!*************************************************!*\
  !*** ./components/Categories/CategoriesData.js ***!
  \*************************************************/
/*! exports provided: categories */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categories", function() { return categories; });
const categories = [{
  id: 1,
  title: "American Style Pizza",
  url: "https://www.teahub.io/photos/full/23-232612_large-pizza-wallpaper-src-large-pizza-wallpaper-pizza.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 2,
  title: "Calzone",
  url: "https://thumbs.dreamstime.com/b/italian-food-closed-pizza-calzone-spinach-cheese-wooden-background-copy-space-calzone-spinach-cheese-107729251.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 3,
  title: "Gemusegerichte",
  url: "https://cdn.pixabay.com/photo/2016/02/19/10/00/food-1209007_960_720.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 4,
  title: "Brot  & Brotchen",
  url: "https://st.depositphotos.com/2226532/3034/i/950/depositphotos_30345395-stock-photo-brot-und-brtchen.jpg",
  description: "This item is made in Germany",
  variants: [{
    title: "variant1"
  }, {
    id: 1,
    title: "variant2"
  }],
  size: 'lg'
}];

/***/ }),

/***/ "./components/Foods/foodsData.js":
/*!***************************************!*\
  !*** ./components/Foods/foodsData.js ***!
  \***************************************/
/*! exports provided: foodsArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "foodsArray", function() { return foodsArray; });
const foodsArray = [{
  id: 1,
  title: "Pizza Familia",
  url: "https://media-cdn.tripadvisor.com/media/photo-s/11/49/b4/56/photo0jpg.jpg",
  size: "sm",
  category: "Angebot",
  price: "43",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: [{
    name: "liter Coca Cola",
    quantity: 1
  }, {
    name: "mini Fries",
    quantity: 2
  }]
}, {
  id: 2,
  title: "FlamKuchen",
  url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
  price: "23",
  category: "American Pizza",
  url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}, {
  id: 3,
  title: "Gazzo",
  size: "xlg",
  category: "Pizza",
  url: "https://prod-wolt-venue-images-cdn.wolt.com/5f914334e8bd89fc65eb4647/53630304-17b1-11eb-9229-3e9ff85dedc2_pizza_no_8_2.jpg",
  price: "1441",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}, {
  id: 4,
  title: "Margherita",
  size: "md",
  category: "Pizza",
  price: "65",
  url: "https://i.pinimg.com/originals/7d/4c/ea/7d4cea99d73d2ea82549de0ea4b80198.jpg",
  description: "This Food Is German",
  allergies: "a,e,r,t",
  Extras: []
}];

/***/ }),

/***/ "./components/Orders/ordersData.js":
/*!*****************************************!*\
  !*** ./components/Orders/ordersData.js ***!
  \*****************************************/
/*! exports provided: ordersData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ordersData", function() { return ordersData; });
const ordersData = [{
  id: 1,
  time: "12 Nov 2021 3:34Pm",
  paymentMode: "PayPal",
  paymentId: "san-remo-dh2g3h21321f3",
  phone: "+1(7842)-6532",
  name: "Arnold Jems",
  adress: "45 Oregon Street Los Angels",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 2,
    category: "Pizza",
    Extras: [{
      name: "liter Coca Cola",
      quantity: 1
    }, {
      name: "mini Fries",
      quantity: 2
    }]
  }, {
    id: 2,
    title: "FlamKuchen",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/df/Flameukeusche_2.jpg/375px-Flameukeusche_2.jpg",
    price: 23,
    quantity: 4,
    category: "American Pizza",
    Extras: []
  }],
  type: "pick-up",
  status: "pending"
}, {
  id: 2,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(342)-34532",
  name: "Jessca",
  adress: "24 T-Block West Cost Asia",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 5,
    category: "American Fa,ilia  Pizza",
    Extras: [{
      name: "liter Coca Cola",
      quantity: 1
    }, {
      name: "mini Fries",
      quantity: 2
    }]
  }],
  type: "pick-up",
  status: "pending"
}, {
  id: 3,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(45432)-34532",
  name: "Alisa",
  adress: "13 Linkin Park Street USA",
  items: [{
    id: 1,
    title: "Camilion Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 53,
    category: "Camilion Pizza",
    Extras: []
  }],
  type: "Cash On Delivery",
  status: "new"
}, {
  id: 4,
  time: "14 dec 2021 3:34Pm",
  paymentMode: "Rayzor",
  paymentId: "san-remo-dh2g3h21321wer",
  phone: "+1(3432)-34532",
  name: "Rochelle",
  adress: "12 DownStreet London",
  items: [{
    id: 1,
    title: "Pizza Familia",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 10,
    category: "American Pizza"
  }, {
    id: 2,
    title: "Hunre Pizza",
    url: "https://imgs.mi9.com/uploads/other/4613/pizza-free-wallpaper_1920x1200_82157.jpg",
    price: 45,
    quantity: 5,
    category: "American Fa,ilia  Pizza"
  }],
  type: "pick-up",
  status: "completed"
}];

/***/ }),

/***/ "./components/PageChange/PageChange.js":
/*!*********************************************!*\
  !*** ./components/PageChange/PageChange.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PageChange; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! reactstrap */ "reactstrap");
/* harmony import */ var reactstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(reactstrap__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "E:\\admin\\components\\PageChange\\PageChange.js";
 // reactstrap components

 // core components

function PageChange(props) {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "page-transition-wrapper-div",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "page-transition-icon-wrapper mb-3",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(reactstrap__WEBPACK_IMPORTED_MODULE_2__["Spinner"], {
          color: "white",
          style: {
            width: "6rem",
            height: "6rem",
            borderWidth: ".3rem"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 12,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
        className: "title text-white",
        children: "Loading"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 10,
    columnNumber: 5
  }, this);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@fortawesome/fontawesome-free/css/all.min.css":
/*!********************************************************************!*\
  !*** ./node_modules/@fortawesome/fontawesome-free/css/all.min.css ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.AppInitialProps = _utils.AppInitialProps;
exports.NextWebVitalsMetric = _utils.NextWebVitalsMetric;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps({
  Component,
  ctx
}) {
  const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    const {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return /*#__PURE__*/_react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
let warnContainer;
let warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn(`Warning: the \`Container\` in \`_app\` has been deprecated and should be removed. https://nextjs.org/docs/messages/app-container-deprecated`);
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error(`Warning: the 'url' property is deprecated. https://nextjs.org/docs/messages/url-deprecated`);
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  const {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      const pushRoute = as ? href : '';
      const pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      const replaceRoute = as ? href : '';
      const replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyApp; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var components_PageChange_PageChange_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! components/PageChange/PageChange.js */ "./components/PageChange/PageChange.js");
/* harmony import */ var _Reducers_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Reducers/reducer */ "./Reducers/reducer.js");
/* harmony import */ var assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! assets/plugins/nucleo/css/nucleo.css */ "./assets/plugins/nucleo/css/nucleo.css");
/* harmony import */ var assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(assets_plugins_nucleo_css_nucleo_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @fortawesome/fontawesome-free/css/all.min.css */ "./node_modules/@fortawesome/fontawesome-free/css/all.min.css");
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! assets/scss/nextjs-argon-dashboard.scss */ "./assets/scss/nextjs-argon-dashboard.scss");
/* harmony import */ var assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(assets_scss_nextjs_argon_dashboard_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _API_WORK_fetchAndDispatch__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../API_WORK/fetchAndDispatch */ "./API_WORK/fetchAndDispatch.js");


var _jsxFileName = "E:\\admin\\pages\\_app.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }















next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeStart", url => {
  console.log(`Loading: ${url}`);
  document.body.classList.add("body-page-transition");
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.render( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(components_PageChange_PageChange_js__WEBPACK_IMPORTED_MODULE_8__["default"], {
    path: url
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 22,
    columnNumber: 5
  }, undefined), document.getElementById("page-transition"));
});
next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeComplete", () => {
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});
next_router__WEBPACK_IMPORTED_MODULE_5___default.a.events.on("routeChangeError", () => {
  react_dom__WEBPACK_IMPORTED_MODULE_2___default.a.unmountComponentAtNode(document.getElementById("page-transition"));
  document.body.classList.remove("body-page-transition");
});
class MyApp extends next_app__WEBPACK_IMPORTED_MODULE_3___default.a {
  componentDidMount() {
    let comment = document.createComment(`

=========================================================
* * NextJS Argon Dashboard v1.1.0 based on Argon Dashboard React v1.1.0
=========================================================

* Product Page: https://www.creative-tim.com/product/nextjs-argon-dashboard
* Copyright 2021 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/nextjs-argon-dashboard/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

`);
    document.insertBefore(comment, document.documentElement);
  }

  static async getInitialProps({
    Component,
    router,
    ctx
  }) {
    let pageProps = {};

    if (Component.getInitialProps) {
      pageProps = await Component.getInitialProps(ctx);
    }

    return {
      pageProps
    };
  }

  render() {
    const {
      Component,
      pageProps
    } = this.props;

    const Layout = Component.layout || (({
      children
    }) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: children
    }, void 0, false));

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1___default.a.Fragment, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_4___default.a, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
          name: "viewport",
          content: "width=device-width, initial-scale=1, shrink-to-fit=no"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
          children: "San Remo Admin Panel"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
          src: "https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 79,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Layout, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_redux__WEBPACK_IMPORTED_MODULE_6__["Provider"], {
          store: _Reducers_reducer__WEBPACK_IMPORTED_MODULE_9__["store"],
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_API_WORK_fetchAndDispatch__WEBPACK_IMPORTED_MODULE_13__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 11
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 11
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 78,
      columnNumber: 7
    }, this);
  }

}

/***/ }),

/***/ 0:
/*!****************************************!*\
  !*** multi private-next-pages/_app.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.js */"./pages/_app.js");


/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "reactstrap":
/*!*****************************!*\
  !*** external "reactstrap" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("reactstrap");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovLy8uL0FQSV9XT1JLL2ZldGNoQW5kRGlzcGF0Y2guanMiLCJ3ZWJwYWNrOi8vLy4vUmVkdWNlcnMvcmVkdWNlci5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0NhdGVnb3JpZXMvQ2F0ZWdvcmllc0RhdGEuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9Gb29kcy9mb29kc0RhdGEuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9PcmRlcnMvb3JkZXJzRGF0YS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1BhZ2VDaGFuZ2UvUGFnZUNoYW5nZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvYXBwLmpzIiwid2VicGFjazovLy8uLi8uLi9wYWdlcy9fYXBwLnRzeCIsIndlYnBhY2s6Ly8vLi9wYWdlcy9fYXBwLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvcm91dGVyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1kb21cIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1yZWR1eFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0c3RyYXBcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eFwiIl0sIm5hbWVzIjpbImZldGNoQW5kRGlzcGF0Y2giLCJkaXNwYXRjaCIsInVzZURpc3BhdGNoIiwidHlwZSIsIkNBVEVHT1JJRVMiLCJjYXRlZ29yaWVzIiwiRk9PRFMiLCJmb29kc0FycmF5IiwiT1JERVJTIiwib3JkZXJzRGF0YSIsImluaXRpYWxTdGF0ZSIsIkVESVRfUFJPUFMiLCJERUxFVEVfUFJPUFMiLCJWSUVXX1BST1BTIiwicmVkdWNlciIsInN0YXRlIiwiYWN0aW9uIiwiY29uc29sZSIsImxvZyIsInN0b3JlIiwiY3JlYXRlU3RvcmUiLCJpZCIsInRpdGxlIiwidXJsIiwiZGVzY3JpcHRpb24iLCJ2YXJpYW50cyIsInNpemUiLCJjYXRlZ29yeSIsInByaWNlIiwiYWxsZXJnaWVzIiwiRXh0cmFzIiwibmFtZSIsInF1YW50aXR5IiwidGltZSIsInBheW1lbnRNb2RlIiwicGF5bWVudElkIiwicGhvbmUiLCJhZHJlc3MiLCJpdGVtcyIsInN0YXR1cyIsIlBhZ2VDaGFuZ2UiLCJwcm9wcyIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyV2lkdGgiLCJwYWdlUHJvcHMiLCJSZWFjdCIsIkNvbXBvbmVudCIsImNvbXBvbmVudERpZENhdGNoIiwicmVuZGVyIiwiX19OX1NTRyIsImNyZWF0ZVVybCIsIkFwcCIsIm9yaWdHZXRJbml0aWFsUHJvcHMiLCJhcHBHZXRJbml0aWFsUHJvcHMiLCJnZXRJbml0aWFsUHJvcHMiLCJ3YXJuQ29udGFpbmVyIiwid2FyblVybCIsInAiLCJiYWNrIiwicm91dGVyIiwicHVzaCIsInB1c2hUbyIsInB1c2hSb3V0ZSIsImFzIiwicHVzaFVybCIsInJlcGxhY2UiLCJyZXBsYWNlVG8iLCJyZXBsYWNlUm91dGUiLCJyZXBsYWNlVXJsIiwiUm91dGVyIiwiZXZlbnRzIiwib24iLCJkb2N1bWVudCIsImJvZHkiLCJjbGFzc0xpc3QiLCJhZGQiLCJSZWFjdERPTSIsImdldEVsZW1lbnRCeUlkIiwidW5tb3VudENvbXBvbmVudEF0Tm9kZSIsInJlbW92ZSIsIk15QXBwIiwiY29tcG9uZW50RGlkTW91bnQiLCJjb21tZW50IiwiY3JlYXRlQ29tbWVudCIsImluc2VydEJlZm9yZSIsImRvY3VtZW50RWxlbWVudCIsImN0eCIsIkxheW91dCIsImxheW91dCIsImNoaWxkcmVuIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUN4RkEsK0Q7Ozs7Ozs7Ozs7OztBQ0FBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLFNBQVNBLGdCQUFULEdBQTRCO0FBQzVCLFFBQU1DLFFBQVEsR0FBR0MsK0RBQVcsRUFBNUI7QUFFRUQsVUFBUSxDQUFDO0FBQ1BFLFFBQUksRUFBQyxnQkFERTtBQUVQQyxjQUFVLEVBQUNDLGdGQUFVQTtBQUZkLEdBQUQsQ0FBUjtBQUtBSixVQUFRLENBQUM7QUFDUEUsUUFBSSxFQUFDLFdBREU7QUFFUEcsU0FBSyxFQUFDQyxzRUFBVUE7QUFGVCxHQUFELENBQVI7QUFLQU4sVUFBUSxDQUFDO0FBQ1BFLFFBQUksRUFBQyxZQURFO0FBRVBLLFVBQU0sRUFBQ0Msd0VBQVVBO0FBRlYsR0FBRCxDQUFSO0FBUUUsU0FBTyxDQUFQO0FBRUg7O0FBRWNULCtFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQ0E7QUFFQSxNQUFNVSxZQUFZLEdBQUc7QUFDbkJKLE9BQUssRUFBRSxFQURZO0FBRW5CRixZQUFVLEVBQUMsRUFGUTtBQUduQkksUUFBTSxFQUFDLEVBSFk7QUFJbkJHLFlBQVUsRUFBQyxFQUpRO0FBS25CQyxjQUFZLEVBQUMsRUFMTTtBQU1uQkMsWUFBVSxFQUFDO0FBTlEsQ0FBckI7O0FBYUEsTUFBTUMsT0FBTyxHQUFHLENBQUNDLEtBQUssR0FBR0wsWUFBVCxFQUF1Qk0sTUFBdkIsS0FBa0M7QUFDaERDLFNBQU8sQ0FBQ0MsR0FBUixDQUFZRixNQUFaOztBQUdBLFVBQVFBLE1BQU0sQ0FBQ2IsSUFBZjtBQUNFLFNBQUssV0FBTDtBQUNFLDZDQUNLWSxLQURMO0FBRUNULGFBQUssRUFBQ1UsTUFBTSxDQUFDVjtBQUZkOztBQUlKLFNBQUssZ0JBQUw7QUFDRSw2Q0FDS1MsS0FETDtBQUVFWCxrQkFBVSxFQUFDWSxNQUFNLENBQUNaO0FBRnBCOztBQUlKLFNBQUssZ0JBQUw7QUFDRSw2Q0FDS1csS0FETDtBQUVFSixrQkFBVSxFQUFDSyxNQUFNLENBQUNMO0FBRnBCOztBQU1GLFNBQUssZ0JBQUw7QUFDRU0sYUFBTyxDQUFDQyxHQUFSLENBQVksS0FBWjtBQUNBLDZDQUNLSCxLQURMO0FBRUVGLGtCQUFVLEVBQUNHLE1BQU0sQ0FBQ0g7QUFGcEI7O0FBS0EsU0FBSyxrQkFBTDtBQUNFLDZDQUNLRSxLQURMO0FBRUVILG9CQUFZLEVBQUNJLE1BQU0sQ0FBQ0o7QUFGdEI7O0FBSUYsU0FBSyxZQUFMO0FBQ0UsNkNBQ0tHLEtBREw7QUFFRVAsY0FBTSxFQUFDUSxNQUFNLENBQUNSO0FBRmhCOztBQU1BO0FBQ0UsK0JBQ0tPLEtBREw7QUF0Q0o7QUEwQ0QsQ0E5Q0Q7O0FBZ0RlRCxzRUFBZjtBQUNPLE1BQU1LLEtBQUssR0FBR0MseURBQVcsQ0FBQ04sT0FBRCxDQUF6QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEVQO0FBQUE7QUFBTyxNQUFNVCxVQUFVLEdBQUcsQ0FHeEI7QUFDRWdCLElBQUUsRUFBQyxDQURMO0FBRUVDLE9BQUssRUFBRSxzQkFGVDtBQUdFQyxLQUFHLEVBQUUsdUdBSFA7QUFJRUMsYUFBVyxFQUFDLDhCQUpkO0FBS0VDLFVBQVEsRUFDUixDQUNFO0FBQ0VKLE1BQUUsRUFBQyxDQURMO0FBRUFDLFNBQUssRUFBQztBQUZOLEdBREYsRUFLQTtBQUNFRCxNQUFFLEVBQUMsQ0FETDtBQUVFQyxTQUFLLEVBQUM7QUFGUixHQUxBLENBTkY7QUFrQkVJLE1BQUksRUFBQztBQWxCUCxDQUh3QixFQXVCeEI7QUFDRUwsSUFBRSxFQUFDLENBREw7QUFFRUMsT0FBSyxFQUFFLFNBRlQ7QUFHRUMsS0FBRyxFQUFFLG9KQUhQO0FBSUVDLGFBQVcsRUFBQyw4QkFKZDtBQUtFQyxVQUFRLEVBQUMsQ0FBQztBQUNSSixNQUFFLEVBQUMsQ0FESztBQUVSQyxTQUFLLEVBQUM7QUFGRSxHQUFELEVBSVQ7QUFDRUQsTUFBRSxFQUFDLENBREw7QUFFRUMsU0FBSyxFQUFDO0FBRlIsR0FKUyxDQUxYO0FBZ0JFSSxNQUFJLEVBQUM7QUFoQlAsQ0F2QndCLEVBeUN4QjtBQUNFTCxJQUFFLEVBQUMsQ0FETDtBQUVFQyxPQUFLLEVBQUUsZ0JBRlQ7QUFHRUMsS0FBRyxFQUFFLHlFQUhQO0FBSUVDLGFBQVcsRUFBQyw4QkFKZDtBQUtFQyxVQUFRLEVBQUMsQ0FBQztBQUNSSixNQUFFLEVBQUMsQ0FESztBQUVSQyxTQUFLLEVBQUM7QUFGRSxHQUFELEVBSVQ7QUFDRUQsTUFBRSxFQUFDLENBREw7QUFFRUMsU0FBSyxFQUFDO0FBRlIsR0FKUyxDQUxYO0FBZUNJLE1BQUksRUFBQztBQWZOLENBekN3QixFQTBEeEI7QUFDRUwsSUFBRSxFQUFDLENBREw7QUFFRUMsT0FBSyxFQUFFLGtCQUZUO0FBR0VDLEtBQUcsRUFBQyx5R0FITjtBQUlFQyxhQUFXLEVBQUMsOEJBSmQ7QUFLRUMsVUFBUSxFQUFDLENBQUM7QUFDUkgsU0FBSyxFQUFDO0FBREUsR0FBRCxFQUdUO0FBQ0VELE1BQUUsRUFBQyxDQURMO0FBRUVDLFNBQUssRUFBQztBQUZSLEdBSFMsQ0FMWDtBQWVFSSxNQUFJLEVBQUM7QUFmUCxDQTFEd0IsQ0FBbkIsQzs7Ozs7Ozs7Ozs7O0FDQVA7QUFBQTtBQUFPLE1BQU1uQixVQUFVLEdBQUMsQ0FDcEI7QUFDSWMsSUFBRSxFQUFDLENBRFA7QUFFSUMsT0FBSyxFQUFDLGVBRlY7QUFHSUMsS0FBRyxFQUFDLDJFQUhSO0FBS0lHLE1BQUksRUFBQyxJQUxUO0FBTUlDLFVBQVEsRUFBQyxTQU5iO0FBT0lDLE9BQUssRUFBQyxJQVBWO0FBUUlKLGFBQVcsRUFBQyxxQkFSaEI7QUFTSUssV0FBUyxFQUFDLFNBVGQ7QUFXSUMsUUFBTSxFQUFDLENBQ2Y7QUFDQ0MsUUFBSSxFQUFDLGlCQUROO0FBRUNDLFlBQVEsRUFBQztBQUZWLEdBRGUsRUFLZjtBQUNBRCxRQUFJLEVBQUMsWUFETDtBQUVBQyxZQUFRLEVBQUM7QUFGVCxHQUxlO0FBWFgsQ0FEb0IsRUF5QnBCO0FBQ0lYLElBQUUsRUFBQyxDQURQO0FBRUlDLE9BQUssRUFBQyxZQUZWO0FBR0lDLEtBQUcsRUFBQyx5R0FIUjtBQUlJSyxPQUFLLEVBQUMsSUFKVjtBQU1JRCxVQUFRLEVBQUMsZ0JBTmI7QUFPSUosS0FBRyxFQUFDLHlHQVBSO0FBU0lDLGFBQVcsRUFBQyxxQkFUaEI7QUFVSUssV0FBUyxFQUFDLFNBVmQ7QUFZSUMsUUFBTSxFQUFDO0FBWlgsQ0F6Qm9CLEVBMENwQjtBQUNJVCxJQUFFLEVBQUMsQ0FEUDtBQUVJQyxPQUFLLEVBQUMsT0FGVjtBQUdJSSxNQUFJLEVBQUMsS0FIVDtBQUlJQyxVQUFRLEVBQUMsT0FKYjtBQUtJSixLQUFHLEVBQUMsNEhBTFI7QUFPSUssT0FBSyxFQUFDLE1BUFY7QUFRSUosYUFBVyxFQUFDLHFCQVJoQjtBQVNJSyxXQUFTLEVBQUMsU0FUZDtBQVdJQyxRQUFNLEVBQUM7QUFYWCxDQTFDb0IsRUF5RHBCO0FBQ0lULElBQUUsRUFBQyxDQURQO0FBRUlDLE9BQUssRUFBQyxZQUZWO0FBSUlJLE1BQUksRUFBQyxJQUpUO0FBS0lDLFVBQVEsRUFBQyxPQUxiO0FBTUlDLE9BQUssRUFBQyxJQU5WO0FBT0lMLEtBQUcsRUFBQyw4RUFQUjtBQVNJQyxhQUFXLEVBQUMscUJBVGhCO0FBVUlLLFdBQVMsRUFBQyxTQVZkO0FBWUlDLFFBQU0sRUFBQztBQVpYLENBekRvQixDQUFqQixDOzs7Ozs7Ozs7Ozs7QUNBUDtBQUFBO0FBQU8sTUFBTXJCLFVBQVUsR0FBRyxDQUN4QjtBQUNFWSxJQUFFLEVBQUUsQ0FETjtBQUVFWSxNQUFJLEVBQUUsb0JBRlI7QUFHRUMsYUFBVyxFQUFFLFFBSGY7QUFJRUMsV0FBUyxFQUFFLHdCQUpiO0FBS0VDLE9BQUssRUFBRSxlQUxUO0FBTUVMLE1BQUksRUFBRSxhQU5SO0FBT0VNLFFBQU0sRUFBRSw2QkFQVjtBQVNFQyxPQUFLLEVBQUUsQ0FDTDtBQUNFakIsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGVBRlQ7QUFHRUMsT0FBRyxFQUFFLGtGQUhQO0FBSUVLLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRSxPQU5aO0FBUUVHLFVBQU0sRUFBRSxDQUNOO0FBQ0VDLFVBQUksRUFBRSxpQkFEUjtBQUVFQyxjQUFRLEVBQUU7QUFGWixLQURNLEVBS047QUFDRUQsVUFBSSxFQUFFLFlBRFI7QUFFRUMsY0FBUSxFQUFFO0FBRlosS0FMTTtBQVJWLEdBREssRUFxQkw7QUFDRVgsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLFlBRlQ7QUFHRUMsT0FBRyxFQUFFLHlHQUhQO0FBSUVLLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRSxnQkFOWjtBQU9FRyxVQUFNLEVBQUU7QUFQVixHQXJCSyxDQVRUO0FBd0NFM0IsTUFBSSxFQUFFLFNBeENSO0FBeUNFb0MsUUFBTSxFQUFFO0FBekNWLENBRHdCLEVBNEN4QjtBQUNFbEIsSUFBRSxFQUFFLENBRE47QUFFRVksTUFBSSxFQUFFLG9CQUZSO0FBR0VDLGFBQVcsRUFBRSxRQUhmO0FBSUVDLFdBQVMsRUFBRSx5QkFKYjtBQUtFQyxPQUFLLEVBQUUsZUFMVDtBQU1FTCxNQUFJLEVBQUUsUUFOUjtBQU9FTSxRQUFNLEVBQUUsMkJBUFY7QUFTRUMsT0FBSyxFQUFFLENBQ0w7QUFDRWpCLE1BQUUsRUFBRSxDQUROO0FBRUVDLFNBQUssRUFBRSxlQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFSyxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsQ0FMWjtBQU1FTCxZQUFRLEVBQUUseUJBTlo7QUFPRUcsVUFBTSxFQUFFLENBQ047QUFDRUMsVUFBSSxFQUFFLGlCQURSO0FBRUVDLGNBQVEsRUFBRTtBQUZaLEtBRE0sRUFLTjtBQUNFRCxVQUFJLEVBQUUsWUFEUjtBQUVFQyxjQUFRLEVBQUU7QUFGWixLQUxNO0FBUFYsR0FESyxDQVRUO0FBNkJFN0IsTUFBSSxFQUFFLFNBN0JSO0FBOEJFb0MsUUFBTSxFQUFFO0FBOUJWLENBNUN3QixFQTRFeEI7QUFDRWxCLElBQUUsRUFBRSxDQUROO0FBRUVZLE1BQUksRUFBRSxvQkFGUjtBQUdFQyxhQUFXLEVBQUUsUUFIZjtBQUlFQyxXQUFTLEVBQUUseUJBSmI7QUFLRUMsT0FBSyxFQUFFLGlCQUxUO0FBTUVMLE1BQUksRUFBRSxPQU5SO0FBT0VNLFFBQU0sRUFBRSwyQkFQVjtBQVNFQyxPQUFLLEVBQUUsQ0FDTDtBQUNFakIsTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGtCQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFSyxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsRUFMWjtBQU1FTCxZQUFRLEVBQUUsZ0JBTlo7QUFPRUcsVUFBTSxFQUFFO0FBUFYsR0FESyxDQVRUO0FBb0JFM0IsTUFBSSxFQUFFLGtCQXBCUjtBQXFCRW9DLFFBQU0sRUFBRTtBQXJCVixDQTVFd0IsRUFtR3hCO0FBQ0VsQixJQUFFLEVBQUUsQ0FETjtBQUVFWSxNQUFJLEVBQUUsb0JBRlI7QUFHRUMsYUFBVyxFQUFFLFFBSGY7QUFJRUMsV0FBUyxFQUFFLHlCQUpiO0FBS0VDLE9BQUssRUFBRSxnQkFMVDtBQU1FTCxNQUFJLEVBQUUsVUFOUjtBQU9FTSxRQUFNLEVBQUUsc0JBUFY7QUFTRUMsT0FBSyxFQUFFLENBQ0w7QUFDRWpCLE1BQUUsRUFBRSxDQUROO0FBRUVDLFNBQUssRUFBRSxlQUZUO0FBR0VDLE9BQUcsRUFBRSxrRkFIUDtBQUlFSyxTQUFLLEVBQUUsRUFKVDtBQUtFSSxZQUFRLEVBQUUsRUFMWjtBQU1FTCxZQUFRLEVBQUU7QUFOWixHQURLLEVBVUw7QUFDRU4sTUFBRSxFQUFFLENBRE47QUFFRUMsU0FBSyxFQUFFLGFBRlQ7QUFHRUMsT0FBRyxFQUFFLGtGQUhQO0FBSUVLLFNBQUssRUFBRSxFQUpUO0FBS0VJLFlBQVEsRUFBRSxDQUxaO0FBTUVMLFlBQVEsRUFBRTtBQU5aLEdBVkssQ0FUVDtBQTZCRXhCLE1BQUksRUFBRSxTQTdCUjtBQThCRW9DLFFBQU0sRUFBRTtBQTlCVixDQW5Hd0IsQ0FBbkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQ0VQOztDQUdBOztBQUVlLFNBQVNDLFVBQVQsQ0FBb0JDLEtBQXBCLEVBQTJCO0FBQ3hDLHNCQUNFO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsNkJBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsbUNBQWY7QUFBQSwrQkFDRSxxRUFBQyxrREFBRDtBQUNFLGVBQUssRUFBQyxPQURSO0FBRUUsZUFBSyxFQUFFO0FBQUVDLGlCQUFLLEVBQUUsTUFBVDtBQUFpQkMsa0JBQU0sRUFBRSxNQUF6QjtBQUFpQ0MsdUJBQVcsRUFBRTtBQUE5QztBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFPRTtBQUFJLGlCQUFTLEVBQUMsa0JBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUFlRCxDOzs7Ozs7Ozs7OztBQ3ZCRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHdDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkEsaUJBQWlCLG1CQUFPLENBQUMsaUVBQW1COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTVDOztBQUNBOzs7O0FBa0JBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGtDQUFrQztBQUFBO0FBQWxDO0FBQWtDLENBQWxDLEVBR3lDO0FBQ3ZDLFFBQU1DLFNBQVMsR0FBRyxNQUFNLDJDQUF4QixHQUF3QixDQUF4QjtBQUNBLFNBQU87QUFBUDtBQUFPLEdBQVA7QUFHYTs7QUFBQSxrQkFBMkNDLGVBQU1DLFNBQWpELENBR2I7QUFJQTtBQUNBO0FBQ0E7QUFDQUMsbUJBQWlCLG9CQUE0QztBQUMzRDtBQUdGQzs7QUFBQUEsUUFBTSxHQUFHO0FBQ1AsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUFxRCxLQUEzRDtBQUdBLHdCQUNFLHFFQUdJO0FBQ0E7QUFDSSxNQUFFQyxPQUFPLElBQVQsV0FBd0I7QUFBRTNCLFNBQUcsRUFBRTRCLFNBQVMsQ0FBeEMsTUFBd0M7QUFBaEIsS0FBeEIsR0FOVixFQUNFLEVBREY7QUFmRjs7QUFBQTs7O0FBSG1CQyxHLENBSVpDLG1CQUpZRCxHQUlVRSxrQkFKVkY7QUFBQUEsRyxDQUtaRyxlQUxZSCxHQUtNRSxrQkFMTkY7QUErQnJCO0FBQ0E7O0FBRUEsVUFBMkM7QUFDekNJLGVBQWEsR0FBRyxxQkFBUyxNQUFNO0FBQzdCdkMsV0FBTyxDQUFQQTtBQURGdUMsR0FBZ0IsQ0FBaEJBO0FBTUFDLFNBQU8sR0FBRyxxQkFBUyxNQUFNO0FBQ3ZCeEMsV0FBTyxDQUFQQTtBQURGd0MsR0FBVSxDQUFWQTtBQU9GLEMsQ0FBQTs7O0FBQ08sc0JBQTJCO0FBQ2hDLFlBQTJDRCxhQUFhO0FBQ3hELFNBQU9FLENBQUMsQ0FBUjtBQUdLOztBQUFBLDJCQUFtQztBQUN4QztBQUNBLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUFOO0FBQ0EsU0FBTztBQUNMLGdCQUFZO0FBQ1YsZ0JBQTJDRCxPQUFPO0FBQ2xEO0FBSEc7O0FBS0wsbUJBQWU7QUFDYixnQkFBMkNBLE9BQU87QUFDbEQ7QUFQRzs7QUFTTCxpQkFBYTtBQUNYLGdCQUEyQ0EsT0FBTztBQUNsRDtBQVhHOztBQWFMRSxRQUFJLEVBQUUsTUFBTTtBQUNWLGdCQUEyQ0YsT0FBTztBQUNsREcsWUFBTSxDQUFOQTtBQWZHO0FBaUJMQyxRQUFJLEVBQUUsYUFBOEI7QUFDbEMsZ0JBQTJDSixPQUFPO0FBQ2xELGFBQU9HLE1BQU0sQ0FBTkEsVUFBUCxFQUFPQSxDQUFQO0FBbkJHO0FBcUJMRSxVQUFNLEVBQUUsY0FBK0I7QUFDckMsZ0JBQTJDTCxPQUFPO0FBQ2xELFlBQU1NLFNBQVMsR0FBR0MsRUFBRSxVQUFwQjtBQUNBLFlBQU1DLE9BQU8sR0FBR0QsRUFBRSxJQUFsQjtBQUVBLGFBQU9KLE1BQU0sQ0FBTkEsZ0JBQVAsT0FBT0EsQ0FBUDtBQTFCRztBQTRCTE0sV0FBTyxFQUFFLGFBQThCO0FBQ3JDLGdCQUEyQ1QsT0FBTztBQUNsRCxhQUFPRyxNQUFNLENBQU5BLGFBQVAsRUFBT0EsQ0FBUDtBQTlCRztBQWdDTE8sYUFBUyxFQUFFLGNBQStCO0FBQ3hDLGdCQUEyQ1YsT0FBTztBQUNsRCxZQUFNVyxZQUFZLEdBQUdKLEVBQUUsVUFBdkI7QUFDQSxZQUFNSyxVQUFVLEdBQUdMLEVBQUUsSUFBckI7QUFFQSxhQUFPSixNQUFNLENBQU5BLHNCQUFQLFVBQU9BLENBQVA7QUFyQ0o7QUFBTyxHQUFQO0FBd0NELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUlBVSxrREFBTSxDQUFDQyxNQUFQLENBQWNDLEVBQWQsQ0FBaUIsa0JBQWpCLEVBQXNDakQsR0FBRCxJQUFTO0FBQzVDTixTQUFPLENBQUNDLEdBQVIsQ0FBYSxZQUFXSyxHQUFJLEVBQTVCO0FBQ0FrRCxVQUFRLENBQUNDLElBQVQsQ0FBY0MsU0FBZCxDQUF3QkMsR0FBeEIsQ0FBNEIsc0JBQTVCO0FBQ0FDLGtEQUFRLENBQUM1QixNQUFULGVBQ0UscUVBQUMsMkVBQUQ7QUFBWSxRQUFJLEVBQUUxQjtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsRUFFRWtELFFBQVEsQ0FBQ0ssY0FBVCxDQUF3QixpQkFBeEIsQ0FGRjtBQUlELENBUEQ7QUFRQVIsa0RBQU0sQ0FBQ0MsTUFBUCxDQUFjQyxFQUFkLENBQWlCLHFCQUFqQixFQUF3QyxNQUFNO0FBQzVDSyxrREFBUSxDQUFDRSxzQkFBVCxDQUFnQ04sUUFBUSxDQUFDSyxjQUFULENBQXdCLGlCQUF4QixDQUFoQztBQUNBTCxVQUFRLENBQUNDLElBQVQsQ0FBY0MsU0FBZCxDQUF3QkssTUFBeEIsQ0FBK0Isc0JBQS9CO0FBQ0QsQ0FIRDtBQUlBVixrREFBTSxDQUFDQyxNQUFQLENBQWNDLEVBQWQsQ0FBaUIsa0JBQWpCLEVBQXFDLE1BQU07QUFDekNLLGtEQUFRLENBQUNFLHNCQUFULENBQWdDTixRQUFRLENBQUNLLGNBQVQsQ0FBd0IsaUJBQXhCLENBQWhDO0FBQ0FMLFVBQVEsQ0FBQ0MsSUFBVCxDQUFjQyxTQUFkLENBQXdCSyxNQUF4QixDQUErQixzQkFBL0I7QUFDRCxDQUhEO0FBS2UsTUFBTUMsS0FBTixTQUFvQjdCLCtDQUFwQixDQUF3QjtBQUVyQzhCLG1CQUFpQixHQUFHO0FBRWxCLFFBQUlDLE9BQU8sR0FBR1YsUUFBUSxDQUFDVyxhQUFULENBQXdCO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBaEJrQixDQUFkO0FBaUJBWCxZQUFRLENBQUNZLFlBQVQsQ0FBc0JGLE9BQXRCLEVBQStCVixRQUFRLENBQUNhLGVBQXhDO0FBQ0Q7O0FBQ0QsZUFBYS9CLGVBQWIsQ0FBNkI7QUFBRVIsYUFBRjtBQUFhYSxVQUFiO0FBQXFCMkI7QUFBckIsR0FBN0IsRUFBeUQ7QUFDdkQsUUFBSTFDLFNBQVMsR0FBRyxFQUFoQjs7QUFFQSxRQUFJRSxTQUFTLENBQUNRLGVBQWQsRUFBK0I7QUFDN0JWLGVBQVMsR0FBRyxNQUFNRSxTQUFTLENBQUNRLGVBQVYsQ0FBMEJnQyxHQUExQixDQUFsQjtBQUNEOztBQUVELFdBQU87QUFBRTFDO0FBQUYsS0FBUDtBQUNEOztBQUlESSxRQUFNLEdBQUc7QUFHUCxVQUFNO0FBQUVGLGVBQUY7QUFBYUY7QUFBYixRQUEyQixLQUFLSixLQUF0Qzs7QUFFQSxVQUFNK0MsTUFBTSxHQUFHekMsU0FBUyxDQUFDMEMsTUFBVixLQUFxQixDQUFDO0FBQUVDO0FBQUYsS0FBRCxrQkFBa0I7QUFBQSxnQkFBR0E7QUFBSCxxQkFBdkMsQ0FBZjs7QUFFQSx3QkFDRSxxRUFBQyw0Q0FBRCxDQUFPLFFBQVA7QUFBQSw4QkFDRSxxRUFBQyxnREFBRDtBQUFBLGdDQUNFO0FBQ0UsY0FBSSxFQUFDLFVBRFA7QUFFRSxpQkFBTyxFQUFDO0FBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUxGLGVBTUU7QUFBUSxhQUFHLEVBQUM7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBU0UscUVBQUMsTUFBRDtBQUFBLCtCQUNFLHFFQUFDLG9EQUFEO0FBQVUsZUFBSyxFQUFFdkUsdURBQWpCO0FBQUEsa0NBQ0EscUVBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFEQSxlQUVBLHFFQUFDLFNBQUQsb0JBQWUwQixTQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGO0FBb0JEOztBQTlEb0MsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ3ZDLHNDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtEOzs7Ozs7Ozs7OztBQ0FBLHVDOzs7Ozs7Ozs7OztBQ0FBLGtDIiwiZmlsZSI6InBhZ2VzL19hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMCk7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3V0aWxzLmpzXCIpOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHt1c2VTZWxlY3Rvcix1c2VEaXNwYXRjaH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCB7Y2F0ZWdvcmllc30gZnJvbSBcIi4uL2NvbXBvbmVudHMvQ2F0ZWdvcmllcy9DYXRlZ29yaWVzRGF0YVwiO1xyXG5pbXBvcnQge2Zvb2RzQXJyYXl9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zvb2RzL2Zvb2RzRGF0YVwiO1xyXG5pbXBvcnQge29yZGVyc0RhdGF9IGZyb20gXCIuLi9jb21wb25lbnRzL09yZGVycy9vcmRlcnNEYXRhXCI7XHJcblxyXG5cclxuZnVuY3Rpb24gZmV0Y2hBbmREaXNwYXRjaCgpIHtcclxuY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xyXG4gXHJcbiAgZGlzcGF0Y2goe1xyXG4gICAgdHlwZTonU0VUX0NBVEVHT1JJRVMnLFxyXG4gICAgQ0FURUdPUklFUzpjYXRlZ29yaWVzLFxyXG4gIH1cclxuICApO1xyXG4gIGRpc3BhdGNoKHtcclxuICAgIHR5cGU6J1NFVF9GT09EUycsXHJcbiAgICBGT09EUzpmb29kc0FycmF5LFxyXG4gIH1cclxuICApO1xyXG4gIGRpc3BhdGNoKHtcclxuICAgIHR5cGU6J1NFVF9PUkRFUlMnLFxyXG4gICAgT1JERVJTOm9yZGVyc0RhdGEsXHJcbiAgICBcclxuICB9XHJcbiAgKTtcclxuXHJcbiAgXHJcbiAgICByZXR1cm4gMDtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZldGNoQW5kRGlzcGF0Y2hcclxuXHJcbiIsImltcG9ydCB7IGNyZWF0ZVN0b3JlIH0gZnJvbSBcInJlZHV4XCI7XHJcblxyXG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XHJcbiAgRk9PRFM6IFtdLFxyXG4gIENBVEVHT1JJRVM6W10sXHJcbiAgT1JERVJTOltdLFxyXG4gIEVESVRfUFJPUFM6e30sXHJcbiAgREVMRVRFX1BST1BTOnt9LFxyXG4gIFZJRVdfUFJPUFM6bnVsbCxcclxuXHJcblxyXG5cclxuXHJcbn07XHJcblxyXG5jb25zdCByZWR1Y2VyID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICBjb25zb2xlLmxvZyhhY3Rpb24pO1xyXG5cclxuXHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSAnU0VUX0ZPT0RTJzpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgIEZPT0RTOmFjdGlvbi5GT09EUyAsXHJcbiAgfVxyXG4gIGNhc2UgJ1NFVF9DQVRFR09SSUVTJzpcclxuICAgIHJldHVybiB7XHJcbiAgICAgIC4uLnN0YXRlLFxyXG4gICAgICBDQVRFR09SSUVTOmFjdGlvbi5DQVRFR09SSUVTICxcclxufVxyXG5jYXNlICdTRVRfRURJVF9QUk9QUyc6XHJcbiAgcmV0dXJuIHtcclxuICAgIC4uLnN0YXRlLFxyXG4gICAgRURJVF9QUk9QUzphY3Rpb24uRURJVF9QUk9QUyxcclxuICB9XHJcblxyXG5cclxuY2FzZSAnU0VUX1ZJRVdfUFJPUFMnOlxyXG4gIGNvbnNvbGUubG9nKFwic2V0XCIpO1xyXG4gIHJldHVybiB7XHJcbiAgICAuLi5zdGF0ZSxcclxuICAgIFZJRVdfUFJPUFM6YWN0aW9uLlZJRVdfUFJPUFMsXHJcbiAgfVxyXG5cclxuICBjYXNlICdTRVRfREVMRVRFX1BST1BTJzpcclxuICAgIHJldHVybiB7XHJcbiAgICAgIC4uLnN0YXRlLFxyXG4gICAgICBERUxFVEVfUFJPUFM6YWN0aW9uLkRFTEVURV9QUk9QUyxcclxuICAgIH1cclxuICBjYXNlICdTRVRfT1JERVJTJzpcclxuICAgIHJldHVybiB7XHJcbiAgICAgIC4uLnN0YXRlLFxyXG4gICAgICBPUkRFUlM6YWN0aW9uLk9SREVSUyxcclxuICAgIH1cclxuICBcclxuICAgICAgXHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICB9O1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJlZHVjZXI7XHJcbmV4cG9ydCBjb25zdCBzdG9yZSA9IGNyZWF0ZVN0b3JlKHJlZHVjZXIpO1xyXG4iLCJleHBvcnQgY29uc3QgY2F0ZWdvcmllcyA9IFtcclxuIFxyXG5cclxuICB7XHJcbiAgICBpZDoxLFxyXG4gICAgdGl0bGU6IFwiQW1lcmljYW4gU3R5bGUgUGl6emFcIixcclxuICAgIHVybDogXCJodHRwczovL3d3dy50ZWFodWIuaW8vcGhvdG9zL2Z1bGwvMjMtMjMyNjEyX2xhcmdlLXBpenphLXdhbGxwYXBlci1zcmMtbGFyZ2UtcGl6emEtd2FsbHBhcGVyLXBpenphLmpwZ1wiLFxyXG4gICAgZGVzY3JpcHRpb246XCJUaGlzIGl0ZW0gaXMgbWFkZSBpbiBHZXJtYW55XCIsXHJcbiAgICB2YXJpYW50czpcclxuICAgIFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOjEsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDFcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOjIsXHJcbiAgICAgIHRpdGxlOlwidmFyaWFudDJcIixcclxuICAgIH0sXHJcblxyXG4gIF0sXHJcbiAgXHJcbiAgICBzaXplOidsZydcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOjIsXHJcbiAgICB0aXRsZTogXCJDYWx6b25lXCIsXHJcbiAgICB1cmw6IFwiaHR0cHM6Ly90aHVtYnMuZHJlYW1zdGltZS5jb20vYi9pdGFsaWFuLWZvb2QtY2xvc2VkLXBpenphLWNhbHpvbmUtc3BpbmFjaC1jaGVlc2Utd29vZGVuLWJhY2tncm91bmQtY29weS1zcGFjZS1jYWx6b25lLXNwaW5hY2gtY2hlZXNlLTEwNzcyOTI1MS5qcGdcIixcclxuICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBpdGVtIGlzIG1hZGUgaW4gR2VybWFueVwiLFxyXG4gICAgdmFyaWFudHM6W3tcclxuICAgICAgaWQ6MSxcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6MixcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MlwiLFxyXG4gICAgfSxcclxuXHJcbiAgXSxcclxuICBcclxuICAgIHNpemU6J2xnJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6MyxcclxuICAgIHRpdGxlOiBcIkdlbXVzZWdlcmljaHRlXCIsXHJcbiAgICB1cmw6IFwiaHR0cHM6Ly9jZG4ucGl4YWJheS5jb20vcGhvdG8vMjAxNi8wMi8xOS8xMC8wMC9mb29kLTEyMDkwMDdfOTYwXzcyMC5qcGdcIixcclxuICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBpdGVtIGlzIG1hZGUgaW4gR2VybWFueVwiLFxyXG4gICAgdmFyaWFudHM6W3tcclxuICAgICAgaWQ6MSxcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6MixcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MlwiLFxyXG4gICAgfSxcclxuXHJcbiAgXSxcclxuICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDo0LFxyXG4gICAgdGl0bGU6IFwiQnJvdCAgJiBCcm90Y2hlblwiLFxyXG4gICAgdXJsOlwiaHR0cHM6Ly9zdC5kZXBvc2l0cGhvdG9zLmNvbS8yMjI2NTMyLzMwMzQvaS85NTAvZGVwb3NpdHBob3Rvc18zMDM0NTM5NS1zdG9jay1waG90by1icm90LXVuZC1icnRjaGVuLmpwZ1wiLFxyXG4gICAgZGVzY3JpcHRpb246XCJUaGlzIGl0ZW0gaXMgbWFkZSBpbiBHZXJtYW55XCIsXHJcbiAgICB2YXJpYW50czpbe1xyXG4gICAgICB0aXRsZTpcInZhcmlhbnQxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDoxLFxyXG4gICAgICB0aXRsZTpcInZhcmlhbnQyXCIsXHJcbiAgICB9LFxyXG5cclxuICBdLFxyXG4gIFxyXG4gICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICBcclxuXHJcbl07XHJcbiIsImV4cG9ydCBjb25zdCBmb29kc0FycmF5PVtcclxuICAgIHtcclxuICAgICAgICBpZDoxLFxyXG4gICAgICAgIHRpdGxlOlwiUGl6emEgRmFtaWxpYVwiLFxyXG4gICAgICAgIHVybDpcImh0dHBzOi8vbWVkaWEtY2RuLnRyaXBhZHZpc29yLmNvbS9tZWRpYS9waG90by1zLzExLzQ5L2I0LzU2L3Bob3RvMGpwZy5qcGdcIixcclxuXHJcbiAgICAgICAgc2l6ZTpcInNtXCIsXHJcbiAgICAgICAgY2F0ZWdvcnk6XCJBbmdlYm90XCIsXHJcbiAgICAgICAgcHJpY2U6XCI0M1wiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBGb29kIElzIEdlcm1hblwiLFxyXG4gICAgICAgIGFsbGVyZ2llczpcImEsZSxyLHRcIixcclxuXHJcbiAgICAgICAgRXh0cmFzOltcclxue1xyXG4gbmFtZTpcImxpdGVyIENvY2EgQ29sYVwiLFxyXG4gcXVhbnRpdHk6MVxyXG59LFxyXG57XHJcbm5hbWU6XCJtaW5pIEZyaWVzXCIsXHJcbnF1YW50aXR5OjIsXHJcbn0sXHJcblxyXG5dLFxyXG5cclxufSxcclxuICAgIHtcclxuICAgICAgICBpZDoyLFxyXG4gICAgICAgIHRpdGxlOlwiRmxhbUt1Y2hlblwiLFxyXG4gICAgICAgIHVybDpcImh0dHBzOi8vdXBsb2FkLndpa2ltZWRpYS5vcmcvd2lraXBlZGlhL2NvbW1vbnMvdGh1bWIvZC9kZi9GbGFtZXVrZXVzY2hlXzIuanBnLzM3NXB4LUZsYW1ldWtldXNjaGVfMi5qcGdcIixcclxuICAgICAgICBwcmljZTpcIjIzXCIsXHJcbiAgICAgIFxyXG4gICAgICAgIGNhdGVnb3J5OlwiQW1lcmljYW4gUGl6emFcIixcclxuICAgICAgICB1cmw6XCJodHRwczovL3VwbG9hZC53aWtpbWVkaWEub3JnL3dpa2lwZWRpYS9jb21tb25zL3RodW1iL2QvZGYvRmxhbWV1a2V1c2NoZV8yLmpwZy8zNzVweC1GbGFtZXVrZXVzY2hlXzIuanBnXCIsXHJcblxyXG4gICAgICAgIGRlc2NyaXB0aW9uOlwiVGhpcyBGb29kIElzIEdlcm1hblwiLFxyXG4gICAgICAgIGFsbGVyZ2llczpcImEsZSxyLHRcIixcclxuICAgICAgICBcclxuICAgICAgICBFeHRyYXM6W10sXHJcblxyXG5cclxuICAgIH0sXHJcblxyXG4gICAge1xyXG4gICAgICAgIGlkOjMsXHJcbiAgICAgICAgdGl0bGU6XCJHYXp6b1wiLFxyXG4gICAgICAgIHNpemU6XCJ4bGdcIixcclxuICAgICAgICBjYXRlZ29yeTpcIlBpenphXCIsXHJcbiAgICAgICAgdXJsOlwiaHR0cHM6Ly9wcm9kLXdvbHQtdmVudWUtaW1hZ2VzLWNkbi53b2x0LmNvbS81ZjkxNDMzNGU4YmQ4OWZjNjVlYjQ2NDcvNTM2MzAzMDQtMTdiMS0xMWViLTkyMjktM2U5ZmY4NWRlZGMyX3BpenphX25vXzhfMi5qcGdcIixcclxuXHJcbiAgICAgICAgcHJpY2U6XCIxNDQxXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246XCJUaGlzIEZvb2QgSXMgR2VybWFuXCIsXHJcbiAgICAgICAgYWxsZXJnaWVzOlwiYSxlLHIsdFwiLFxyXG4gICAgICAgIFxyXG4gICAgICAgIEV4dHJhczpbXSxcclxuXHJcblxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBpZDo0LFxyXG4gICAgICAgIHRpdGxlOlwiTWFyZ2hlcml0YVwiLFxyXG4gICAgICAgIFxyXG4gICAgICAgIHNpemU6XCJtZFwiLFxyXG4gICAgICAgIGNhdGVnb3J5OlwiUGl6emFcIixcclxuICAgICAgICBwcmljZTpcIjY1XCIsXHJcbiAgICAgICAgdXJsOlwiaHR0cHM6Ly9pLnBpbmltZy5jb20vb3JpZ2luYWxzLzdkLzRjL2VhLzdkNGNlYTk5ZDczZDJlYTgyNTQ5ZGUwZWE0YjgwMTk4LmpwZ1wiLFxyXG5cclxuICAgICAgICBkZXNjcmlwdGlvbjpcIlRoaXMgRm9vZCBJcyBHZXJtYW5cIixcclxuICAgICAgICBhbGxlcmdpZXM6XCJhLGUscix0XCIsXHJcbiAgICAgICAgXHJcbiAgICAgICAgRXh0cmFzOltdLFxyXG5cclxuXHJcbiAgICB9LFxyXG4gICAgXHJcbl1cclxuXHJcblxyXG4iLCJleHBvcnQgY29uc3Qgb3JkZXJzRGF0YSA9IFtcclxuICB7XHJcbiAgICBpZDogMSxcclxuICAgIHRpbWU6IFwiMTIgTm92IDIwMjEgMzozNFBtXCIsXHJcbiAgICBwYXltZW50TW9kZTogXCJQYXlQYWxcIixcclxuICAgIHBheW1lbnRJZDogXCJzYW4tcmVtby1kaDJnM2gyMTMyMWYzXCIsXHJcbiAgICBwaG9uZTogXCIrMSg3ODQyKS02NTMyXCIsXHJcbiAgICBuYW1lOiBcIkFybm9sZCBKZW1zXCIsXHJcbiAgICBhZHJlc3M6IFwiNDUgT3JlZ29uIFN0cmVldCBMb3MgQW5nZWxzXCIsXHJcblxyXG4gICAgaXRlbXM6IFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIHRpdGxlOiBcIlBpenphIEZhbWlsaWFcIixcclxuICAgICAgICB1cmw6IFwiaHR0cHM6Ly9pbWdzLm1pOS5jb20vdXBsb2Fkcy9vdGhlci80NjEzL3BpenphLWZyZWUtd2FsbHBhcGVyXzE5MjB4MTIwMF84MjE1Ny5qcGdcIixcclxuICAgICAgICBwcmljZTogNDUsXHJcbiAgICAgICAgcXVhbnRpdHk6IDIsXHJcbiAgICAgICAgY2F0ZWdvcnk6IFwiUGl6emFcIixcclxuXHJcbiAgICAgICAgRXh0cmFzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6IFwibGl0ZXIgQ29jYSBDb2xhXCIsXHJcbiAgICAgICAgICAgIHF1YW50aXR5OiAxLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbmFtZTogXCJtaW5pIEZyaWVzXCIsXHJcbiAgICAgICAgICAgIHF1YW50aXR5OiAyLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG5cclxuICAgICAge1xyXG4gICAgICAgIGlkOiAyLFxyXG4gICAgICAgIHRpdGxlOiBcIkZsYW1LdWNoZW5cIixcclxuICAgICAgICB1cmw6IFwiaHR0cHM6Ly91cGxvYWQud2lraW1lZGlhLm9yZy93aWtpcGVkaWEvY29tbW9ucy90aHVtYi9kL2RmL0ZsYW1ldWtldXNjaGVfMi5qcGcvMzc1cHgtRmxhbWV1a2V1c2NoZV8yLmpwZ1wiLFxyXG4gICAgICAgIHByaWNlOiAyMyxcclxuICAgICAgICBxdWFudGl0eTogNCxcclxuICAgICAgICBjYXRlZ29yeTogXCJBbWVyaWNhbiBQaXp6YVwiLFxyXG4gICAgICAgIEV4dHJhczogW10sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgdHlwZTogXCJwaWNrLXVwXCIsXHJcbiAgICBzdGF0dXM6IFwicGVuZGluZ1wiLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IDIsXHJcbiAgICB0aW1lOiBcIjE0IGRlYyAyMDIxIDM6MzRQbVwiLFxyXG4gICAgcGF5bWVudE1vZGU6IFwiUmF5em9yXCIsXHJcbiAgICBwYXltZW50SWQ6IFwic2FuLXJlbW8tZGgyZzNoMjEzMjF3ZXJcIixcclxuICAgIHBob25lOiBcIisxKDM0MiktMzQ1MzJcIixcclxuICAgIG5hbWU6IFwiSmVzc2NhXCIsXHJcbiAgICBhZHJlc3M6IFwiMjQgVC1CbG9jayBXZXN0IENvc3QgQXNpYVwiLFxyXG5cclxuICAgIGl0ZW1zOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICB0aXRsZTogXCJQaXp6YSBGYW1pbGlhXCIsXHJcbiAgICAgICAgdXJsOiBcImh0dHBzOi8vaW1ncy5taTkuY29tL3VwbG9hZHMvb3RoZXIvNDYxMy9waXp6YS1mcmVlLXdhbGxwYXBlcl8xOTIweDEyMDBfODIxNTcuanBnXCIsXHJcbiAgICAgICAgcHJpY2U6IDQ1LFxyXG4gICAgICAgIHF1YW50aXR5OiA1LFxyXG4gICAgICAgIGNhdGVnb3J5OiBcIkFtZXJpY2FuIEZhLGlsaWEgIFBpenphXCIsXHJcbiAgICAgICAgRXh0cmFzOiBbXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG5hbWU6IFwibGl0ZXIgQ29jYSBDb2xhXCIsXHJcbiAgICAgICAgICAgIHF1YW50aXR5OiAxLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgbmFtZTogXCJtaW5pIEZyaWVzXCIsXHJcbiAgICAgICAgICAgIHF1YW50aXR5OiAyLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICAgIHR5cGU6IFwicGljay11cFwiLFxyXG4gICAgc3RhdHVzOiBcInBlbmRpbmdcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAzLFxyXG4gICAgdGltZTogXCIxNCBkZWMgMjAyMSAzOjM0UG1cIixcclxuICAgIHBheW1lbnRNb2RlOiBcIlJheXpvclwiLFxyXG4gICAgcGF5bWVudElkOiBcInNhbi1yZW1vLWRoMmczaDIxMzIxd2VyXCIsXHJcbiAgICBwaG9uZTogXCIrMSg0NTQzMiktMzQ1MzJcIixcclxuICAgIG5hbWU6IFwiQWxpc2FcIixcclxuICAgIGFkcmVzczogXCIxMyBMaW5raW4gUGFyayBTdHJlZXQgVVNBXCIsXHJcblxyXG4gICAgaXRlbXM6IFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIHRpdGxlOiBcIkNhbWlsaW9uIEZhbWlsaWFcIixcclxuICAgICAgICB1cmw6IFwiaHR0cHM6Ly9pbWdzLm1pOS5jb20vdXBsb2Fkcy9vdGhlci80NjEzL3BpenphLWZyZWUtd2FsbHBhcGVyXzE5MjB4MTIwMF84MjE1Ny5qcGdcIixcclxuICAgICAgICBwcmljZTogNDUsXHJcbiAgICAgICAgcXVhbnRpdHk6IDUzLFxyXG4gICAgICAgIGNhdGVnb3J5OiBcIkNhbWlsaW9uIFBpenphXCIsXHJcbiAgICAgICAgRXh0cmFzOiBbXSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgICB0eXBlOiBcIkNhc2ggT24gRGVsaXZlcnlcIixcclxuICAgIHN0YXR1czogXCJuZXdcIixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiA0LFxyXG4gICAgdGltZTogXCIxNCBkZWMgMjAyMSAzOjM0UG1cIixcclxuICAgIHBheW1lbnRNb2RlOiBcIlJheXpvclwiLFxyXG4gICAgcGF5bWVudElkOiBcInNhbi1yZW1vLWRoMmczaDIxMzIxd2VyXCIsXHJcbiAgICBwaG9uZTogXCIrMSgzNDMyKS0zNDUzMlwiLFxyXG4gICAgbmFtZTogXCJSb2NoZWxsZVwiLFxyXG4gICAgYWRyZXNzOiBcIjEyIERvd25TdHJlZXQgTG9uZG9uXCIsXHJcblxyXG4gICAgaXRlbXM6IFtcclxuICAgICAge1xyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIHRpdGxlOiBcIlBpenphIEZhbWlsaWFcIixcclxuICAgICAgICB1cmw6IFwiaHR0cHM6Ly9pbWdzLm1pOS5jb20vdXBsb2Fkcy9vdGhlci80NjEzL3BpenphLWZyZWUtd2FsbHBhcGVyXzE5MjB4MTIwMF84MjE1Ny5qcGdcIixcclxuICAgICAgICBwcmljZTogNDUsXHJcbiAgICAgICAgcXVhbnRpdHk6IDEwLFxyXG4gICAgICAgIGNhdGVnb3J5OiBcIkFtZXJpY2FuIFBpenphXCIsXHJcbiAgICAgIH0sXHJcblxyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6IDIsXHJcbiAgICAgICAgdGl0bGU6IFwiSHVucmUgUGl6emFcIixcclxuICAgICAgICB1cmw6IFwiaHR0cHM6Ly9pbWdzLm1pOS5jb20vdXBsb2Fkcy9vdGhlci80NjEzL3BpenphLWZyZWUtd2FsbHBhcGVyXzE5MjB4MTIwMF84MjE1Ny5qcGdcIixcclxuICAgICAgICBwcmljZTogNDUsXHJcbiAgICAgICAgcXVhbnRpdHk6IDUsXHJcbiAgICAgICAgY2F0ZWdvcnk6IFwiQW1lcmljYW4gRmEsaWxpYSAgUGl6emFcIixcclxuICAgICAgfSxcclxuICAgIF0sXHJcblxyXG4gICAgdHlwZTogXCJwaWNrLXVwXCIsXHJcbiAgICBzdGF0dXM6IFwiY29tcGxldGVkXCIsXHJcbiAgfSxcclxuXTtcclxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG4vLyByZWFjdHN0cmFwIGNvbXBvbmVudHNcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tIFwicmVhY3RzdHJhcFwiO1xuXG4vLyBjb3JlIGNvbXBvbmVudHNcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUGFnZUNoYW5nZShwcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtdHJhbnNpdGlvbi13cmFwcGVyLWRpdlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtdHJhbnNpdGlvbi1pY29uLXdyYXBwZXIgbWItM1wiPlxuICAgICAgICAgIDxTcGlubmVyXG4gICAgICAgICAgICBjb2xvcj1cIndoaXRlXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjZyZW1cIiwgaGVpZ2h0OiBcIjZyZW1cIiwgYm9yZGVyV2lkdGg6IFwiLjNyZW1cIiB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGl0bGUgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgIExvYWRpbmdcbiAgICAgICAgPC9oND5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufVxuIiwiZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICBcImRlZmF1bHRcIjogb2JqXG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdDsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9wYWdlcy9fYXBwJylcbiIsImltcG9ydCBSZWFjdCwgeyBFcnJvckluZm8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIGV4ZWNPbmNlLFxuICBsb2FkR2V0SW5pdGlhbFByb3BzLFxuICBBcHBDb250ZXh0VHlwZSxcbiAgQXBwSW5pdGlhbFByb3BzLFxuICBBcHBQcm9wc1R5cGUsXG4gIE5leHRXZWJWaXRhbHNNZXRyaWMsXG59IGZyb20gJy4uL25leHQtc2VydmVyL2xpYi91dGlscydcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJy4uL2NsaWVudC9yb3V0ZXInXG5cbmV4cG9ydCB7IEFwcEluaXRpYWxQcm9wcyB9XG5cbmV4cG9ydCB7IE5leHRXZWJWaXRhbHNNZXRyaWMgfVxuXG5leHBvcnQgdHlwZSBBcHBDb250ZXh0ID0gQXBwQ29udGV4dFR5cGU8Um91dGVyPlxuXG5leHBvcnQgdHlwZSBBcHBQcm9wczxQID0ge30+ID0gQXBwUHJvcHNUeXBlPFJvdXRlciwgUD5cblxuLyoqXG4gKiBgQXBwYCBjb21wb25lbnQgaXMgdXNlZCBmb3IgaW5pdGlhbGl6ZSBvZiBwYWdlcy4gSXQgYWxsb3dzIGZvciBvdmVyd3JpdGluZyBhbmQgZnVsbCBjb250cm9sIG9mIHRoZSBgcGFnZWAgaW5pdGlhbGl6YXRpb24uXG4gKiBUaGlzIGFsbG93cyBmb3Iga2VlcGluZyBzdGF0ZSBiZXR3ZWVuIG5hdmlnYXRpb24sIGN1c3RvbSBlcnJvciBoYW5kbGluZywgaW5qZWN0aW5nIGFkZGl0aW9uYWwgZGF0YS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gYXBwR2V0SW5pdGlhbFByb3BzKHtcbiAgQ29tcG9uZW50LFxuICBjdHgsXG59OiBBcHBDb250ZXh0KTogUHJvbWlzZTxBcHBJbml0aWFsUHJvcHM+IHtcbiAgY29uc3QgcGFnZVByb3BzID0gYXdhaXQgbG9hZEdldEluaXRpYWxQcm9wcyhDb21wb25lbnQsIGN0eClcbiAgcmV0dXJuIHsgcGFnZVByb3BzIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQXBwPFAgPSB7fSwgQ1AgPSB7fSwgUyA9IHt9PiBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDxcbiAgUCAmIEFwcFByb3BzPENQPixcbiAgU1xuPiB7XG4gIHN0YXRpYyBvcmlnR2V0SW5pdGlhbFByb3BzID0gYXBwR2V0SW5pdGlhbFByb3BzXG4gIHN0YXRpYyBnZXRJbml0aWFsUHJvcHMgPSBhcHBHZXRJbml0aWFsUHJvcHNcblxuICAvLyBLZXB0IGhlcmUgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuICAvLyBXaGVuIHNvbWVvbmUgZW5kZWQgQXBwIHRoZXkgY291bGQgY2FsbCBgc3VwZXIuY29tcG9uZW50RGlkQ2F0Y2hgLlxuICAvLyBAZGVwcmVjYXRlZCBUaGlzIG1ldGhvZCBpcyBubyBsb25nZXIgbmVlZGVkLiBFcnJvcnMgYXJlIGNhdWdodCBhdCB0aGUgdG9wIGxldmVsXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yOiBFcnJvciwgX2Vycm9ySW5mbzogRXJyb3JJbmZvKTogdm9pZCB7XG4gICAgdGhyb3cgZXJyb3JcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHJvdXRlciwgQ29tcG9uZW50LCBwYWdlUHJvcHMsIF9fTl9TU0csIF9fTl9TU1AgfSA9IHRoaXNcbiAgICAgIC5wcm9wcyBhcyBBcHBQcm9wczxDUD5cblxuICAgIHJldHVybiAoXG4gICAgICA8Q29tcG9uZW50XG4gICAgICAgIHsuLi5wYWdlUHJvcHN9XG4gICAgICAgIHtcbiAgICAgICAgICAvLyB3ZSBkb24ndCBhZGQgdGhlIGxlZ2FjeSBVUkwgcHJvcCBpZiBpdCdzIHVzaW5nIG5vbi1sZWdhY3lcbiAgICAgICAgICAvLyBtZXRob2RzIGxpa2UgZ2V0U3RhdGljUHJvcHMgYW5kIGdldFNlcnZlclNpZGVQcm9wc1xuICAgICAgICAgIC4uLighKF9fTl9TU0cgfHwgX19OX1NTUCkgPyB7IHVybDogY3JlYXRlVXJsKHJvdXRlcikgfSA6IHt9KVxuICAgICAgICB9XG4gICAgICAvPlxuICAgIClcbiAgfVxufVxuXG5sZXQgd2FybkNvbnRhaW5lcjogKCkgPT4gdm9pZFxubGV0IHdhcm5Vcmw6ICgpID0+IHZvaWRcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgd2FybkNvbnRhaW5lciA9IGV4ZWNPbmNlKCgpID0+IHtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBgV2FybmluZzogdGhlIFxcYENvbnRhaW5lclxcYCBpbiBcXGBfYXBwXFxgIGhhcyBiZWVuIGRlcHJlY2F0ZWQgYW5kIHNob3VsZCBiZSByZW1vdmVkLiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9hcHAtY29udGFpbmVyLWRlcHJlY2F0ZWRgXG4gICAgKVxuICB9KVxuXG4gIHdhcm5VcmwgPSBleGVjT25jZSgoKSA9PiB7XG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIGBXYXJuaW5nOiB0aGUgJ3VybCcgcHJvcGVydHkgaXMgZGVwcmVjYXRlZC4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvdXJsLWRlcHJlY2F0ZWRgXG4gICAgKVxuICB9KVxufVxuXG4vLyBAZGVwcmVjYXRlZCBub29wIGZvciBub3cgdW50aWwgcmVtb3ZhbFxuZXhwb3J0IGZ1bmN0aW9uIENvbnRhaW5lcihwOiBhbnkpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5Db250YWluZXIoKVxuICByZXR1cm4gcC5jaGlsZHJlblxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVXJsKHJvdXRlcjogUm91dGVyKSB7XG4gIC8vIFRoaXMgaXMgdG8gbWFrZSBzdXJlIHdlIGRvbid0IHJlZmVyZW5jZXMgdGhlIHJvdXRlciBvYmplY3QgYXQgY2FsbCB0aW1lXG4gIGNvbnN0IHsgcGF0aG5hbWUsIGFzUGF0aCwgcXVlcnkgfSA9IHJvdXRlclxuICByZXR1cm4ge1xuICAgIGdldCBxdWVyeSgpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiBxdWVyeVxuICAgIH0sXG4gICAgZ2V0IHBhdGhuYW1lKCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHBhdGhuYW1lXG4gICAgfSxcbiAgICBnZXQgYXNQYXRoKCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIGFzUGF0aFxuICAgIH0sXG4gICAgYmFjazogKCkgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcm91dGVyLmJhY2soKVxuICAgIH0sXG4gICAgcHVzaDogKHVybDogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHJvdXRlci5wdXNoKHVybCwgYXMpXG4gICAgfSxcbiAgICBwdXNoVG86IChocmVmOiBzdHJpbmcsIGFzPzogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICBjb25zdCBwdXNoUm91dGUgPSBhcyA/IGhyZWYgOiAnJ1xuICAgICAgY29uc3QgcHVzaFVybCA9IGFzIHx8IGhyZWZcblxuICAgICAgcmV0dXJuIHJvdXRlci5wdXNoKHB1c2hSb3V0ZSwgcHVzaFVybClcbiAgICB9LFxuICAgIHJlcGxhY2U6ICh1cmw6IHN0cmluZywgYXM/OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiByb3V0ZXIucmVwbGFjZSh1cmwsIGFzKVxuICAgIH0sXG4gICAgcmVwbGFjZVRvOiAoaHJlZjogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgY29uc3QgcmVwbGFjZVJvdXRlID0gYXMgPyBocmVmIDogJydcbiAgICAgIGNvbnN0IHJlcGxhY2VVcmwgPSBhcyB8fCBocmVmXG5cbiAgICAgIHJldHVybiByb3V0ZXIucmVwbGFjZShyZXBsYWNlUm91dGUsIHJlcGxhY2VVcmwpXG4gICAgfSxcbiAgfVxufVxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb21cIjtcbmltcG9ydCBBcHAgZnJvbSBcIm5leHQvYXBwXCI7XG5pbXBvcnQgSGVhZCBmcm9tIFwibmV4dC9oZWFkXCI7XG5pbXBvcnQgUm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tIFwicmVhY3QtcmVkdXhcIjtcbmltcG9ydCB7IGNyZWF0ZVN0b3JlIH0gZnJvbSBcInJlZHV4XCI7XG5pbXBvcnQgUGFnZUNoYW5nZSBmcm9tIFwiY29tcG9uZW50cy9QYWdlQ2hhbmdlL1BhZ2VDaGFuZ2UuanNcIjtcbmltcG9ydCByZWR1Y2VyIGZyb20gXCIuLi9SZWR1Y2Vycy9yZWR1Y2VyXCI7XG5pbXBvcnQgXCJhc3NldHMvcGx1Z2lucy9udWNsZW8vY3NzL251Y2xlby5jc3NcIjtcbmltcG9ydCBcIkBmb3J0YXdlc29tZS9mb250YXdlc29tZS1mcmVlL2Nzcy9hbGwubWluLmNzc1wiO1xuaW1wb3J0IFwiYXNzZXRzL3Njc3MvbmV4dGpzLWFyZ29uLWRhc2hib2FyZC5zY3NzXCI7XG5pbXBvcnQge3N0b3JlfSBmcm9tIFwiLi4vUmVkdWNlcnMvcmVkdWNlclwiO1xuaW1wb3J0IEZldGNoQW5kRGlzcGF0Y2ggZnJvbSBcIi4uL0FQSV9XT1JLL2ZldGNoQW5kRGlzcGF0Y2hcIjtcblxuXG5cblJvdXRlci5ldmVudHMub24oXCJyb3V0ZUNoYW5nZVN0YXJ0XCIsICh1cmwpID0+IHtcbiAgY29uc29sZS5sb2coYExvYWRpbmc6ICR7dXJsfWApO1xuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC5hZGQoXCJib2R5LXBhZ2UtdHJhbnNpdGlvblwiKTtcbiAgUmVhY3RET00ucmVuZGVyKFxuICAgIDxQYWdlQ2hhbmdlIHBhdGg9e3VybH0gLz4sXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwYWdlLXRyYW5zaXRpb25cIilcbiAgKTtcbn0pO1xuUm91dGVyLmV2ZW50cy5vbihcInJvdXRlQ2hhbmdlQ29tcGxldGVcIiwgKCkgPT4ge1xuICBSZWFjdERPTS51bm1vdW50Q29tcG9uZW50QXROb2RlKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGFnZS10cmFuc2l0aW9uXCIpKTtcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiYm9keS1wYWdlLXRyYW5zaXRpb25cIik7XG59KTtcblJvdXRlci5ldmVudHMub24oXCJyb3V0ZUNoYW5nZUVycm9yXCIsICgpID0+IHtcbiAgUmVhY3RET00udW5tb3VudENvbXBvbmVudEF0Tm9kZShkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBhZ2UtdHJhbnNpdGlvblwiKSk7XG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnJlbW92ZShcImJvZHktcGFnZS10cmFuc2l0aW9uXCIpO1xufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15QXBwIGV4dGVuZHMgQXBwIHtcblxuICBjb21wb25lbnREaWRNb3VudCgpIHtcbiAgICBcbiAgICBsZXQgY29tbWVudCA9IGRvY3VtZW50LmNyZWF0ZUNvbW1lbnQoYFxuXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiogKiBOZXh0SlMgQXJnb24gRGFzaGJvYXJkIHYxLjEuMCBiYXNlZCBvbiBBcmdvbiBEYXNoYm9hcmQgUmVhY3QgdjEuMS4wXG49PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuKiBQcm9kdWN0IFBhZ2U6IGh0dHBzOi8vd3d3LmNyZWF0aXZlLXRpbS5jb20vcHJvZHVjdC9uZXh0anMtYXJnb24tZGFzaGJvYXJkXG4qIENvcHlyaWdodCAyMDIxIENyZWF0aXZlIFRpbSAoaHR0cHM6Ly93d3cuY3JlYXRpdmUtdGltLmNvbSlcbiogTGljZW5zZWQgdW5kZXIgTUlUIChodHRwczovL2dpdGh1Yi5jb20vY3JlYXRpdmV0aW1vZmZpY2lhbC9uZXh0anMtYXJnb24tZGFzaGJvYXJkL2Jsb2IvbWFzdGVyL0xJQ0VOU0UubWQpXG5cbiogQ29kZWQgYnkgQ3JlYXRpdmUgVGltXG5cbj09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG4qIFRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlIGFuZCB0aGlzIHBlcm1pc3Npb24gbm90aWNlIHNoYWxsIGJlIGluY2x1ZGVkIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuXG5gKTtcbiAgICBkb2N1bWVudC5pbnNlcnRCZWZvcmUoY29tbWVudCwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KTtcbiAgfVxuICBzdGF0aWMgYXN5bmMgZ2V0SW5pdGlhbFByb3BzKHsgQ29tcG9uZW50LCByb3V0ZXIsIGN0eCB9KSB7XG4gICAgbGV0IHBhZ2VQcm9wcyA9IHt9O1xuXG4gICAgaWYgKENvbXBvbmVudC5nZXRJbml0aWFsUHJvcHMpIHtcbiAgICAgIHBhZ2VQcm9wcyA9IGF3YWl0IENvbXBvbmVudC5nZXRJbml0aWFsUHJvcHMoY3R4KTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBwYWdlUHJvcHMgfTtcbiAgfVxuXG5cblxuICByZW5kZXIoKSB7XG4gICAgXG4gICAgXG4gICAgY29uc3QgeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9ID0gdGhpcy5wcm9wcztcblxuICAgIGNvbnN0IExheW91dCA9IENvbXBvbmVudC5sYXlvdXQgfHwgKCh7IGNoaWxkcmVuIH0pID0+IDw+e2NoaWxkcmVufTwvPik7XG5cbiAgICByZXR1cm4gKFxuICAgICAgPFJlYWN0LkZyYWdtZW50PlxuICAgICAgICA8SGVhZD5cbiAgICAgICAgICA8bWV0YVxuICAgICAgICAgICAgbmFtZT1cInZpZXdwb3J0XCJcbiAgICAgICAgICAgIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MSwgc2hyaW5rLXRvLWZpdD1ub1wiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8dGl0bGU+U2FuIFJlbW8gQWRtaW4gUGFuZWw8L3RpdGxlPlxuICAgICAgICAgIDxzY3JpcHQgc3JjPVwiaHR0cHM6Ly9tYXBzLmdvb2dsZWFwaXMuY29tL21hcHMvYXBpL2pzP2tleT1ZT1VSX0tFWV9IRVJFXCI+PC9zY3JpcHQ+XG4gICAgICAgIDwvSGVhZD5cbiAgICAgICAgPExheW91dD5cbiAgICAgICAgICA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfSA+XG4gICAgICAgICAgPEZldGNoQW5kRGlzcGF0Y2ggLz5cbiAgICAgICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgICAgICAgXG4gICAgICAgICAgPC9Qcm92aWRlcj5cblxuICAgICAgICA8L0xheW91dD5cbiAgICAgIDwvUmVhY3QuRnJhZ21lbnQ+XG4gICAgKTtcbiAgfVxufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9oZWFkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWRvbVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RzdHJhcFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eFwiKTsiXSwic291cmNlUm9vdCI6IiJ9