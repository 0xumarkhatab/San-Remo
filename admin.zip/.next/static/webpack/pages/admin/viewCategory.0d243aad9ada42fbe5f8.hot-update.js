webpackHotUpdate_N_E("pages/admin/viewCategory",{

/***/ "./pages/admin/viewCategory.js":
/*!*************************************!*\
  !*** ./pages/admin/viewCategory.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layouts_Admin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../layouts/Admin */ "./layouts/Admin.js");
/* harmony import */ var _components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/Headers/SimpleHeader */ "./components/Headers/SimpleHeader.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/es/index.js");
/* harmony import */ var _assets_css_nextjs_argon_dashboard_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/css/nextjs-argon-dashboard.css */ "./assets/css/nextjs-argon-dashboard.css");
/* harmony import */ var _assets_css_nextjs_argon_dashboard_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_assets_css_nextjs_argon_dashboard_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "E:\\admin\\pages\\admin\\viewCategory.js",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(E_admin_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }







function viewCategory() {
  _s();

  var _this = this;

  var item = Object(react_redux__WEBPACK_IMPORTED_MODULE_5__["useSelector"])(function (state) {
    return state.VIEW_PROPS;
  });
  item = _objectSpread({}, item);
  console.log(item);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Headers_SimpleHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "item_img ml- mt-2",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: item.url,
        alt: item.title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("b", {
          className: "text-white",
          children: item.title
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
          className: "text-white",
          children: item.description
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "d-flex justify-center",
          children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": " mt-2 fas fa-arrow-circle-right"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "ml-2 ",
            children: " "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 13
          }, this), item.variants.map(function (v, index) {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              children: [v.title, " ", index + 1 === item.variants.length ? "" : ",", " "]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 17
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "d-flex",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": "mt-1 fas fa-star"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": "mt-1 fas fa-star"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": "mt-1 fas fa-star"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": "mt-1 fas fa-star"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 36,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("i", {
            "class": "mt-1 fas fa-star-half-alt"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 13
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "ml-1",
            children: " 4.5 "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 13
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 5
  }, this);
}

_s(viewCategory, "wOUaN/i/jvCnXlTExIRYqJl7gdY=", false, function () {
  return [react_redux__WEBPACK_IMPORTED_MODULE_5__["useSelector"]];
});

viewCategory.layout = _layouts_Admin__WEBPACK_IMPORTED_MODULE_3__["default"];
/* harmony default export */ __webpack_exports__["default"] = (viewCategory);

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvYWRtaW4vdmlld0NhdGVnb3J5LmpzIl0sIm5hbWVzIjpbInZpZXdDYXRlZ29yeSIsIml0ZW0iLCJ1c2VTZWxlY3RvciIsInN0YXRlIiwiVklFV19QUk9QUyIsImNvbnNvbGUiLCJsb2ciLCJ1cmwiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwidmFyaWFudHMiLCJtYXAiLCJ2IiwiaW5kZXgiLCJsZW5ndGgiLCJsYXlvdXQiLCJBZG1pbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU0EsWUFBVCxHQUF3QjtBQUFBOztBQUFBOztBQUN0QixNQUFJQyxJQUFJLEdBQUdDLCtEQUFXLENBQUMsVUFBQ0MsS0FBRDtBQUFBLFdBQVdBLEtBQUssQ0FBQ0MsVUFBakI7QUFBQSxHQUFELENBQXRCO0FBQ0FILE1BQUkscUJBQVFBLElBQVIsQ0FBSjtBQUNBSSxTQUFPLENBQUNDLEdBQVIsQ0FBWUwsSUFBWjtBQUVBLHNCQUNFO0FBQUEsNEJBQ0UscUVBQUMsd0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURGLGVBRUU7QUFBSyxlQUFTLEVBQUMsbUJBQWY7QUFBQSw4QkFDRTtBQUFLLFdBQUcsRUFBRUEsSUFBSSxDQUFDTSxHQUFmO0FBQW9CLFdBQUcsRUFBRU4sSUFBSSxDQUFDTztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFFRTtBQUFBLGdDQUNFO0FBQUcsbUJBQVMsRUFBQyxZQUFiO0FBQUEsb0JBQTJCUCxJQUFJLENBQUNPO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFFRTtBQUFJLG1CQUFTLEVBQUMsWUFBZDtBQUFBLG9CQUE0QlAsSUFBSSxDQUFDUTtBQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZGLGVBR0U7QUFBRyxtQkFBUyxFQUFDLHVCQUFiO0FBQUEscUJBQ0csR0FESCxlQUVFO0FBQUcscUJBQU07QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLEVBRWtELEdBRmxELGVBR0U7QUFBRyxxQkFBUyxFQUFDLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSEYsRUFJR1IsSUFBSSxDQUFDUyxRQUFMLENBQWNDLEdBQWQsQ0FBa0IsVUFBQ0MsQ0FBRCxFQUFJQyxLQUFKLEVBQWM7QUFDL0IsZ0NBQ0U7QUFBQSx5QkFDR0QsQ0FBQyxDQUFDSixLQURMLE9BQ2FLLEtBQUssR0FBRyxDQUFSLEtBQWNaLElBQUksQ0FBQ1MsUUFBTCxDQUFjSSxNQUE1QixHQUFxQyxFQUFyQyxHQUEwQyxHQUR2RCxFQUM0RCxHQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFLRCxXQU5BLENBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUhGLGVBZUU7QUFBRyxtQkFBUyxFQUFDLFFBQWI7QUFBQSxrQ0FDRTtBQUFHLHFCQUFNO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixlQUVFO0FBQUcscUJBQU07QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZGLGVBR0U7QUFBRyxxQkFBTTtBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSEYsZUFJRTtBQUFHLHFCQUFNO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFKRixlQUtFO0FBQUcscUJBQU07QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUxGLGVBTUU7QUFBRyxxQkFBUyxFQUFDLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQURGO0FBZ0NEOztHQXJDUWQsWTtVQUNJRSx1RDs7O0FBc0NiRixZQUFZLENBQUNlLE1BQWIsR0FBc0JDLHNEQUF0QjtBQUVlaEIsMkVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvYWRtaW4vdmlld0NhdGVnb3J5LjBkMjQzYWFkOWFkYTQyZmJlNWY4LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBBZG1pbiBmcm9tIFwiLi4vLi4vbGF5b3V0cy9BZG1pblwiO1xyXG5pbXBvcnQgU2ltcGxlSGVhZGVyIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0hlYWRlcnMvU2ltcGxlSGVhZGVyXCI7XHJcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBcIi4uLy4uL2Fzc2V0cy9jc3MvbmV4dGpzLWFyZ29uLWRhc2hib2FyZC5jc3NcIjtcclxuXHJcbmZ1bmN0aW9uIHZpZXdDYXRlZ29yeSgpIHtcclxuICBsZXQgaXRlbSA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUuVklFV19QUk9QUyk7XHJcbiAgaXRlbSA9IHsgLi4uaXRlbSB9O1xyXG4gIGNvbnNvbGUubG9nKGl0ZW0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPFNpbXBsZUhlYWRlciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIml0ZW1faW1nIG1sLSBtdC0yXCI+XHJcbiAgICAgICAgPGltZyBzcmM9e2l0ZW0udXJsfSBhbHQ9e2l0ZW0udGl0bGV9IC8+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxiIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj57aXRlbS50aXRsZX08L2I+XHJcbiAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPntpdGVtLmRlc2NyaXB0aW9ufTwvaDQ+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkLWZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAge1wiIFwifVxyXG4gICAgICAgICAgICA8aSBjbGFzcz1cIiBtdC0yIGZhcyBmYS1hcnJvdy1jaXJjbGUtcmlnaHRcIj48L2k+e1wiIFwifVxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtbC0yIFwiPiA8L3A+XHJcbiAgICAgICAgICAgIHtpdGVtLnZhcmlhbnRzLm1hcCgodiwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgIHt2LnRpdGxlfSB7aW5kZXggKyAxID09PSBpdGVtLnZhcmlhbnRzLmxlbmd0aCA/IFwiXCIgOiBcIixcIn17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkLWZsZXhcIj5cclxuICAgICAgICAgICAgPGkgY2xhc3M9XCJtdC0xIGZhcyBmYS1zdGFyXCI+PC9pPlxyXG4gICAgICAgICAgICA8aSBjbGFzcz1cIm10LTEgZmFzIGZhLXN0YXJcIj48L2k+XHJcbiAgICAgICAgICAgIDxpIGNsYXNzPVwibXQtMSBmYXMgZmEtc3RhclwiPjwvaT5cclxuICAgICAgICAgICAgPGkgY2xhc3M9XCJtdC0xIGZhcyBmYS1zdGFyXCI+PC9pPlxyXG4gICAgICAgICAgICA8aSBjbGFzcz1cIm10LTEgZmFzIGZhLXN0YXItaGFsZi1hbHRcIj48L2k+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1sLTFcIj4gNC41IDwvcD5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG52aWV3Q2F0ZWdvcnkubGF5b3V0ID0gQWRtaW47XHJcblxyXG5leHBvcnQgZGVmYXVsdCB2aWV3Q2F0ZWdvcnk7XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=