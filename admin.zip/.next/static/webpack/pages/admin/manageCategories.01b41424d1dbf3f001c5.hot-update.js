webpackHotUpdate_N_E("pages/admin/manageCategories",{

/***/ "./components/Categories/CategoriesData.js":
/*!*************************************************!*\
  !*** ./components/Categories/CategoriesData.js ***!
  \*************************************************/
/*! exports provided: categories */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "categories", function() { return categories; });
var categories = [{
  id: 1,
  title: "American Style Pizza",
  url: "https://www.teahub.io/photos/full/23-232612_large-pizza-wallpaper-src-large-pizza-wallpaper-pizza.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    id: 2,
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 2,
  title: "Calzone",
  url: "https://thumbs.dreamstime.com/b/italian-food-closed-pizza-calzone-spinach-cheese-wooden-background-copy-space-calzone-spinach-cheese-107729251.jpg",
  description: "This item is made in Germany",
  variants: [{
    title: "variant1"
  }, {
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 3,
  title: "Gemusegerichte",
  url: "https://cdn.pixabay.com/photo/2016/02/19/10/00/food-1209007_960_720.jpg",
  description: "This item is made in Germany",
  variants: [{
    id: 1,
    title: "variant1"
  }, {
    title: "variant2"
  }],
  size: 'lg'
}, {
  id: 4,
  title: "Brot  & Brotchen",
  url: "https://st.depositphotos.com/2226532/3034/i/950/depositphotos_30345395-stock-photo-brot-und-brtchen.jpg",
  description: "This item is made in Germany",
  variants: [{
    title: "variant1"
  }, {
    id: 1,
    title: "variant2"
  }],
  size: 'lg'
}];

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9DYXRlZ29yaWVzL0NhdGVnb3JpZXNEYXRhLmpzIl0sIm5hbWVzIjpbImNhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwidXJsIiwiZGVzY3JpcHRpb24iLCJ2YXJpYW50cyIsInNpemUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQU8sSUFBTUEsVUFBVSxHQUFHLENBR3hCO0FBQ0VDLElBQUUsRUFBQyxDQURMO0FBRUVDLE9BQUssRUFBRSxzQkFGVDtBQUdFQyxLQUFHLEVBQUUsdUdBSFA7QUFJRUMsYUFBVyxFQUFDLDhCQUpkO0FBS0VDLFVBQVEsRUFDUixDQUNFO0FBQ0VKLE1BQUUsRUFBQyxDQURMO0FBRUFDLFNBQUssRUFBQztBQUZOLEdBREYsRUFLQTtBQUNFRCxNQUFFLEVBQUMsQ0FETDtBQUVFQyxTQUFLLEVBQUM7QUFGUixHQUxBLENBTkY7QUFrQkVJLE1BQUksRUFBQztBQWxCUCxDQUh3QixFQXVCeEI7QUFDRUwsSUFBRSxFQUFDLENBREw7QUFFRUMsT0FBSyxFQUFFLFNBRlQ7QUFHRUMsS0FBRyxFQUFFLG9KQUhQO0FBSUVDLGFBQVcsRUFBQyw4QkFKZDtBQUtFQyxVQUFRLEVBQUMsQ0FBQztBQUNSSCxTQUFLLEVBQUM7QUFERSxHQUFELEVBR1Q7QUFDRUEsU0FBSyxFQUFDO0FBRFIsR0FIUyxDQUxYO0FBY0VJLE1BQUksRUFBQztBQWRQLENBdkJ3QixFQXVDeEI7QUFDRUwsSUFBRSxFQUFDLENBREw7QUFFRUMsT0FBSyxFQUFFLGdCQUZUO0FBR0VDLEtBQUcsRUFBRSx5RUFIUDtBQUlFQyxhQUFXLEVBQUMsOEJBSmQ7QUFLRUMsVUFBUSxFQUFDLENBQUM7QUFDUkosTUFBRSxFQUFDLENBREs7QUFFUkMsU0FBSyxFQUFDO0FBRkUsR0FBRCxFQUlUO0FBRUVBLFNBQUssRUFBQztBQUZSLEdBSlMsQ0FMWDtBQWVDSSxNQUFJLEVBQUM7QUFmTixDQXZDd0IsRUF3RHhCO0FBQ0VMLElBQUUsRUFBQyxDQURMO0FBRUVDLE9BQUssRUFBRSxrQkFGVDtBQUdFQyxLQUFHLEVBQUMseUdBSE47QUFJRUMsYUFBVyxFQUFDLDhCQUpkO0FBS0VDLFVBQVEsRUFBQyxDQUFDO0FBQ1JILFNBQUssRUFBQztBQURFLEdBQUQsRUFHVDtBQUNFRCxNQUFFLEVBQUMsQ0FETDtBQUVFQyxTQUFLLEVBQUM7QUFGUixHQUhTLENBTFg7QUFlRUksTUFBSSxFQUFDO0FBZlAsQ0F4RHdCLENBQW5CIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2FkbWluL21hbmFnZUNhdGVnb3JpZXMuMDFiNDE0MjRkMWRiZjNmMDAxYzUuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBjYXRlZ29yaWVzID0gW1xyXG4gXHJcblxyXG4gIHtcclxuICAgIGlkOjEsXHJcbiAgICB0aXRsZTogXCJBbWVyaWNhbiBTdHlsZSBQaXp6YVwiLFxyXG4gICAgdXJsOiBcImh0dHBzOi8vd3d3LnRlYWh1Yi5pby9waG90b3MvZnVsbC8yMy0yMzI2MTJfbGFyZ2UtcGl6emEtd2FsbHBhcGVyLXNyYy1sYXJnZS1waXp6YS13YWxscGFwZXItcGl6emEuanBnXCIsXHJcbiAgICBkZXNjcmlwdGlvbjpcIlRoaXMgaXRlbSBpcyBtYWRlIGluIEdlcm1hbnlcIixcclxuICAgIHZhcmlhbnRzOlxyXG4gICAgW1xyXG4gICAgICB7XHJcbiAgICAgICAgaWQ6MSxcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6MixcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MlwiLFxyXG4gICAgfSxcclxuXHJcbiAgXSxcclxuICBcclxuICAgIHNpemU6J2xnJ1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6MixcclxuICAgIHRpdGxlOiBcIkNhbHpvbmVcIixcclxuICAgIHVybDogXCJodHRwczovL3RodW1icy5kcmVhbXN0aW1lLmNvbS9iL2l0YWxpYW4tZm9vZC1jbG9zZWQtcGl6emEtY2Fsem9uZS1zcGluYWNoLWNoZWVzZS13b29kZW4tYmFja2dyb3VuZC1jb3B5LXNwYWNlLWNhbHpvbmUtc3BpbmFjaC1jaGVlc2UtMTA3NzI5MjUxLmpwZ1wiLFxyXG4gICAgZGVzY3JpcHRpb246XCJUaGlzIGl0ZW0gaXMgbWFkZSBpbiBHZXJtYW55XCIsXHJcbiAgICB2YXJpYW50czpbe1xyXG4gICAgICB0aXRsZTpcInZhcmlhbnQxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTpcInZhcmlhbnQyXCIsXHJcbiAgICB9LFxyXG5cclxuICBdLFxyXG4gIFxyXG4gICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDozLFxyXG4gICAgdGl0bGU6IFwiR2VtdXNlZ2VyaWNodGVcIixcclxuICAgIHVybDogXCJodHRwczovL2Nkbi5waXhhYmF5LmNvbS9waG90by8yMDE2LzAyLzE5LzEwLzAwL2Zvb2QtMTIwOTAwN185NjBfNzIwLmpwZ1wiLFxyXG4gICAgZGVzY3JpcHRpb246XCJUaGlzIGl0ZW0gaXMgbWFkZSBpbiBHZXJtYW55XCIsXHJcbiAgICB2YXJpYW50czpbe1xyXG4gICAgICBpZDoxLFxyXG4gICAgICB0aXRsZTpcInZhcmlhbnQxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBcclxuICAgICAgdGl0bGU6XCJ2YXJpYW50MlwiLFxyXG4gICAgfSxcclxuXHJcbiAgXSxcclxuICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDo0LFxyXG4gICAgdGl0bGU6IFwiQnJvdCAgJiBCcm90Y2hlblwiLFxyXG4gICAgdXJsOlwiaHR0cHM6Ly9zdC5kZXBvc2l0cGhvdG9zLmNvbS8yMjI2NTMyLzMwMzQvaS85NTAvZGVwb3NpdHBob3Rvc18zMDM0NTM5NS1zdG9jay1waG90by1icm90LXVuZC1icnRjaGVuLmpwZ1wiLFxyXG4gICAgZGVzY3JpcHRpb246XCJUaGlzIGl0ZW0gaXMgbWFkZSBpbiBHZXJtYW55XCIsXHJcbiAgICB2YXJpYW50czpbe1xyXG4gICAgICB0aXRsZTpcInZhcmlhbnQxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDoxLFxyXG4gICAgICB0aXRsZTpcInZhcmlhbnQyXCIsXHJcbiAgICB9LFxyXG5cclxuICBdLFxyXG4gIFxyXG4gICAgc2l6ZTonbGcnXHJcbiAgfSxcclxuICBcclxuXHJcbl07XHJcbiJdLCJzb3VyY2VSb290IjoiIn0=