webpackHotUpdate_N_E("styles",{

/***/ "./assets/css/nextjs-argon-dashboard.css":
/*!***********************************************!*\
  !*** ./assets/css/nextjs-argon-dashboard.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin;
    if (true) {
      var injectCss = function injectCss(prev, href) {
        var link = prev.cloneNode();
        link.href = href;
        link.onload = function() {
          prev.parentNode.removeChild(prev);
        };
        prev.stale = true;
        prev.parentNode.insertBefore(link, prev);
      };
      module.hot.dispose(function() {
        window.__webpack_reload_css__ = true;
      });
      if (window.__webpack_reload_css__) {
        module.hot.__webpack_reload_css__ = false;
        console.log("[HMR] Reloading stylesheets...");
        var prefix = document.location.protocol + '//' + document.location.host;
        document
          .querySelectorAll("link[href][rel=stylesheet]")
          .forEach(function(link) {
            if (!link.href.match(prefix) || link.stale) return;
            injectCss(link, link.href.split("?")[0] + "?unix=1631286976768");
          });
      }
    }
  

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vYXNzZXRzL2Nzcy9uZXh0anMtYXJnb24tZGFzaGJvYXJkLmNzcz83MDYzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBQ0EsUUFBUSxJQUFVO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0EiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svc3R5bGVzLjcyOTc0YzMyZTAxNjJiNTQ5ZGQ2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW47XG4gICAgaWYgKG1vZHVsZS5ob3QpIHtcbiAgICAgIHZhciBpbmplY3RDc3MgPSBmdW5jdGlvbiBpbmplY3RDc3MocHJldiwgaHJlZikge1xuICAgICAgICB2YXIgbGluayA9IHByZXYuY2xvbmVOb2RlKCk7XG4gICAgICAgIGxpbmsuaHJlZiA9IGhyZWY7XG4gICAgICAgIGxpbmsub25sb2FkID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgcHJldi5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHByZXYpO1xuICAgICAgICB9O1xuICAgICAgICBwcmV2LnN0YWxlID0gdHJ1ZTtcbiAgICAgICAgcHJldi5wYXJlbnROb2RlLmluc2VydEJlZm9yZShsaW5rLCBwcmV2KTtcbiAgICAgIH07XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7XG4gICAgICAgIHdpbmRvdy5fX3dlYnBhY2tfcmVsb2FkX2Nzc19fID0gdHJ1ZTtcbiAgICAgIH0pO1xuICAgICAgaWYgKHdpbmRvdy5fX3dlYnBhY2tfcmVsb2FkX2Nzc19fKSB7XG4gICAgICAgIG1vZHVsZS5ob3QuX193ZWJwYWNrX3JlbG9hZF9jc3NfXyA9IGZhbHNlO1xuICAgICAgICBjb25zb2xlLmxvZyhcIltITVJdIFJlbG9hZGluZyBzdHlsZXNoZWV0cy4uLlwiKTtcbiAgICAgICAgdmFyIHByZWZpeCA9IGRvY3VtZW50LmxvY2F0aW9uLnByb3RvY29sICsgJy8vJyArIGRvY3VtZW50LmxvY2F0aW9uLmhvc3Q7XG4gICAgICAgIGRvY3VtZW50XG4gICAgICAgICAgLnF1ZXJ5U2VsZWN0b3JBbGwoXCJsaW5rW2hyZWZdW3JlbD1zdHlsZXNoZWV0XVwiKVxuICAgICAgICAgIC5mb3JFYWNoKGZ1bmN0aW9uKGxpbmspIHtcbiAgICAgICAgICAgIGlmICghbGluay5ocmVmLm1hdGNoKHByZWZpeCkgfHzCoGxpbmsuc3RhbGUpIHJldHVybjtcbiAgICAgICAgICAgIGluamVjdENzcyhsaW5rLCBsaW5rLmhyZWYuc3BsaXQoXCI/XCIpWzBdICsgXCI/dW5peD0xNjMxMjg2OTc2NzY4XCIpO1xuICAgICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgIl0sInNvdXJjZVJvb3QiOiIifQ==