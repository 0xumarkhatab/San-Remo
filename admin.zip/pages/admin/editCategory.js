import React from 'react'
import {useSelector} from "react-redux";
import AddCategory from './AddCategory';

function editCategory() {

const item=useSelector(state=>state.EDIT_PROPS);
console.table(item);

    return (
        <div>
            <AddCategory item={item} />
        </div>
    )
}

export default editCategory
