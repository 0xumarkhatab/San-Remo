import React from 'react'

function deleteCategory() {
    return (
        <div>
            delete Category
        </div>
    )
}

export default deleteCategory
