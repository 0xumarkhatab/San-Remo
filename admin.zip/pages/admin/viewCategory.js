import React from "react";
import Admin from "../../layouts/Admin";
import SimpleHeader from "../../components/Headers/SimpleHeader";
import { useSelector } from "react-redux";
import "../../assets/css/nextjs-argon-dashboard.css";

function viewCategory() {
  let item = useSelector((state) => state.VIEW_PROPS);
  item = { ...item };
  console.log(item);

  return (
    <div>
      <SimpleHeader />
      <div className="item_img  ml-3 mt-2">
        <img src={item.url} alt={item.title} />
        <div className="mt-2 ml-5">
          <b className="text-white">{item.title}</b>
          <h4 className="text-white">{item.description}</h4>
          
          <p className="d-flex">
            <i class="mt-1 fas fa-star"></i>
            <i class="mt-1 fas fa-star"></i>
            <i class="mt-1 fas fa-star"></i>
            <i class="mt-1 fas fa-star"></i>
            <i class="mt-1 fas fa-star-half-alt"></i>
            <p className="ml-1"> 4.5 </p>
          </p>
          <p className="d-flex justify-center">
            {" "}
            <i class=" mt-2 fas fa-arrow-circle-right"></i>{" "}
            <p className="ml-2 "> </p>
            {item.variants.map((v, index) => {
              return (
                <p>
                  {v.title} {index + 1 === item.variants.length ? "" : ","}{" "}
                </p>
              );
            })}
          </p>
          
        </div>
        
      </div>
    </div>
  );
}

viewCategory.layout = Admin;

export default viewCategory;
