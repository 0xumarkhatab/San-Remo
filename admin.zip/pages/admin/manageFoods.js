import React,{useState} from "react";
import Admin from "layouts/Admin.js";
import SimpleHeader from "../../components/Headers/SimpleHeader";
import ShowFoods from "../../components/Foods/ShowFoods";
import Link from "next/link";
import {Button} from "reactstrap";
import {useSelector } from "react-redux";

import fetchAndDispatch from "../../API_WORK/fetchAndDispatch";

function manageFoods() {
  
  let foods=useSelector(state=>state.FOODS);
  console.log("foods received ",foods); 
  const [reload,setReload]=useState(false);
const dispatch = useDispatch();

const ViewPropsSetter=(props)=>{
  dispatch({
    type:"SET_VIEW_PROPS",
    
  })
  
}


  if( foods ===undefined  || foods.length === 0 ){
    console.log("Not Loaded Properly");
   fetchAndDispatch();
  }

  

  





  return (
    <div>
      <SimpleHeader />
      <h3 className="text-center mt-4 text-white bg-transparent">Manage Foods</h3>
   
      <ShowFoods reload={setReload}/>      
      <div className="text-center">
      <Link exact href="/admin/AddFood">
          <Button color="primary" className="pt3 pb-3 ">
            Add New Food
          </Button>
        </Link>
        
      </div>
    </div>
  );
}
manageFoods.layout = Admin;
export default manageFoods;
