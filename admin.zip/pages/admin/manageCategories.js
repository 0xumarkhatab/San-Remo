import React from "react";
import Admin from "layouts/Admin.js";

import SimpleHeader from "../../components/Headers/SimpleHeader";
import ShowCategories from "../../components/Categories/ShowCategories";
import Link from "next/link";
import { useSelector} from "react-redux";
import { Button } from "reactstrap";
import fetchAndDispatch from "../../API_WORK/fetchAndDispatch";

function manageCategories() {

let categories=useSelector(state=>state.CATEGORIES);
  console.log("categories received ",categories);

if( categories ===undefined  || categories.length === 0 ){
    console.log("Not Loaded Properly");
   fetchAndDispatch();

  }
  
  



  console.log("manage Categories categories from store",useSelector(state=>state.CATEGORIES));


  

  return (
    <div>
      <SimpleHeader  />
      <h3 className="text-center mt-4 text-white bg-transparent">Manage Categories</h3>

      <ShowCategories />
      <div className="text-center">
      <Link exact href="/admin/AddCategory">
          <Button color="primary" className="pt3 pb-3 ">
            Add New Category
          </Button>
        </Link>
        
      </div>
    </div>
  );
}
manageCategories.layout = Admin;
export default manageCategories;
