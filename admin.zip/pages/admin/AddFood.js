import React, { useState } from "react";
import SimpleHeader from "../../components/Headers/SimpleHeader";
import Admin from "../../layouts/Admin";

import Link from "next/link";

import {
  Button,
  Card,
  CardHeader,
  CardBody,
  FormGroup,
  Form,
  Input,
  
  Container,
  Row,
  Col,
} from "reactstrap";

import SelectMenuSingle from "../../components/SelectMenu/SelectMenuSingle";
import SelectMenuMultiple from "../../components/SelectMenu/SelectMenuMultiple";
import {useSelector,useDispatch} from "react-redux";

// layout for this page
let title, category, sizes, description, price;

function addFood({item}) {

console.log("existing Food Recieved",item);
  const [prices, setPrices] = useState([]);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [allergies, setAllergies] = useState([]);
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [isExtras, setIsExtras] = useState(false);
  const [sizes, setSizes] = useState([]);
  const foods=useSelector(state=>state.FOODS);  
  const categories=useSelector(state=>state.CATEGORIES);  
  console.log(useSelector(state=>state));

  const dispatch=useDispatch();
  

function Submitter(e){
   sizes.map((size,index)=>{
   console.log( document.getElementById(`input-price${index+1}`).value) ;
   prices.push(document.getElementById(`input-price${index+1}`).value);
  });

 let price = document.getElementById("input-price").value;
  const food= (sizes.length ===0) ? 
  {   
    id:(foods.length+1),
    title:title,
    price:price,
    allergies:allergies,
    description:description,
    isExtras:isExtras,
    Extras:[],
    imageUrl:imageUrl,
    category:category,
    size:null,
  }
  :
  sizes.map((size,index)=>{
    return {
    id:(foods.length+index+1),
    title:title,
    price:prices[index],
    allergies:allergies,
    description:description,
    isExtras:isExtras,
    Extras:[],
    imageUrl:imageUrl,
    category:category,
    size:size,
    }

  });
if(sizes.length > 0 ){  
food.map(fo=>{
  foods.push(fo);
});
}
else{
  foods.push(food);
}


  dispatch({
    type:'SET_FOODS',
    FOODS:foods,
  }
  );
  console.log(foods);

}
 const onCategoryChange = (e)=>{
   setCategory(e.value);

 }
  const onPriceChanger = (e) => {
    prices.push(Number(e.target.value));
    setPrices(prices);
  };
  const onTitleChanger = (e) => {
    setTitle(e.target.value);
  };

  const onImageUrlChange=(e)=>{
    
    setImageUrl(e.target.value);

  }
  
  const onDescriptionChanger = (e) => {
    setDescription(e.target.value);
    
  };
  const onSizesChanger = (e) => {
    let s = e.map((u) => u.value);
   document.getElementById("input-price").disabled=true;
   
    

    const ele = document.getElementById("sizesDiv");
    const child = document.createElement('div');
    child.className= "pl-lg-4" ;
    child.innerHTML = `<Row>
                      <Col md="12" >
                        <FormGroup >
                          <label
                            className="mr-2 form-control-label"
                            htmlFor="input-price${e.length}"

                            >
                            Price for Size${e.length}
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-price${e.length}"
                            placeholder="4.56€"
                            
                            
                            type="text"

                          />
                        </FormGroup>
                      </Col>
                    
                      </Row>

    `;

    ele.appendChild(child);
    
    setSizes(s);

    
  };
  const onAllergiesChanger = (e) => {
    let arr = "";
    arr = arr.concat("" + e.target.value);
    arr = arr.split(",", 1000);
    setAllergies(arr);
  };
  const onExtrasChanger = (e) => {
    // console.log(e.target.checked);

    setIsExtras(e.target.checked);
  
  };

  const categoryOptions = categories.map(cat=>{
    return {
      value:cat.title,
      label:cat.title,
    }
  });


  const sizesOptions = [
    { value: "sm", label: "Small" },
    { value: "md", label: "Medium" },
    { value: "lg", label: "Large" },
    { value: "xlg", label: "Extra Large" },
  ];

  return (
    <>
      <SimpleHeader />

      <Container className="mt-7" fluid>
        <Row>
          <Col className="order-xl-1" xl="8">
            <Card className="bg-secondary shadow">
              <CardHeader className="bg-white border-0"></CardHeader>
              <CardBody>
                <Row className="align-items-center">
                  <Col xs="8">
                    <h3 className="mb-0">{item? "Edit Existing Food":"Add New Food"} </h3>
                  </Col>
                  <Col className="text-right" xs="4">
                    <Link   exact href="/admin/manageFoods" onClick={e=>Submitter(e)}>
                      <Button onClick={e=>Submitter(e)} color={item?"success":"primary"} className="pt3 pb-3 ">
                      {item? "Save Changes":"Add"} 

                      </Button>
                    </Link>
                  </Col>
                </Row>
                <Form>
                <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                    <hr className="mt-2 mb-2" />
                   </Col>
                   </Row>
                   </div>

                   <div className="pl-lg-4 text-center">
                    <Row>
                      <Col md="12">
                   <p>Click On Every Field at least Once</p>
                   </Col>
                   </Row>
                   </div>
                   
                   <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                    <hr className="mb-2" />
                   </Col>
                   </Row>
                   </div>
                   
                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-address"
                          >
                            Title
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-title"
                            placeholder="pizza , speghati etc...."
                            autoFocus
                            type="text"
                            defaultValue={item? item.title:""}
                            onChange={(e)=>{onTitleChanger(e)}}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>

                  <div className="pl-lg-4 ">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-category"
                          >
                            Select the Category
                          </label>
                          <SelectMenuSingle
                            id="input-category"
                            options={categoryOptions}
                            defaultValue={item? item.category:""}

                            onChangeHandler={onCategoryChange}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                  <div id="sizesDiv">
                    <div className="pl-lg-4 ">
                      <Row>
                        <Col md="12">
                          <FormGroup>
                            <label
                              className="form-control-label"
                              htmlFor="input-sizes"
                            >
                              Add Size(optional)
                            </label>
                            <SelectMenuMultiple
                              id="input-sizes"
                              onChangeHandler={onSizesChanger}
                              options={sizesOptions}
                            />
                          </FormGroup>
                        </Col>
                      </Row>
                    </div>

                  </div>

                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-address"
                          >
                            Image Url
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-imageUrl"
                            placeholder="www.example.com/image.png"
                            type="text"
                            defaultValue={item? item.url:""}

                            onChange={(e,v)=>onImageUrlChange(e,v)}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>

                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-price"
                          >
                            Price
                          </label>
                          <Input
                            className="form-control-alternative"
                            id="input-price"
                            placeholder="4.56€"
                            defaultValue={item? item.price:""}
                            
                            onChange={(e, v) => onPriceChanger(e, v)}
                            type="text"
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-allergies"
                          >
                            Allergies
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue=""
                            id="input-allergies"
                            placeholder="Allergies i,i,1,2"
                            type="text"
                            defaultValue={item? item.allergies:""}

                            onChange={(e, v) => onAllergiesChanger(e, v)}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <label
                            className="form-control-label"
                            htmlFor="input-address"
                          >
                            Description
                          </label>
                          <Input
                            className="form-control-alternative"
                            defaultValue=""
                            id="input-address"
                            placeholder="Description"
                            defaultValue={item? item.description:""}

                            type="textarea"
                            rows={5}
                            onChange={(e)=>{onDescriptionChanger(e)}}
                          />
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                  <div className="pl-lg-4">
                    <Row>
                      <Col md="12">
                        <FormGroup>
                          <Input type="checkbox" onChange={(e)=>{onExtrasChanger(e)}} />
                          <p>Extras Included?</p>
                        </FormGroup>
                      </Col>
                    </Row>
                  </div>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </>
  );
}
addFood.layout = Admin;

export default addFood;
